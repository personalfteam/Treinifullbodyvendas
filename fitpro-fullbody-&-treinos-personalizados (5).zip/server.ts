import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy Gemini client
let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }
  if (!geminiClient) {
    geminiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return geminiClient;
}

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', hasGeminiKey: !!process.env.GEMINI_API_KEY });
});

app.post('/api/generate-custom-workout', async (req, res) => {
  try {
    const { student, workoutConfig, nutritionConfig, previousExercises } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.status(200).json({
        success: false,
        useLocalFallback: true,
        message: 'No GEMINI_API_KEY configured, will use smart algorithmic generator.',
      });
    }

    const pastExercisesList = Array.isArray(previousExercises) && previousExercises.length > 0
      ? previousExercises.join(', ')
      : 'Nenhum exercício anterior registrado (primeiro ciclo)';

    const systemPrompt = `Você é um Educador Físico e Nutricionista Esportivo de elite especializado em musculação, treinamento Fullbody, treinos em casa (calistenia com peso corporal, acessórios, elásticos/minibands e pesos livres/halteres), divisões de treino (A/B, A/B/C, Push/Pull/Legs), periodização avançada (pirâmides, drop-sets, bi-sets, rest-pause) e nutrição personalizada.
Regras fundamentais:
1. NUNCA gere treinos idênticos ou repita sequências de exercícios para perfis diferentes.
2. DIRETIVA DE MEMÓRIA E ANTI-REPETIÇÃO RIGOROSA: Se o aluno já realizou treinos anteriores e foram informados exercícios já utilizados no histórico, você é ESTRITAMENTE PROIBIDO de repetir esses mesmos exercícios.
3. Cada treino gerado deve ser adaptado rigorosamente para os dados do aluno (Gênero, Idade, Peso, Altura, Nível, Objetivo, Foco Muscular, Observações do Professor).
4. Especifique com precisão séries, repetições (ou tempo), descanso em segundos sugerido, cadência e carga sugerida (ou deixe flexível para preenchimento), além de notas técnicas de execução e técnica avançada se solicitada (ex: pirâmide 12-10-8-6, drop-set na última série, bi-set com 2 exercícios conjugados).
5. REGRA OBRIGATÓRIA PARA TREINOS EM CASA ('casa'): Sempre forneça uma estrutura de 30 dias com 3 treinos completos (Treino A, Treino B, Treino C) para que o aluno e o professor tenham a periodização completa de 30 dias pronta para executar:
   - Treino A: Membros Inferiores & Glúteos + Core (Agachamentos, Passadas, Elevação Pélvica, Panturrilhas, Prancha)
   - Treino B: Membros Superiores & Puxar/Empurrar (Flexões, Remadas, Ombros, Bíceps, Tríceps, Abdômen)
   - Treino C: Full Body Metabólico & Queima de Gordura 30 Dias (Burpees, Saltos, Step-up, Slam ball, Escalador, Mobilidade)
6. Se for 'fullbody', organize o treino englobando grandes grupos com estímulo balanceado. Se for 'inferiores', monte um treino completo e sem repetição focado em pernas/glúteos. Se for 'mobilidade', monte rotina de mobilidade articular e prevenção de lesões. Se for 'musculacao' (A/B, A/B/C), estruture os dias organizadamente.
7. Utilize nomes padronizados e claros de exercícios para que os vídeos demonstrativos e GIFs funcionem com máxima fidelidade.
8. Se for solicitado plano alimentar (dieta), calcule o gasto energético diário aproximado e divida em refeições balanceadas com macros, horários sugeridos, opções de substituição e hidratação.
9. Retorne EXCLUSIVAMENTE um objeto JSON válido no formato especificado.`;

    const userPrompt = `Gere uma nova prescrição de treino e/ou dieta para o seguinte aluno:
DADOS DO ALUNO:
- Nome: ${student?.name || 'Aluno'}
- Gênero: ${student?.gender || 'feminino'}
- Idade: ${student?.age || 28} anos
- Peso: ${student?.weight || 65} kg
- Altura: ${student?.height || 165} cm
- Nível de Treinamento: ${student?.level || 'Iniciante'} (Iniciante, Intermediário, Avançado)
- Objetivo Principal: ${student?.goal || 'Hipertrofia de Membros Inferiores'}
- Frequência Semanal: ${student?.frequency || 3} dias por semana
- Restrições/Lesões: ${student?.limitations || 'Nenhuma'}

HISTÓRICO DE EXERCÍCIOS JÁ UTILIZADOS (ANTI-REPETIÇÃO):
- Exercícios a NÃO repetir: ${pastExercisesList}
(Importante: Não use os nomes listados acima. Substitua por outros exercícios anatômicos do mesmo grupo muscular).

CONFIGURAÇÃO DA PRESCRIÇÃO:
- Modalidade: ${workoutConfig?.modality || 'fullbody'} (opções: fullbody, casa, inferiores, superiores, mobilidade, musculacao)
- Equipamentos em Casa (se aplicável): ${workoutConfig?.homeEquipment || 'peso corporal, elásticos e pesos livres'}
- Divisão: ${workoutConfig?.splitType || 'Fullbody'} (caso musculação: Fullbody, A/B, A/B/C, A/B/C/D)
- Técnicas Especiais: ${workoutConfig?.advancedTechniques?.join(', ') || 'Nenhuma'} (ex: Pirâmide, Drop-set, Bi-set, Rest-pause, Excêntrica Lenta)
- Observações Específicas do Professor: "${workoutConfig?.customNotes || ''}"
- O que deve ser gerado: ${workoutConfig?.generationScope || 'both'} ('workout_only', 'diet_only', 'both')

Retorne JSON estruturado com:
{
  "title": "Nome do Programa de Treino",
  "objectiveSummary": "Resumo do objetivo e estratégia biomecânica",
  "totalEstimatedTimeMinutes": 55,
  "workouts": [
    {
      "id": "treino-a",
      "name": "Treino A - Foco Inferiores / Fullbody",
      "focus": "Membros Inferiores & Core",
      "suggestedRestBetweenExercisesSeconds": 60,
      "exercises": [
        {
          "id": "ex-1",
          "name": "Agachamento Livre com Barra",
          "muscleGroup": "Quadríceps / Glúteos",
          "sets": 4,
          "reps": "10-12",
          "suggestedLoadKg": 20,
          "restSeconds": 60,
          "technique": "Tradicional / Pirâmide / Drop-set / Bi-set",
          "notes": "Postura ereta, descida controlada em 3 segundos."
        }
      ]
    }
  ],
  "nutritionPlan": {
    "dailyCalories": 1950,
    "macros": { "proteinGrams": 130, "carbsGrams": 220, "fatGrams": 55 },
    "waterIntakeMl": 2600,
    "strategy": "Hipertrofia limpa com leve superávit calórico",
    "meals": [
      {
        "id": "meal-1",
        "name": "Café da Manhã",
        "time": "07:30",
        "foods": ["3 ovos mexidos", "2 fatias de pão 100% integral", "1 fruta (banana ou mamão)", "Café sem açúcar"],
        "calories": 420,
        "proteinGrams": 25,
        "notes": "Fonte de proteínas de alto valor biológico e carboidratos complexos"
      }
    ],
    "supplementSuggestions": ["Creatina 5g diárias", "Whey protein pós-treino"]
  },
  "coachSummaryNotes": "Instruções e recomendações do educador físico para o aluno"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.8,
      },
    });

    const text = response.text || '';
    const parsedData = JSON.parse(text);

    return res.json({
      success: true,
      data: parsedData,
    });
  } catch (error: any) {
    console.error('Error generating AI workout:', error);
    return res.status(200).json({
      success: false,
      useLocalFallback: true,
      error: error?.message || 'Error communicating with Gemini API',
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`FitPro Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
