import React, { useState, useEffect, useRef } from 'react';
import { Navbar, ActiveTab } from './components/Navbar';
import { WorkoutCreator } from './components/WorkoutCreator';
import { WorkoutViewer } from './components/WorkoutViewer';
import { StudentEvolutionView } from './components/StudentEvolutionView';
import { NutritionViewer } from './components/NutritionViewer';
import { ActiveWorkoutModal } from './components/ActiveWorkoutModal';
import { StudentModal } from './components/StudentModal';
import { CoachProfileModal } from './components/CoachProfileModal';
import { StudentPortalView } from './components/StudentPortalView';
import { StudentShareModal } from './components/StudentShareModal';
import { SubscriptionModal } from './components/SubscriptionModal';
import { PrintableWorkoutPdf } from './components/PrintableWorkoutPdf';
import { InstallAppModal } from './components/InstallAppModal';
import { DeleteStudentModal } from './components/DeleteStudentModal';
import { FunctionalCircuitManager } from './components/FunctionalCircuitManager';
import { PrintableCircuitPdf } from './components/PrintableCircuitPdf';
import { Student, WorkoutPlan, WorkoutDay, EvolutionRecord, CoachProfile, FunctionalCircuit, Exercise } from './types';
import { INITIAL_STUDENTS, INITIAL_WORKOUT_PLAN, DEFAULT_COACH_PROFILE } from './data/initialData';
import { INITIAL_FUNCTIONAL_CIRCUITS } from './data/initialCircuits';
import { playCountdownBeep, playCelebrationBeep } from './utils/audioTimer';
import { findBestVideoMatch } from './data/videoLibrary';
import { GOOGLE_DRIVE_VIDEOS_URL } from './utils/videoUtils';

function sanitizeExerciseVideo(ex: Exercise): Exercise {
  if (
    !ex.videoUrl ||
    ex.videoUrl.includes('youtube.com') ||
    ex.videoUrl.includes('youtu.be') ||
    ex.videoUrl.includes('vimeo.com')
  ) {
    const match = findBestVideoMatch(ex.name);
    return {
      ...ex,
      videoUrl: match?.videoUrl || GOOGLE_DRIVE_VIDEOS_URL,
      videoName: match?.videoName || 'Vídeo de Demonstração (Google Drive)',
    };
  }
  return ex;
}

function sanitizeWorkoutPlan(plan: WorkoutPlan): WorkoutPlan {
  if (!plan || !plan.workouts) return plan;
  return {
    ...plan,
    workouts: plan.workouts.map((day) => ({
      ...day,
      exercises: (day.exercises || []).map(sanitizeExerciseVideo),
    })),
  };
}

function sanitizeStudent(s: Student): Student {
  return {
    ...s,
    savedPlans: (s.savedPlans || []).map(sanitizeWorkoutPlan),
  };
}

export default function App() {
  // Local storage keys
  const STORAGE_KEY_STUDENTS = 'fitpro_students_v1';
  const STORAGE_KEY_PLAN = 'fitpro_current_plan_v1';
  const STORAGE_KEY_COACH = 'fitpro_coach_profile_v1';

  // State: Coach Profile
  const [coachProfile, setCoachProfile] = useState<CoachProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_COACH);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_COACH_PROFILE;
  });

  // State: Students
  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_STUDENTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_STUDENTS;
  });

  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    INITIAL_STUDENTS[0].id
  );

  // State: View Mode (Coach platform vs Student Portal App)
  const [viewMode, setViewMode] = useState<'coach' | 'student'>('coach');
  const [isCoachPreview, setIsCoachPreview] = useState<boolean>(false);
  const [studentPortalId, setStudentPortalId] = useState<string>(INITIAL_STUDENTS[0].id);

  // Check URL parameters for direct student links (e.g. ?view=student&studentId=student-1)
  useEffect(() => {
    const handleUrlParams = () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const viewParam = params.get('view');
        const studentIdParam = params.get('studentId');

        if (viewParam === 'student' && studentIdParam) {
          setViewMode('student');
          setStudentPortalId(studentIdParam);
          // When opened via external URL, it is a student link
          setIsCoachPreview(false);
          // If student exists, also update selected
          if (students.some((s) => s.id === studentIdParam)) {
            setSelectedStudentId(studentIdParam);
          }
        }
      } catch (e) {
        console.error(e);
      }
    };

    handleUrlParams();
    window.addEventListener('popstate', handleUrlParams);
    return () => window.removeEventListener('popstate', handleUrlParams);
  }, [students]);

  // State: Current Workout Plan
  const [currentPlan, setCurrentPlan] = useState<WorkoutPlan>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PLAN);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_WORKOUT_PLAN;
  });

  // State: Navigation
  const [activeTab, setActiveTab] = useState<ActiveTab>('creator');

  // State: Modals
  const [isStudentModalOpen, setIsStudentModalOpen] = useState(false);
  const [isCoachModalOpen, setIsCoachModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [studentForModal, setStudentForModal] = useState<Student | null>(null);
  const [studentToDelete, setStudentToDelete] = useState<Student | null>(null);

  const [isActiveSessionModalOpen, setIsActiveSessionModalOpen] = useState(false);
  const [activeSessionDay, setActiveSessionDay] = useState<WorkoutDay | null>(
    INITIAL_WORKOUT_PLAN.workouts[0]
  );

  // State: Rest Timer
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [timerSecondsLeft, setTimerSecondsLeft] = useState(0);
  const [totalRestTime, setTotalRestTime] = useState(60);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_STUDENTS, JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PLAN, JSON.stringify(currentPlan));
  }, [currentPlan]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_COACH, JSON.stringify(coachProfile));
  }, [coachProfile]);

  // Rest Timer Interval Logic
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerActive && timerSecondsLeft > 0) {
      interval = setInterval(() => {
        setTimerSecondsLeft((prev) => {
          if (prev <= 1) {
            setIsTimerActive(false);
            playCelebrationBeep();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isTimerActive, timerSecondsLeft]);

  const startRestTimer = (durationSeconds: number) => {
    setTotalRestTime(durationSeconds);
    setTimerSecondsLeft(durationSeconds);
    setIsTimerActive(true);
  };

  const stopRestTimer = () => {
    setIsTimerActive(false);
  };

  const addTimerSeconds = (secs: number) => {
    setTimerSecondsLeft((prev) => Math.max(0, prev + secs));
    setTotalRestTime((prev) => Math.max(0, prev + secs));
  };

  // Selected Student Object
  const selectedStudent =
    students.find((s) => s.id === selectedStudentId) || students[0] || null;

  // Student for portal view
  const currentPortalStudent =
    students.find((s) => s.id === studentPortalId) || selectedStudent || students[0];

  // Latest plan for portal student
  const currentPortalPlan =
    currentPortalStudent.savedPlans && currentPortalStudent.savedPlans.length > 0
      ? currentPortalStudent.savedPlans[0]
      : currentPlan.studentId === currentPortalStudent.id
      ? currentPlan
      : { ...currentPlan, studentId: currentPortalStudent.id, studentName: currentPortalStudent.name };

  // Handlers
  const handleSaveStudent = (updatedOrNewStudent: Student) => {
    setStudents((prev) => {
      const exists = prev.some((s) => s.id === updatedOrNewStudent.id);
      if (exists) {
        return prev.map((s) => (s.id === updatedOrNewStudent.id ? updatedOrNewStudent : s));
      }
      return [updatedOrNewStudent, ...prev];
    });
    setSelectedStudentId(updatedOrNewStudent.id);
  };

  const handleUpdateStudentSubscription = (updatedStudent: Student) => {
    setStudents((prev) =>
      prev.map((s) => (s.id === updatedStudent.id ? updatedStudent : s))
    );
  };

  const handleAddEvolutionRecord = (studentId: string, record: EvolutionRecord) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id !== studentId) return s;
        return {
          ...s,
          weightKg: record.weightKg || s.weightKg,
          evolutionHistory: [...s.evolutionHistory, record],
        };
      })
    );
  };

  const handlePlanGenerated = (plan: WorkoutPlan) => {
    setCurrentPlan(plan);
    setSelectedStudentId(plan.studentId);
    let targetStudent: Student | null = null;

    setStudents((prev) => {
      const exists = prev.some((s) => s.id === plan.studentId);
      if (exists) {
        return prev.map((s) => {
          if (s.id === plan.studentId) {
            const existingPlans = s.savedPlans || [];
            const filtered = existingPlans.filter((p) => p.id !== plan.id);
            const updated: Student = {
              ...s,
              lastUpdatedByCoach: new Date().toISOString(),
              savedPlans: [plan, ...filtered],
            };
            targetStudent = updated;
            return updated;
          }
          return s;
        });
      } else {
        const newStudent: Student = {
          id: plan.studentId,
          name: plan.studentName,
          gender: 'feminino',
          age: 25,
          weightKg: 60,
          heightCm: 165,
          level: 'Iniciante',
          goal: 'Hipertrofia Geral',
          frequencyDaysPerWeek: 3,
          phone: '',
          limitations: '',
          createdAt: new Date().toISOString(),
          lastUpdatedByCoach: new Date().toISOString(),
          savedPlans: [plan],
          evolutionHistory: [
            {
              id: `evo-init-${Date.now()}`,
              date: new Date().toISOString().split('T')[0],
              weightKg: 60,
              notes: 'Ficha gerada pelo professor.',
            },
          ],
        };
        targetStudent = newStudent;
        return [newStudent, ...prev];
      }
    });

    setActiveTab('viewer');
    // Open the Delivery modal automatically so the professor can send the workout to the student with 1 click
    setTimeout(() => {
      if (targetStudent) {
        setStudentForModal(targetStudent);
      } else {
        const st = students.find((s) => s.id === plan.studentId);
        if (st) setStudentForModal({ ...st, savedPlans: [plan, ...(st.savedPlans || [])] });
      }
      setIsShareModalOpen(true);
    }, 150);
  };

  const handleUpdatePlan = (updatedPlan: WorkoutPlan) => {
    setCurrentPlan(updatedPlan);
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === updatedPlan.studentId) {
          const existingPlans = s.savedPlans || [];
          const exists = existingPlans.some((p) => p.id === updatedPlan.id);
          const updatedPlans = exists
            ? existingPlans.map((p) => (p.id === updatedPlan.id ? updatedPlan : p))
            : [updatedPlan, ...existingPlans];
          return {
            ...s,
            lastUpdatedByCoach: new Date().toISOString(),
            savedPlans: updatedPlans,
          };
        }
        return s;
      })
    );
  };

  const handleStudentUpdateExerciseLoad = (
    studentId: string,
    exerciseName: string,
    newLoadKg: number
  ) => {
    const todayStr = new Date().toISOString().split('T')[0];
    setStudents((prev) =>
      prev.map((st) => {
        if (st.id !== studentId) return st;
        const newRecord: EvolutionRecord = {
          date: todayStr,
          exerciseLoads: { [exerciseName]: newLoadKg },
        };
        return {
          ...st,
          evolutionHistory: [...st.evolutionHistory, newRecord],
        };
      })
    );
  };

  const handleStartSession = (day: WorkoutDay) => {
    setActiveSessionDay(day);
    setIsActiveSessionModalOpen(true);
  };

  const handleOpenShareModal = (st?: Student) => {
    setStudentForModal(st || selectedStudent);
    setIsShareModalOpen(true);
  };

  const handleOpenSubscriptionModal = (st?: Student) => {
    setStudentForModal(st || selectedStudent);
    setIsSubscriptionModalOpen(true);
  };

  const handleOpenDeleteStudent = (st?: Student) => {
    const target = st || selectedStudent;
    if (target) {
      setStudentToDelete(target);
    }
  };

  const handleConfirmDeleteStudent = (studentId: string) => {
    try {
      localStorage.removeItem(`fitpro_student_water_${studentId}`);
      localStorage.removeItem(`fitpro_student_completed_${studentId}`);
    } catch (e) {
      console.error(e);
    }

    setStudents((prev) => {
      const remaining = prev.filter((s) => s.id !== studentId);
      try {
        localStorage.setItem(STORAGE_KEY_STUDENTS, JSON.stringify(remaining));
      } catch (e) {
        console.error(e);
      }
      if (selectedStudentId === studentId) {
        if (remaining.length > 0) {
          setSelectedStudentId(remaining[0].id);
          if (remaining[0].savedPlans && remaining[0].savedPlans.length > 0) {
            setCurrentPlan(remaining[0].savedPlans[0]);
          }
        } else {
          setSelectedStudentId('');
        }
      }
      return remaining;
    });
    setStudentToDelete(null);
  };

  const handleOpenStudentPortal = (studentId?: string) => {
    const targetId = studentId || selectedStudentId;
    setStudentPortalId(targetId);
    setIsCoachPreview(true);
    setViewMode('student');
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('view', 'student');
      url.searchParams.set('studentId', targetId);
      window.history.pushState({}, '', url.toString());
    } catch (e) {
      console.error(e);
    }
  };

  const handleSwitchToCoachView = () => {
    setViewMode('coach');
    setIsCoachPreview(false);
    try {
      const url = new URL(window.location.href);
      url.searchParams.delete('view');
      url.searchParams.delete('studentId');
      window.history.pushState({}, '', url.toString());
    } catch (e) {
      console.error(e);
    }
  };

  // IF STUDENT PORTAL VIEW MODE IS ACTIVE:
  if (viewMode === 'student') {
    // If student not found and not in coach preview
    if (!currentPortalStudent) {
      return (
        <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6 text-center">
          <div className="max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto text-2xl font-bold">
              🔒
            </div>
            <h2 className="text-xl font-bold text-white">Aluno não encontrado</h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              O link de acesso fornecido não corresponde a nenhum aluno cadastrado na consultoria de <strong>{coachProfile.name}</strong>.
            </p>
            <a
              href={`https://wa.me/55${coachProfile.phone.replace(/\D/g, '')}?text=${encodeURIComponent('Olá professor, preciso do link de acesso atualizado para ver meu treino!')}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#25D366] text-slate-950 text-xs font-bold shadow-lg"
            >
              <span>Solicitar Link no WhatsApp</span>
            </a>
          </div>
        </div>
      );
    }

    return (
      <StudentPortalView
        student={currentPortalStudent}
        plan={currentPortalPlan}
        coachProfile={coachProfile}
        isCoachPreview={isCoachPreview}
        studentsList={isCoachPreview ? students : []}
        onSelectStudent={isCoachPreview ? (id) => {
          setStudentPortalId(id);
          setSelectedStudentId(id);
        } : undefined}
        onSwitchToCoachView={isCoachPreview ? handleSwitchToCoachView : undefined}
        onUpdateExerciseLoad={(exName, load) =>
          handleStudentUpdateExerciseLoad(currentPortalStudent.id, exName, load)
        }
      />
    );
  }

  // COACH PLATFORM INTERFACE:
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        students={students}
        selectedStudent={selectedStudent}
        setSelectedStudent={(st) => st && setSelectedStudentId(st.id)}
        onNewStudentClick={() => setIsStudentModalOpen(true)}
        onDeleteStudent={handleOpenDeleteStudent}
        onOpenCoachProfile={() => setIsCoachModalOpen(true)}
        onOpenStudentPortal={() => handleOpenStudentPortal(selectedStudentId)}
        onOpenShareModal={() => handleOpenShareModal(selectedStudent)}
        onOpenSubscriptionModal={() => handleOpenSubscriptionModal(selectedStudent)}
        onOpenInstallAppModal={() => setIsInstallModalOpen(true)}
        isTimerRunning={isTimerActive}
        timerSecondsLeft={timerSecondsLeft}
        openTimerModal={() => {
          if (activeSessionDay) setIsActiveSessionModalOpen(true);
          else if (currentPlan.workouts[0]) {
            setActiveSessionDay(currentPlan.workouts[0]);
            setIsActiveSessionModalOpen(true);
          }
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {activeTab === 'creator' && (
          <WorkoutCreator
            students={students}
            selectedStudent={selectedStudent}
            onSelectStudent={(st) => setSelectedStudentId(st.id)}
            onSaveStudent={handleSaveStudent}
            onPlanGenerated={handlePlanGenerated}
          />
        )}

        {activeTab === 'viewer' && selectedStudent && (
          <WorkoutViewer
            plan={currentPlan}
            student={selectedStudent}
            onUpdatePlan={handleUpdatePlan}
            onStartSession={handleStartSession}
            onNavigateToCreator={() => setActiveTab('creator')}
            onNavigateToNutrition={() => setActiveTab('nutrition')}
            onOpenShareModal={(st) => handleOpenShareModal(st)}
            onOpenSubscriptionModal={(st) => handleOpenSubscriptionModal(st)}
            onOpenStudentPortal={(id) => handleOpenStudentPortal(id)}
            onDeleteStudent={handleOpenDeleteStudent}
          />
        )}

        {activeTab === 'students' && (
          <StudentEvolutionView
            students={students}
            selectedStudent={selectedStudent}
            onSelectStudent={(st) => setSelectedStudentId(st.id)}
            onAddNewStudent={() => setIsStudentModalOpen(true)}
            onDeleteStudent={handleOpenDeleteStudent}
            onAddEvolutionRecord={handleAddEvolutionRecord}
            onLoadPlan={(plan) => {
              setCurrentPlan(plan);
              setActiveTab('viewer');
            }}
            onOpenShareModal={(st) => handleOpenShareModal(st)}
            onOpenSubscriptionModal={(st) => handleOpenSubscriptionModal(st)}
            onOpenStudentPortal={(id) => handleOpenStudentPortal(id)}
          />
        )}

        {activeTab === 'circuits' && (
          <FunctionalCircuitManager
            coachProfile={coachProfile}
            onOpenCoachProfile={() => setIsCoachModalOpen(true)}
          />
        )}

        {activeTab === 'nutrition' && selectedStudent && currentPlan.nutritionPlan && (
          <NutritionViewer
            nutritionPlan={currentPlan.nutritionPlan}
            student={selectedStudent}
            onNavigateToWorkout={() => setActiveTab('viewer')}
          />
        )}

        {activeTab === 'timer' && selectedStudent && (
          <div className="max-w-4xl mx-auto px-4 py-8">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 text-center">
              <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto text-2xl font-black">
                ⏱️
              </div>
              <div className="space-y-2 max-w-md mx-auto">
                <h2 className="text-2xl font-black text-white font-display">
                  Cronômetro & Modo de Execução Ativa
                </h2>
                <p className="text-xs sm:text-sm text-slate-400">
                  Inicie a medição de descanso entre séries com bips sonoros e registro de carga do aluno em tempo real.
                </p>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  id="btn-launch-active-workout-tab"
                  onClick={() => {
                    if (currentPlan.workouts[0]) {
                      setActiveSessionDay(currentPlan.workouts[0]);
                      setIsActiveSessionModalOpen(true);
                    }
                  }}
                  className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition-all"
                >
                  <span>Abrir Cronômetro com Ficha ({selectedStudent.name})</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Offscreen & Print-Ready PDF Container (used by html2canvas/jspdf export and native window.print) */}
      <div
        className="print:block"
        style={{
          position: 'absolute',
          left: '-9999px',
          top: 0,
          width: '850px',
          backgroundColor: '#ffffff',
          zIndex: -10,
        }}
      >
        {selectedStudent && (
          <PrintableWorkoutPdf
            plan={currentPlan}
            student={selectedStudent}
            coachProfile={coachProfile}
          />
        )}
      </div>

      {/* Active Workout Session & Rest Timer Modal */}
      {isActiveSessionModalOpen && activeSessionDay && selectedStudent && (
        <ActiveWorkoutModal
          day={activeSessionDay}
          student={selectedStudent}
          isOpen={isActiveSessionModalOpen}
          onClose={() => setIsActiveSessionModalOpen(false)}
          onSaveProgress={(updatedDay) => {
            const updatedWorkouts = currentPlan.workouts.map((w) =>
              w.id === updatedDay.id ? updatedDay : w
            );
            setCurrentPlan({ ...currentPlan, workouts: updatedWorkouts });
          }}
          isTimerActive={isTimerActive}
          timerSecondsLeft={timerSecondsLeft}
          totalRestTime={totalRestTime}
          startRestTimer={startRestTimer}
          stopRestTimer={stopRestTimer}
          addTimerSeconds={addTimerSeconds}
        />
      )}

      {/* New/Edit Student Modal */}
      <StudentModal
        isOpen={isStudentModalOpen}
        onClose={() => setIsStudentModalOpen(false)}
        onSave={handleSaveStudent}
        onDelete={handleOpenDeleteStudent}
        initialStudent={selectedStudent}
      />

      {/* Coach Profile & CREF Customization Modal */}
      <CoachProfileModal
        isOpen={isCoachModalOpen}
        onClose={() => setIsCoachModalOpen(false)}
        coachProfile={coachProfile}
        onSaveCoachProfile={(updatedProfile) => setCoachProfile(updatedProfile)}
      />

      {/* Student Link Share Modal (WhatsApp, QR Code, Direct URL) */}
      {studentForModal && (
        <StudentShareModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          student={studentForModal}
          plan={
            studentForModal.savedPlans && studentForModal.savedPlans.length > 0
              ? studentForModal.savedPlans[0]
              : currentPlan
          }
          coachProfile={coachProfile}
          onOpenStudentView={(studentId) => handleOpenStudentPortal(studentId)}
          onOpenInstallAppModal={() => setIsInstallModalOpen(true)}
        />
      )}

      {/* Student Subscription & Plan Cancellation Modal */}
      {studentForModal && (
        <SubscriptionModal
          isOpen={isSubscriptionModalOpen}
          onClose={() => setIsSubscriptionModalOpen(false)}
          student={studentForModal}
          onSaveStudent={handleUpdateStudentSubscription}
          coachPhone={coachProfile.phone}
        />
      )}

      {/* PWA / Native App Install Modal (Coach or Student) */}
      <InstallAppModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        appName="FitPro Treinos & Consultoria"
        targetRole="coach"
        studentShareUrl={
          selectedStudent
            ? `${window.location.origin}${window.location.pathname}?view=student&studentId=${selectedStudent.id}`
            : undefined
        }
      />

      {/* Delete Student Confirmation Modal */}
      <DeleteStudentModal
        isOpen={!!studentToDelete}
        student={studentToDelete}
        onClose={() => setStudentToDelete(null)}
        onConfirmDelete={handleConfirmDeleteStudent}
      />
    </div>
  );
}
