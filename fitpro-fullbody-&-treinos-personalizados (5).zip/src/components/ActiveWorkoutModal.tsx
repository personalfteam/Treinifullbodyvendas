import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Timer,
  Dumbbell,
  Minimize2,
  X,
  Volume2,
  VolumeX,
  Plus,
  Minus,
  Sparkles,
  Trophy,
  ArrowRight,
  Flame,
  Video
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { WorkoutDay, Exercise, Student } from '../types';
import { playCountdownBeep, playCelebrationBeep } from '../utils/audioTimer';
import { VideoPlayerModal } from './VideoPlayerModal';

interface ActiveWorkoutModalProps {
  day: WorkoutDay;
  student: Student;
  isOpen: boolean;
  onClose: () => void;
  onSaveProgress: (updatedDay: WorkoutDay) => void;
  // Timer shared state
  isTimerActive: boolean;
  timerSecondsLeft: number;
  totalRestTime: number;
  startRestTimer: (duration: number) => void;
  stopRestTimer: () => void;
  addTimerSeconds: (secs: number) => void;
}

export const ActiveWorkoutModal: React.FC<ActiveWorkoutModalProps> = ({
  day,
  student,
  isOpen,
  onClose,
  onSaveProgress,
  isTimerActive,
  timerSecondsLeft,
  totalRestTime,
  startRestTimer,
  stopRestTimer,
  addTimerSeconds,
}) => {
  const [exercises, setExercises] = useState<Exercise[]>(day.exercises);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [activeVideoModal, setActiveVideoModal] = useState<{ url: string; title: string; notes?: string } | null>(null);

  useEffect(() => {
    setExercises(day.exercises);
  }, [day]);

  // Audio trigger on countdown
  useEffect(() => {
    if (isTimerActive && soundEnabled) {
      if (timerSecondsLeft <= 3 && timerSecondsLeft > 0) {
        playCountdownBeep(false);
      } else if (timerSecondsLeft === 0) {
        playCountdownBeep(true);
      }
    }
  }, [timerSecondsLeft, isTimerActive, soundEnabled]);

  if (!isOpen) return null;

  const handleToggleSet = (exerciseIndex: number, setIndex: number, restSeconds: number) => {
    const nextExercises = [...exercises];
    const targetEx = nextExercises[exerciseIndex];
    if (!targetEx.executedSets) {
      targetEx.executedSets = Array.from({ length: targetEx.sets }, (_, i) => ({
        setNumber: i + 1,
        repsCompleted: 10,
        weightKg: targetEx.userCurrentLoadKg || targetEx.suggestedLoadKg || 10,
        completed: false,
      }));
    }

    const currentCompleted = targetEx.executedSets[setIndex].completed;
    targetEx.executedSets[setIndex].completed = !currentCompleted;

    // Check if whole exercise is finished
    const allSetsDone = targetEx.executedSets.every((s) => s.completed);
    targetEx.isCompleted = allSetsDone;

    setExercises(nextExercises);
    onSaveProgress({ ...day, exercises: nextExercises });

    // If set just marked completed, start rest timer!
    if (!currentCompleted) {
      startRestTimer(restSeconds || 60);
    }

    // Check if entire workout day is complete
    const allWorkoutDone = nextExercises.every((ex) =>
      ex.executedSets?.every((s) => s.completed)
    );
    if (allWorkoutDone && !isCompleted) {
      setIsCompleted(true);
      if (soundEnabled) playCelebrationBeep();
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const handleUpdateWeight = (exerciseIndex: number, setIndex: number, newWeight: number) => {
    const nextExercises = [...exercises];
    const targetEx = nextExercises[exerciseIndex];
    if (!targetEx.executedSets) return;
    targetEx.executedSets[setIndex].weightKg = Math.max(0, newWeight);
    targetEx.userCurrentLoadKg = Math.max(0, newWeight);
    setExercises(nextExercises);
    onSaveProgress({ ...day, exercises: nextExercises });
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const timerProgressPercent = totalRestTime > 0 ? ((totalRestTime - timerSecondsLeft) / totalRestTime) * 100 : 0;

  // Floating Minimized view
  if (isMinimized) {
    return (
      <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-emerald-500/50 rounded-2xl p-4 shadow-2xl flex items-center gap-4 animate-bounce-short">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
            <Timer className="w-4 h-4 animate-spin" />
          </div>
          <div>
            <p className="text-xs text-slate-400">Tempo de Descanso</p>
            <p className="text-lg font-black text-white font-display">
              {isTimerActive ? formatSeconds(timerSecondsLeft) : '00:00'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsMinimized(false)}
            className="px-3 py-1.5 rounded-xl bg-emerald-500 text-slate-950 text-xs font-bold hover:bg-emerald-400"
          >
            Maximizar
          </button>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-3 sm:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-3xl w-full shadow-2xl flex flex-col max-h-[92vh] overflow-hidden my-auto">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <Dumbbell className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-white font-display">
                  {day.name}
                </h2>
                <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                  MODO EXECUÇÃO
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Aluno(a): <strong className="text-slate-200">{student.name}</strong> • Marque as séries concluídas
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2 rounded-xl border text-xs ${
                soundEnabled
                  ? 'bg-slate-800 text-emerald-400 border-slate-700'
                  : 'bg-slate-800 text-slate-500 border-slate-700'
              }`}
              title={soundEnabled ? 'Som ativado' : 'Som desativado'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setIsMinimized(true)}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white border border-slate-700"
              title="Minimizar para flutuante"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-rose-400 border border-slate-700"
              title="Fechar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* REST TIMER HERO PANEL */}
        <div className="p-4 sm:p-6 bg-gradient-to-br from-slate-950 to-slate-900 border-b border-slate-800 shrink-0">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Countdown Display with Ring */}
            <div className="flex items-center gap-4">
              <div className="relative w-20 h-20 sm:w-24 sm:h-24 flex items-center justify-center shrink-0">
                {/* SVG Ring */}
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="42"
                    className="text-slate-800"
                    strokeWidth="8"
                    stroke="currentColor"
                    fill="transparent"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="42"
                    className={`${timerSecondsLeft <= 3 && isTimerActive ? 'text-amber-400' : 'text-emerald-400'} transition-all duration-300`}
                    strokeWidth="8"
                    strokeDasharray={264}
                    strokeDashoffset={264 - (264 * timerProgressPercent) / 100}
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="transparent"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className={`text-xl sm:text-2xl font-black font-display ${timerSecondsLeft <= 3 && isTimerActive ? 'text-amber-400 animate-pulse' : 'text-white'}`}>
                    {formatSeconds(timerSecondsLeft)}
                  </span>
                  <span className="text-[9px] uppercase font-bold text-slate-400">Descanso</span>
                </div>
              </div>

              <div className="space-y-1 text-center sm:text-left">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-300">Cronômetro entre Séries</span>
                  {isTimerActive && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                  )}
                </div>
                <p className="text-xs text-slate-400 max-w-xs">
                  {isTimerActive
                    ? 'Respire fundo, hidrate-se e prepare-se para a próxima série.'
                    : 'Marque uma série ou clique em um tempo rápido abaixo para iniciar.'}
                </p>
                {/* Manual Timer Controls */}
                <div className="flex items-center gap-1.5 pt-1">
                  {isTimerActive ? (
                    <button
                      onClick={stopRestTimer}
                      className="px-3 py-1 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/40 text-xs font-bold flex items-center gap-1 hover:bg-rose-500/30"
                    >
                      <Pause className="w-3.5 h-3.5" /> Parar
                    </button>
                  ) : (
                    <button
                      onClick={() => startRestTimer(60)}
                      className="px-3 py-1 rounded-lg bg-emerald-500 text-slate-950 text-xs font-bold flex items-center gap-1 hover:bg-emerald-400"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" /> Iniciar (60s)
                    </button>
                  )}
                  <button
                    onClick={() => addTimerSeconds(15)}
                    className="px-2 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
                    title="+15 segundos"
                  >
                    +15s
                  </button>
                  <button
                    onClick={() => addTimerSeconds(-15)}
                    className="px-2 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
                    title="-15 segundos"
                  >
                    -15s
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Preset Buttons */}
            <div className="grid grid-cols-4 sm:grid-cols-2 gap-1.5 w-full sm:w-auto">
              {[30, 45, 60, 90].map((presetSecs) => (
                <button
                  key={presetSecs}
                  onClick={() => startRestTimer(presetSecs)}
                  className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all ${
                    totalRestTime === presetSecs && isTimerActive
                      ? 'bg-emerald-500/25 text-emerald-300 border-emerald-500'
                      : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  {presetSecs}s
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* WORKOUT COMPLETION CELEBRATION */}
        {isCompleted && (
          <div className="p-4 bg-emerald-950/60 border-b border-emerald-500/40 text-emerald-300 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-sm">
              <Trophy className="w-5 h-5 text-amber-400 animate-bounce" />
              <span>Parabéns! Treino finalizado com sucesso! Cargas registradas.</span>
            </div>
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400 text-xs"
            >
              Concluir Sessão
            </button>
          </div>
        )}

        {/* EXERCISES & SETS CHECKLIST */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          {exercises.map((ex, exIdx) => {
            const executedSets = ex.executedSets || Array.from({ length: ex.sets }, (_, i) => ({
              setNumber: i + 1,
              repsCompleted: 10,
              weightKg: ex.userCurrentLoadKg || ex.suggestedLoadKg || 10,
              completed: false,
            }));

            return (
              <div
                key={ex.id}
                className={`p-4 rounded-2xl border transition-all ${
                  ex.isCompleted
                    ? 'bg-emerald-950/20 border-emerald-500/40 opacity-90'
                    : 'bg-slate-800/60 border-slate-700/80'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-lg bg-slate-700 text-emerald-400 font-bold text-xs flex items-center justify-center">
                      {exIdx + 1}
                    </span>
                    <div>
                      <h4 className="font-bold text-sm text-white">{ex.name}</h4>
                      <p className="text-[11px] text-slate-400">
                        {ex.sets} séries • {ex.reps} reps • Descanso: {ex.restSeconds}s
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {ex.videoUrl && (
                      <button
                        type="button"
                        onClick={() =>
                          setActiveVideoModal({
                            url: ex.videoUrl!,
                            title: ex.videoName || ex.name,
                            notes: ex.notes,
                          })
                        }
                        className="px-2 py-1 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 text-[10px] font-bold flex items-center gap-1 transition-all"
                        title="Ver vídeo de demonstração"
                      >
                        <Video className="w-3 h-3 text-indigo-400" />
                        <span>Vídeo</span>
                      </button>
                    )}
                    {ex.technique && ex.technique !== 'Tradicional' && (
                      <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                        {ex.technique}
                      </span>
                    )}
                  </div>
                </div>

                {/* Sets Row */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {executedSets.map((s, sIdx) => (
                    <div
                      key={sIdx}
                      className={`p-2.5 rounded-xl border flex flex-col justify-between gap-1.5 transition-all ${
                        s.completed
                          ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-200'
                          : 'bg-slate-900/80 border-slate-700/80 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs font-bold">
                        <span>Série {sIdx + 1}</span>
                        <button
                          type="button"
                          onClick={() => handleToggleSet(exIdx, sIdx, ex.restSeconds)}
                          className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all ${
                            s.completed
                              ? 'bg-emerald-500 text-slate-950'
                              : 'bg-slate-800 text-slate-400 hover:bg-emerald-500/20 hover:text-emerald-400'
                          }`}
                        >
                          <CheckCircle2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Weight logged for this set */}
                      <div className="flex items-center gap-1 text-[11px]">
                        <span className="text-slate-400">Carga:</span>
                        <input
                          type="number"
                          step="0.5"
                          min="0"
                          value={s.weightKg}
                          onChange={(e) => handleUpdateWeight(exIdx, sIdx, Number(e.target.value))}
                          className="w-12 px-1 py-0.5 text-center rounded bg-slate-800 font-bold text-white text-xs focus:outline-none focus:ring-1 focus:ring-emerald-400"
                        />
                        <span className="text-slate-400">kg</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900 flex items-center justify-between shrink-0">
          <span className="text-xs text-slate-400">
            {exercises.filter((e) => e.isCompleted).length} de {exercises.length} exercícios concluídos
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
          >
            Fechar Janela
          </button>
        </div>
      </div>

      {/* Modal de Reprodução de Vídeo do Exercício durante a sessão */}
      {activeVideoModal && (
        <VideoPlayerModal
          isOpen={true}
          videoUrl={activeVideoModal.url}
          title={activeVideoModal.title}
          notes={activeVideoModal.notes}
          onClose={() => setActiveVideoModal(null)}
        />
      )}
    </div>
  );
};
