import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Users,
  Flame,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Trophy,
  Video
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { FunctionalCircuit, CircuitExerciseItem } from '../types';
import { playCountdownBeep, playCelebrationBeep } from '../utils/audioTimer';
import { VideoPlayerModal } from './VideoPlayerModal';

interface CircuitTimerModalProps {
  isOpen: boolean;
  circuit: FunctionalCircuit;
  onClose: () => void;
}

type TimerPhase = 'prepare' | 'work' | 'transition' | 'round_rest' | 'finished';

export const CircuitTimerModal: React.FC<CircuitTimerModalProps> = ({
  isOpen,
  circuit,
  onClose,
}) => {
  if (!isOpen) return null;

  // Circuit configuration
  const totalRounds = circuit.rounds || 3;
  const workDuration = circuit.workTimeSeconds || 40;
  const transitionDuration = circuit.transitionTimeSeconds || 15;
  const roundRestDuration = circuit.roundRestSeconds || 60;
  const mainStations = circuit.mainExercises;
  const totalStations = mainStations.length || 8;

  // Timer State
  const [currentRound, setCurrentRound] = useState(1);
  const [currentStationIndex, setCurrentStationIndex] = useState(0);
  const [phase, setPhase] = useState<TimerPhase>('prepare');
  const [secondsLeft, setSecondsLeft] = useState(5); // 5s initial prep
  const [isRunning, setIsRunning] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [activeVideoModal, setActiveVideoModal] = useState<{ url: string; title: string; notes?: string } | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  const currentStation: CircuitExerciseItem | undefined = mainStations[currentStationIndex];
  const nextStationIndex = (currentStationIndex + 1) % totalStations;
  const nextStation: CircuitExerciseItem | undefined = mainStations[nextStationIndex];

  // Fullscreen toggle helper
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  // Sound beep triggers
  useEffect(() => {
    if (!isRunning || !soundEnabled) return;

    if (secondsLeft === 3 || secondsLeft === 2 || secondsLeft === 1) {
      playCountdownBeep(false);
    } else if (secondsLeft === 0) {
      if (phase === 'finished') {
        playCelebrationBeep();
      } else {
        playCountdownBeep(true);
      }
    }
  }, [secondsLeft, isRunning, soundEnabled, phase]);

  // Main Timer Tick Engine
  useEffect(() => {
    let timer: NodeJS.Timeout;

    if (isRunning && phase !== 'finished') {
      timer = setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            // State Transition Machine
            if (phase === 'prepare') {
              setPhase('work');
              return workDuration;
            } else if (phase === 'work') {
              const isLastStationOfRound = currentStationIndex === totalStations - 1;
              const isLastRound = currentRound === totalRounds;

              if (isLastStationOfRound) {
                if (isLastRound) {
                  setPhase('finished');
                  confetti({
                    particleCount: 150,
                    spread: 80,
                    origin: { y: 0.6 },
                  });
                  return 0;
                } else {
                  // Round Rest Break
                  setPhase('round_rest');
                  return roundRestDuration;
                }
              } else {
                // Station Transition
                setPhase('transition');
                return transitionDuration;
              }
            } else if (phase === 'transition') {
              // Move to next station work
              setCurrentStationIndex((idx) => (idx + 1) % totalStations);
              setPhase('work');
              return workDuration;
            } else if (phase === 'round_rest') {
              // Start next round from station 0
              setCurrentRound((r) => r + 1);
              setCurrentStationIndex(0);
              setPhase('work');
              return workDuration;
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => clearInterval(timer);
  }, [
    isRunning,
    phase,
    currentRound,
    currentStationIndex,
    totalRounds,
    totalStations,
    workDuration,
    transitionDuration,
    roundRestDuration,
  ]);

  // Manual Station Navigation
  const handleNextStation = () => {
    if (currentStationIndex < totalStations - 1) {
      setCurrentStationIndex((prev) => prev + 1);
      setPhase('work');
      setSecondsLeft(workDuration);
    } else if (currentRound < totalRounds) {
      setCurrentRound((prev) => prev + 1);
      setCurrentStationIndex(0);
      setPhase('work');
      setSecondsLeft(workDuration);
    }
  };

  const handlePrevStation = () => {
    if (currentStationIndex > 0) {
      setCurrentStationIndex((prev) => prev - 1);
      setPhase('work');
      setSecondsLeft(workDuration);
    } else if (currentRound > 1) {
      setCurrentRound((prev) => prev - 1);
      setCurrentStationIndex(totalStations - 1);
      setPhase('work');
      setSecondsLeft(workDuration);
    }
  };

  const handleReset = () => {
    setIsRunning(false);
    setCurrentRound(1);
    setCurrentStationIndex(0);
    setPhase('prepare');
    setSecondsLeft(5);
  };

  // Phase color themes
  const getPhaseStyles = () => {
    switch (phase) {
      case 'prepare':
        return {
          bg: 'from-amber-950/40 via-slate-900 to-amber-950/30',
          badge: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
          title: 'PREPAREM-SE!',
          subtitle: 'Posicionem-se nas estações para iniciar',
          timerText: 'text-amber-400',
        };
      case 'work':
        return {
          bg: 'from-emerald-950/50 via-slate-900 to-emerald-950/30',
          badge: 'bg-emerald-500 text-slate-950 font-black animate-pulse',
          title: 'EM AÇÃO! DÊ O SEU MÁXIMO!',
          subtitle: `Estação ${currentStationIndex + 1} de ${totalStations} • Volta ${currentRound} de ${totalRounds}`,
          timerText: 'text-emerald-400',
        };
      case 'transition':
        return {
          bg: 'from-cyan-950/50 via-slate-900 to-cyan-950/30',
          badge: 'bg-cyan-500/30 text-cyan-300 border-cyan-500/50',
          title: 'GIREM PARA A PRÓXIMA ESTAÇÃO!',
          subtitle: `Próximo: Estação ${nextStationIndex + 1} (${nextStation?.name || 'Próximo Exercício'})`,
          timerText: 'text-cyan-400',
        };
      case 'round_rest':
        return {
          bg: 'from-indigo-950/50 via-slate-900 to-indigo-950/30',
          badge: 'bg-indigo-500/30 text-indigo-300 border-indigo-500/50',
          title: 'INTERVALO DE VOLTA • HIDRATAÇÃO!',
          subtitle: `Fim da Volta ${currentRound}! Respirem fundo e recuperem o fôlego.`,
          timerText: 'text-indigo-400',
        };
      case 'finished':
        return {
          bg: 'from-amber-950/40 via-slate-900 to-emerald-950/40',
          badge: 'bg-emerald-500 text-slate-950 font-black',
          title: 'CIRCUITO CONCLUÍDO COM SUCESSO!',
          subtitle: 'Parabéns turma! Missão cumprida com excelência!',
          timerText: 'text-emerald-400',
        };
    }
  };

  const currentStyles = getPhaseStyles();

  // Progress calculations
  const totalPhaseTime =
    phase === 'prepare'
      ? 5
      : phase === 'work'
      ? workDuration
      : phase === 'transition'
      ? transitionDuration
      : roundRestDuration;
  const progressPercent = Math.max(0, Math.min(100, (secondsLeft / (totalPhaseTime || 1)) * 100));

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 bg-slate-950 flex flex-col justify-between overflow-hidden select-none font-sans"
    >
      {/* Top Bar Header */}
      <div className="px-6 py-4 bg-slate-900/90 backdrop-blur border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black">
            <Flame className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-emerald-400">
                FitPro Live TV
              </span>
              <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-bold">
                {circuit.groupCategory}
              </span>
            </div>
            <h2 className="text-lg font-black text-white truncate max-w-md sm:max-w-xl">
              {circuit.title}
            </h2>
          </div>
        </div>

        {/* Header Action Tools */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            id="btn-circuit-sound-toggle"
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
              soundEnabled
                ? 'bg-slate-800 border-slate-700 text-emerald-400'
                : 'bg-slate-800 border-slate-700 text-slate-500'
            }`}
            title={soundEnabled ? 'Silenciar bips sonoros' : 'Ativar bips sonoros'}
          >
            {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>

          <button
            id="btn-circuit-fullscreen-toggle"
            onClick={toggleFullscreen}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white transition-all"
            title="Modo Tela Cheia (Ideal para TV da Academia ou Tablet)"
          >
            {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </button>

          <button
            id="btn-circuit-timer-close"
            onClick={onClose}
            className="p-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 transition-all"
            title="Fechar Cronômetro do Circuito"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Center Display */}
      <div
        className={`flex-1 flex flex-col items-center justify-center p-4 sm:p-8 bg-gradient-to-b ${currentStyles.bg} transition-colors duration-500 relative`}
      >
        {phase === 'finished' ? (
          <div className="text-center space-y-6 max-w-xl px-4 animate-in zoom-in-95 duration-500">
            <div className="w-24 h-24 rounded-3xl bg-emerald-500/20 border-2 border-emerald-500/50 text-emerald-400 flex items-center justify-center mx-auto shadow-2xl shadow-emerald-500/30">
              <Trophy className="w-12 h-12" />
            </div>
            <div className="space-y-2">
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-xs uppercase tracking-widest border border-emerald-500/30">
                Treino Completo
              </span>
              <h1 className="text-3xl sm:text-5xl font-black text-white font-display">
                Circuito Finalizado!
              </h1>
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                Todos os alunos completaram {totalRounds} voltas pelas {totalStations} estações de
                trabalho funcional. Excelente desempenho da turma!
              </p>
            </div>
            <div className="pt-4 flex justify-center gap-4">
              <button
                id="btn-circuit-restart"
                onClick={handleReset}
                className="px-8 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/25 transition-all"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reiniciar Circuito</span>
              </button>
              <button
                onClick={onClose}
                className="px-8 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-750 text-white font-bold text-sm border border-slate-700 transition-all"
              >
                <span>Encerrar Modo TV</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="w-full max-w-5xl flex flex-col items-center text-center space-y-6">
            {/* Phase Badge & Round Counters */}
            <div className="flex flex-wrap items-center justify-center gap-3">
              <div
                className={`px-4 py-1.5 rounded-2xl text-xs sm:text-sm font-black tracking-wider uppercase border shadow-lg ${currentStyles.badge}`}
              >
                {currentStyles.title}
              </div>
              <div className="px-4 py-1.5 rounded-2xl bg-slate-800/80 border border-slate-700 text-slate-200 text-xs sm:text-sm font-extrabold flex items-center gap-2">
                <Users className="w-4 h-4 text-teal-400" />
                <span>
                  Volta <strong className="text-emerald-400">{currentRound}</strong> de{' '}
                  {totalRounds}
                </span>
              </div>
            </div>

            {/* Huge Digital Clock Timer */}
            <div className="relative py-2">
              <div
                className={`text-8xl sm:text-[140px] md:text-[180px] font-black tracking-tighter leading-none font-mono drop-shadow-2xl ${currentStyles.timerText}`}
              >
                {secondsLeft < 10 ? `0${secondsLeft}` : secondsLeft}
              </div>
              <p className="text-xs sm:text-sm text-slate-400 uppercase tracking-widest font-bold mt-2">
                {currentStyles.subtitle}
              </p>
            </div>

            {/* Station Focus Card (Live Station Info) */}
            {currentStation && phase !== 'round_rest' && (
              <div className="w-full max-w-3xl bg-slate-900/90 backdrop-blur border border-slate-800 rounded-3xl p-5 sm:p-6 text-left shadow-2xl space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-3">
                    <span className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 font-black text-sm flex items-center justify-center border border-emerald-500/40">
                      #{currentStationIndex + 1}
                    </span>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        Estação Atual ({currentStationIndex + 1}/{totalStations})
                      </span>
                      <h3 className="text-lg sm:text-xl font-black text-white">
                        {currentStation.name}
                      </h3>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 self-start sm:self-center">
                    {currentStation.videoUrl && (
                      <button
                        type="button"
                        onClick={() =>
                          setActiveVideoModal({
                            url: currentStation.videoUrl!,
                            title: currentStation.name,
                            notes: currentStation.description,
                          })
                        }
                        className="px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 text-xs font-bold flex items-center gap-1.5 transition-all"
                      >
                        <Video className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Ver Vídeo da Estação</span>
                      </button>
                    )}
                    <span className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold">
                      🛠️ {currentStation.equipment || 'Peso Corporal'}
                    </span>
                  </div>
                </div>

                {/* Cues & Next Station Preview */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  {currentStation.description && (
                    <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-300">
                      <span className="text-[10px] font-bold text-emerald-400 uppercase block mb-0.5">
                        💡 Dica de Execução
                      </span>
                      {currentStation.description}
                    </div>
                  )}
                  {nextStation && (
                    <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-400">
                      <span className="text-[10px] font-bold text-cyan-400 uppercase block mb-0.5 flex items-center gap-1">
                        <ArrowRight className="w-3 h-3" /> Próxima Estação (#{nextStationIndex + 1})
                      </span>
                      <span className="font-semibold text-slate-200">{nextStation.name}</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Controls Bar */}
      <div className="px-6 py-5 bg-slate-900/95 backdrop-blur border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Quick Station Navigation */}
        <div className="flex items-center gap-2 order-2 sm:order-1">
          <button
            onClick={handlePrevStation}
            className="p-3 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white transition-all"
            title="Estação Anterior"
          >
            <SkipBack className="w-5 h-5" />
          </button>
          <button
            onClick={handleNextStation}
            className="p-3 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white transition-all"
            title="Próxima Estação"
          >
            <SkipForward className="w-5 h-5" />
          </button>
          <button
            onClick={handleReset}
            className="p-3 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white transition-all"
            title="Reiniciar Circuito do Início"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>

        {/* Central Big Play/Pause Button */}
        <div className="order-1 sm:order-2">
          {isRunning ? (
            <button
              id="btn-circuit-pause"
              onClick={() => setIsRunning(false)}
              className="px-10 py-4 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-base flex items-center gap-3 shadow-xl shadow-amber-500/25 transition-all active:scale-95"
            >
              <Pause className="w-6 h-6" />
              <span>PAUSAR CIRCUITO</span>
            </button>
          ) : (
            <button
              id="btn-circuit-start"
              onClick={() => setIsRunning(true)}
              className="px-10 py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-base flex items-center gap-3 shadow-xl shadow-emerald-500/30 transition-all active:scale-95"
            >
              <Play className="w-6 h-6 fill-current" />
              <span>{phase === 'prepare' ? 'INICIAR CIRCUITO' : 'CONTINUAR'}</span>
            </button>
          )}
        </div>

        {/* Stations Indicator Dots */}
        <div className="flex items-center gap-1.5 order-3">
          {mainStations.map((st, sIdx) => (
            <button
              key={st.id}
              onClick={() => {
                setCurrentStationIndex(sIdx);
                setPhase('work');
                setSecondsLeft(workDuration);
              }}
              className={`w-3.5 h-3.5 rounded-full transition-all ${
                sIdx === currentStationIndex
                  ? 'bg-emerald-400 scale-125 ring-2 ring-emerald-400/50'
                  : sIdx < currentStationIndex
                  ? 'bg-slate-600'
                  : 'bg-slate-800 hover:bg-slate-700'
              }`}
              title={`Ir para Estação ${sIdx + 1}: ${st.name}`}
            />
          ))}
        </div>
      </div>

      {/* Video Modal if Opened */}
      {activeVideoModal && (
        <VideoPlayerModal
          isOpen={true}
          videoUrl={activeVideoModal.url}
          title={activeVideoModal.title}
          notes={activeVideoModal.notes}
          onClose={() => setActiveVideoModal(null)}
        />
      )}
    </div>
  );
};
