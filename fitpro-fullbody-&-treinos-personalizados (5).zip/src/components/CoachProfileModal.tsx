import React, { useState } from 'react';
import {
  ShieldCheck,
  User,
  Phone,
  Award,
  Building,
  FileText,
  X,
  Sparkles,
  Check,
  Mail,
  Instagram,
  CreditCard,
  QrCode,
  Smartphone,
  Eye
} from 'lucide-react';
import { CoachProfile } from '../types';

interface CoachProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  coachProfile: CoachProfile;
  onSaveCoachProfile: (profile: CoachProfile) => void;
}

export const CoachProfileModal: React.FC<CoachProfileModalProps> = ({
  isOpen,
  onClose,
  coachProfile,
  onSaveCoachProfile,
}) => {
  const [name, setName] = useState(coachProfile.name || '');
  const [fullName, setFullName] = useState(coachProfile.fullName || '');
  const [cref, setCref] = useState(coachProfile.cref || '');
  const [phone, setPhone] = useState(coachProfile.phone || '');
  const [email, setEmail] = useState(coachProfile.email || '');
  const [instagram, setInstagram] = useState(coachProfile.instagram || '');
  const [brandOrGym, setBrandOrGym] = useState(coachProfile.brandOrGym || '');
  const [customHeaderTitle, setCustomHeaderTitle] = useState(coachProfile.customHeaderTitle || 'FitPro Trainer');
  const [bio, setBio] = useState(coachProfile.bio || '');
  const [pixKey, setPixKey] = useState(coachProfile.pixKey || '');
  const [pixKeyType, setPixKeyType] = useState<CoachProfile['pixKeyType']>(coachProfile.pixKeyType || 'phone');
  const [consultancyNotes, setConsultancyNotes] = useState(coachProfile.consultancyNotes || '');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveCoachProfile({
      name: name.trim() || 'Prof. Consultor',
      fullName: fullName.trim() || name.trim() || 'Prof. Consultor',
      cref: cref.trim() || '000000-G/UF',
      phone: phone.trim(),
      email: email.trim(),
      instagram: instagram.trim(),
      brandOrGym: brandOrGym.trim() || 'Consultoria Esportiva & Performance',
      customHeaderTitle: customHeaderTitle.trim() || 'FITPRO TRAINER CONSULTORIA',
      bio: bio.trim(),
      pixKey: pixKey.trim(),
      pixKeyType: pixKeyType,
      consultancyNotes: consultancyNotes.trim(),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-5 sm:p-7 max-w-2xl w-full shadow-2xl space-y-5 my-auto max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center font-black shadow-md shadow-emerald-500/20">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-white text-lg font-display">
                Cadastro & Personalização do Professor
              </h3>
              <p className="text-xs text-slate-400">
                Sua identidade profissional exibida automaticamente no app dos seus alunos, PDFs e mensagens
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Identity Card Preview */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-800/90 via-slate-800/60 to-emerald-950/30 border border-emerald-500/30 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-wider font-extrabold text-emerald-400 flex items-center gap-1">
              <Eye className="w-3.5 h-3.5" /> Prévia da Marca no App dos Alunos
            </span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
              CREF {cref || '000000-G/UF'}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-black text-base">
              {(name || 'P').charAt(0)}
            </div>
            <div>
              <p className="text-sm font-bold text-white">{name || 'Seu Nome de Treinador'}</p>
              <p className="text-[11px] text-slate-300">{brandOrGym || 'Nome da sua Consultoria / Assessoria'}</p>
              {instagram && <p className="text-[10px] text-teal-400">{instagram}</p>}
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Main Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Nome Comercial / Como os alunos te chamam *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Prof. Fernando Silva"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-emerald-500 font-semibold"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Nome Completo Oficial (para termos e PDFs)
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Ex: Fernando Henrique Silva de Oliveira"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Registro CREF *
              </label>
              <input
                type="text"
                required
                value={cref}
                onChange={(e) => setCref(e.target.value)}
                placeholder="Ex: 019842-G/SP"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500 font-bold text-emerald-400"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                WhatsApp Oficial com DDD *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Ex: 11988887777"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Instagram (@perfil)
              </label>
              <input
                type="text"
                value={instagram}
                onChange={(e) => setInstagram(e.target.value)}
                placeholder="Ex: @fernando_personal"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Nome da Consultoria / Studio / Marca
              </label>
              <input
                type="text"
                value={brandOrGym}
                onChange={(e) => setBrandOrGym(e.target.value)}
                placeholder="Ex: Consultoria Fernando Personal & Performance"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Email de Atendimento
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Ex: contato@fernandopersonal.com.br"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* PIX Key Section for direct student payments */}
          <div className="p-3.5 rounded-2xl bg-slate-800/70 border border-slate-700 space-y-2">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold">
              <QrCode className="w-4 h-4" />
              <span>Chave PIX do Professor (para recebimento de mensalidades dos alunos)</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div>
                <label className="block text-slate-400 text-[11px] mb-1">Tipo de Chave</label>
                <select
                  value={pixKeyType}
                  onChange={(e) => setPixKeyType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none"
                >
                  <option value="phone">Telefone / Celular</option>
                  <option value="cpf">CPF</option>
                  <option value="cnpj">CNPJ</option>
                  <option value="email">E-mail</option>
                  <option value="random">Chave Aleatória</option>
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="block text-slate-400 text-[11px] mb-1">Chave PIX</label>
                <input
                  type="text"
                  value={pixKey}
                  onChange={(e) => setPixKey(e.target.value)}
                  placeholder="Ex: 11988887777 ou contato@email.com"
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Título do Cabeçalho Principal (topo dos PDFs e Fichas)
            </label>
            <input
              type="text"
              value={customHeaderTitle}
              onChange={(e) => setCustomHeaderTitle(e.target.value)}
              placeholder="Ex: FERNANDO PERSONAL TRAINER • CONSULTORIA ESPORTIVA"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500 font-bold text-slate-200"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Bio / Especialidades do Professor
            </label>
            <input
              type="text"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Ex: Especialista em Biomecânica, Hipertrofia de Glúteos e Emagrecimento Saudável."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Mensagem Padrão de Boas-Vindas & Orientações aos Alunos
            </label>
            <textarea
              rows={2}
              value={consultancyNotes}
              onChange={(e) => setConsultancyNotes(e.target.value)}
              placeholder="Ex: Treine com intensidade controlada, hidrate-se durante o treino e anote suas cargas para progressão constante."
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
            ></textarea>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 font-semibold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400 shadow-lg shadow-emerald-500/25 flex items-center gap-1.5 transition-all"
            >
              <Check className="w-4 h-4" />
              <span>Salvar Cadastro do Professor</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
