import React, { useState, useRef } from 'react';
import {
  Upload,
  Link,
  Plus,
  Trash2,
  Video,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Eye,
  FileVideo,
  Sparkles,
  Dumbbell
} from 'lucide-react';
import { Exercise } from '../types';
import { getVideoEmbedInfo, GOOGLE_DRIVE_VIDEOS_URL } from '../utils/videoUtils';

interface CustomExerciseUploaderProps {
  customExercises: Exercise[];
  onChangeCustomExercises: (exercises: Exercise[]) => void;
  onPreviewVideo?: (url: string, name: string) => void;
}

const MUSCLE_GROUPS = [
  'Quadríceps',
  'Glúteos',
  'Posterior de Coxa',
  'Panturrilhas',
  'Peito',
  'Dorsais / Costas',
  'Ombros / Deltoides',
  'Bíceps',
  'Tríceps',
  'Abdômen / Core',
  'Mobilidade',
  'Aquecimento / Cardio',
];

export const CustomExerciseUploader: React.FC<CustomExerciseUploaderProps> = ({
  customExercises,
  onChangeCustomExercises,
  onPreviewVideo,
}) => {
  const [name, setName] = useState('');
  const [muscleGroup, setMuscleGroup] = useState('Quadríceps');
  const [urlInput, setUrlInput] = useState('');
  const [sets, setSets] = useState(3);
  const [reps, setReps] = useState('10-12');
  const [notes, setNotes] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Analyze URL input in real time for feedback
  const embedInfo = urlInput.trim() ? getVideoEmbedInfo(urlInput.trim()) : null;

  const handleFileUpload = (file: File) => {
    if (!file) return;

    // Suggest name from file if empty
    const cleanFileName = file.name
      .replace(/\.(gif|mp4|webm|mov|m4v)$/i, '')
      .replace(/[-_]/g, ' ')
      .trim();

    if (!name.trim()) {
      setName(cleanFileName);
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      if (dataUrl) {
        setUrlInput(dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files[0]);
    } else {
      const text = e.dataTransfer.getData('text/plain');
      if (text && (text.startsWith('http://') || text.startsWith('https://'))) {
        setUrlInput(text.trim());
      }
    }
  };

  const handleAddExercise = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Por favor, informe o nome do exercício.');
      return;
    }

    const newEx: Exercise = {
      id: `custom-ex-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: name.trim(),
      muscleGroup,
      sets: Number(sets) || 3,
      reps: String(reps || '10-12'),
      suggestedLoadKg: 15,
      userCurrentLoadKg: 15,
      restSeconds: 60,
      technique: 'Tradicional',
      notes: notes.trim() || 'Exercício personalizado inserido pelo professor.',
      videoUrl: urlInput.trim() || undefined,
      videoName: name.trim(),
      isCompleted: false,
    };

    onChangeCustomExercises([...customExercises, newEx]);

    // Reset form
    setName('');
    setUrlInput('');
    setNotes('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveExercise = (id: string) => {
    onChangeCustomExercises(customExercises.filter((ex) => ex.id !== id));
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-md">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-sm">
            +
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span>Exercícios Personalizados & Upload de GIFs / URLs</span>
              {customExercises.length > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold border border-purple-500/30">
                  {customExercises.length} adicionado{customExercises.length > 1 ? 's' : ''}
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-400">
              Adicione exercícios específicos com seu link direto do Google Drive ou faça upload de GIFs do seu computador.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsExpanded(!isExpanded)}
          className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-all border border-slate-700 self-start sm:self-auto"
        >
          {isExpanded ? 'Ocultar Formulário' : '+ Adicionar Exercício Específico'}
        </button>
      </div>

      {/* Form Area */}
      {isExpanded && (
        <form onSubmit={handleAddExercise} className="space-y-4 bg-slate-950/60 p-5 rounded-2xl border border-slate-800">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Nome */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-300">
                Nome do Exercício *
              </label>
              <input
                type="text"
                id="input-custom-ex-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Agachamento Sumô com Halter, Elevação Pélvica..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-purple-500"
                required
              />
            </div>

            {/* Grupo Muscular */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-300">
                Grupo Muscular
              </label>
              <select
                id="select-custom-ex-muscle"
                value={muscleGroup}
                onChange={(e) => setMuscleGroup(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-purple-500"
              >
                {MUSCLE_GROUPS.map((mg) => (
                  <option key={mg} value={mg}>
                    {mg}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* URL / Drag & Drop Upload Zone */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Link className="w-3.5 h-3.5 text-purple-400" />
                <span>URL Direta do GIF / Vídeo (Google Drive ou Web) ou Upload:</span>
              </label>
              <span className="text-[11px] text-slate-400">
                Suporta links <code className="text-purple-300">drive.google.com</code>, <code className="text-purple-300">.gif</code> e arquivos locais
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                id="input-custom-ex-url"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="Cole o link do Google Drive (ex: https://drive.google.com/open?id=... ou https://.../arquivo.gif)"
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-purple-500 font-mono"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-2 border border-slate-700 transition-all shrink-0"
              >
                <Upload className="w-3.5 h-3.5 text-purple-400" />
                <span>Anexar GIF do PC</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/gif,video/mp4,video/webm,image/*"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileUpload(e.target.files[0]);
                  }
                }}
              />
            </div>

            {/* Drag & Drop Visual Area */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-3 text-center transition-all cursor-pointer ${
                isDragging
                  ? 'border-purple-500 bg-purple-950/30'
                  : 'border-slate-800 hover:border-slate-700 bg-slate-900/40'
              }`}
              onClick={() => fileInputRef.current?.click()}
            >
              <p className="text-[11px] text-slate-400">
                Arraste e solte o arquivo <strong className="text-purple-300">.gif</strong> ou vídeo aqui do seu computador
              </p>
            </div>

            {/* URL Status Feedback */}
            {embedInfo && embedInfo.type !== 'none' && (
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-purple-950/30 border border-purple-500/30 text-xs text-purple-200">
                <div className="flex items-center gap-2 truncate">
                  <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                  <span className="truncate">
                    <strong>{embedInfo.providerLabel}</strong> detectado com sucesso.
                  </span>
                </div>
                {onPreviewVideo && (
                  <button
                    type="button"
                    onClick={() => onPreviewVideo(urlInput, name || 'Demonstração')}
                    className="px-2.5 py-1 rounded-lg bg-purple-500 text-slate-950 font-bold text-[11px] flex items-center gap-1 hover:bg-purple-400 shrink-0 ml-2"
                  >
                    <Eye className="w-3 h-3" />
                    <span>Testar Preview</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Séries, Repetições e Observações */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="block text-[11px] font-semibold text-slate-400">Séries</label>
              <input
                type="number"
                min={1}
                max={10}
                value={sets}
                onChange={(e) => setSets(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-purple-500"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-[11px] font-semibold text-slate-400">Repetições</label>
              <input
                type="text"
                value={reps}
                onChange={(e) => setReps(e.target.value)}
                placeholder="Ex: 10-12, 15, Até a falha"
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-purple-500"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-[11px] font-semibold text-slate-400">Instruções / Dica de Execução</label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Ex: Pico de contração de 2s no topo"
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end pt-1">
            <button
              type="submit"
              id="btn-add-custom-exercise-to-list"
              className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-600/20 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Incluir este Exercício no Treino</span>
            </button>
          </div>
        </form>
      )}

      {/* Staged Custom Exercises List */}
      {customExercises.length > 0 ? (
        <div className="space-y-3">
          <p className="text-xs font-bold text-slate-300">
            Exercícios Personalizados que serão incluídos na prescrição:
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {customExercises.map((ex, index) => {
              const info = ex.videoUrl ? getVideoEmbedInfo(ex.videoUrl) : null;
              const hasVideo = info && info.type !== 'none';

              return (
                <div
                  key={ex.id || index}
                  className="p-3.5 rounded-2xl bg-slate-950 border border-purple-500/30 flex items-center justify-between gap-3 shadow-sm hover:border-purple-500/50 transition-all"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center shrink-0">
                      {hasVideo ? (
                        <Video className="w-4 h-4 text-purple-400" />
                      ) : (
                        <Dumbbell className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                    <div className="truncate">
                      <h4 className="text-xs font-bold text-white truncate">{ex.name}</h4>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-purple-300 font-semibold">
                          {ex.muscleGroup}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {ex.sets}x {ex.reps}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {hasVideo && onPreviewVideo && (
                      <button
                        type="button"
                        onClick={() => onPreviewVideo(ex.videoUrl!, ex.name)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-purple-300 transition-all"
                        title="Ver vídeo/GIF"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleRemoveExercise(ex.id)}
                      className="p-1.5 rounded-lg bg-red-950/30 hover:bg-red-900/50 text-red-400 border border-red-800/40 transition-all"
                      title="Remover"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        !isExpanded && (
          <div className="p-3.5 rounded-2xl bg-slate-950/40 border border-dashed border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>
              Nenhum exercício personalizado adicionado ainda. O sistema usará os modelos inteligentes automaticamente.
            </span>
            <button
              type="button"
              onClick={() => setIsExpanded(true)}
              className="text-purple-400 hover:text-purple-300 font-bold underline ml-2 shrink-0"
            >
              Adicionar manual / colar URL
            </button>
          </div>
        )
      )}
    </div>
  );
};
