import React from 'react';
import { Trash2, AlertTriangle, X, UserX, ShieldAlert } from 'lucide-react';
import { Student } from '../types';

interface DeleteStudentModalProps {
  isOpen: boolean;
  student: Student | null;
  onClose: () => void;
  onConfirmDelete: (studentId: string) => void;
}

export const DeleteStudentModal: React.FC<DeleteStudentModalProps> = ({
  isOpen,
  student,
  onClose,
  onConfirmDelete,
}) => {
  if (!isOpen || !student) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl relative text-left">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Warning Icon & Header */}
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center text-xl shadow-lg shadow-rose-500/10 flex-shrink-0">
            <Trash2 className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-rose-400">
              Ação Irreversível
            </span>
            <h2 className="text-lg font-black text-white font-display">
              Excluir Aluno(a)?
            </h2>
          </div>
        </div>

        {/* Student Info Box */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-slate-800 text-slate-200 font-black flex items-center justify-center text-sm">
              {student.name.charAt(0)}
            </div>
            <div>
              <p className="font-extrabold text-sm text-white">{student.name}</p>
              <p className="text-[11px] text-slate-400">
                {student.gender === 'feminino' ? 'Aluna' : 'Aluno'} • {student.age} anos • {student.goal}
              </p>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-850 text-xs text-rose-300/90 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              Todos os treinos personalizados, histórico de cargas, registros antropométricos e link de acesso deste aluno serão apagados permanentemente.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white font-bold text-xs transition-all"
          >
            Cancelar
          </button>
          <button
            type="button"
            id="btn-confirm-delete-student"
            onClick={() => onConfirmDelete(student.id)}
            className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs flex items-center gap-1.5 shadow-lg shadow-rose-600/25 transition-all"
          >
            <Trash2 className="w-4 h-4" />
            <span>Sim, Excluir Aluno</span>
          </button>
        </div>
      </div>
    </div>
  );
};
