import React, { useState, useRef, useMemo } from 'react';
import {
  Video,
  Play,
  UploadCloud,
  FolderOpen,
  Link,
  Trash2,
  Check,
  ExternalLink,
  Edit2,
  Film,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { GOOGLE_DRIVE_VIDEOS_URL, getVideoEmbedInfo } from '../utils/videoUtils';
import { findBestVideoMatch } from '../data/videoLibrary';
import { VideoPlayerModal } from './VideoPlayerModal';
import { VideoLibraryModal } from './VideoLibraryModal';

interface ExerciseVideoSlotProps {
  videoUrl?: string;
  videoName?: string;
  exerciseName: string;
  muscleGroup?: string;
  notes?: string;
  onUpdateVideo?: (videoUrl: string, videoName?: string) => void;
  onRemoveVideo?: () => void;
  isReadOnly?: boolean;
  readOnly?: boolean;
  compact?: boolean;
}

export const ExerciseVideoSlot: React.FC<ExerciseVideoSlotProps> = ({
  videoUrl,
  videoName,
  exerciseName,
  muscleGroup,
  notes,
  onUpdateVideo,
  onRemoveVideo,
  isReadOnly = false,
  readOnly = false,
  compact = false,
}) => {
  const effectiveReadOnly = isReadOnly || readOnly;
  const [isDragging, setIsDragging] = useState(false);
  const [isEditingUrl, setIsEditingUrl] = useState(false);
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [inputUrl, setInputUrl] = useState(videoUrl || '');
  const [inputTitle, setInputTitle] = useState(videoName || '');
  const [isPlayerOpen, setIsPlayerOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const embedInfo = getVideoEmbedInfo(videoUrl);
  const hasVideo = !!videoUrl && videoUrl.trim().length > 0;

  // Smart suggestion calculated from exercise name
  const smartMatch = useMemo(() => {
    if (hasVideo || !exerciseName) return null;
    return findBestVideoMatch(exerciseName);
  }, [hasVideo, exerciseName]);

  // Handle Drag Over
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (effectiveReadOnly) return;
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  // Handle File or Link Drop
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (effectiveReadOnly || !onUpdateVideo) return;

    // 1. Check if dropped files
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('video/') || /\.(mp4|webm|mov|m4v|ogg)$/i.test(file.name)) {
        const reader = new FileReader();
        reader.onload = (loadEvent) => {
          const result = loadEvent.target?.result as string;
          if (result) {
            onUpdateVideo(result, file.name);
          }
        };
        reader.readAsDataURL(file);
        return;
      }
    }

    // 2. Check if dropped text / URL
    const droppedText = e.dataTransfer.getData('text/plain') || e.dataTransfer.getData('text/uri-list');
    if (droppedText && droppedText.trim().startsWith('http')) {
      onUpdateVideo(droppedText.trim(), 'Vídeo Vinculado');
    }
  };

  // Handle Local File Selection via hidden input
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0 && onUpdateVideo) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (loadEvent) => {
        const result = loadEvent.target?.result as string;
        if (result) {
          onUpdateVideo(result, file.name);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Manual URL save
  const handleSaveUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onUpdateVideo) return;
    if (inputUrl.trim()) {
      onUpdateVideo(inputUrl.trim(), inputTitle.trim() || undefined);
    }
    setIsEditingUrl(false);
  };

  // 1-Click Auto-Match trigger
  const handleApplySmartMatch = () => {
    if (smartMatch && onUpdateVideo) {
      onUpdateVideo(smartMatch.videoUrl, smartMatch.videoName);
    }
  };

  // READ-ONLY / STUDENT VIEW OR COMPACT WITH VIDEO
  if (effectiveReadOnly) {
    if (!hasVideo) {
      return (
        <div className="flex items-center gap-2 text-[11px] text-slate-500 italic py-1">
          <Film className="w-3.5 h-3.5 text-slate-600" />
          <span>Sem vídeo anexado pelo professor.</span>
          <a
            href={GOOGLE_DRIVE_VIDEOS_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="text-indigo-400 hover:text-indigo-300 font-bold not-italic ml-auto flex items-center gap-1"
          >
            <FolderOpen className="w-3 h-3" />
            <span>Ver Drive</span>
          </a>
        </div>
      );
    }

    return (
      <>
        <div className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-slate-900/90 border border-emerald-500/30">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0">
              <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white truncate">
                {videoName || 'Vídeo de Demonstração'}
              </p>
              <span className="text-[10px] text-emerald-400 font-semibold">
                {embedInfo.providerLabel}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsPlayerOpen(true)}
            className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all flex-shrink-0"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>Assistir</span>
          </button>
        </div>

        <VideoPlayerModal
          isOpen={isPlayerOpen}
          onClose={() => setIsPlayerOpen(false)}
          videoUrl={videoUrl}
          videoName={videoName}
          exerciseName={exerciseName}
          muscleGroup={muscleGroup}
          notes={notes}
        />
      </>
    );
  }

  // PROFESSOR / COACH INTERACTIVE VIEW
  return (
    <div className="w-full space-y-2">
      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*"
        onChange={handleFileSelect}
        className="hidden"
      />

      {hasVideo && !isEditingUrl ? (
        // STATE A: VIDEO IS ATTACHED
        <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-700/80 hover:border-emerald-500/40 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setIsPlayerOpen(true)}
              className="w-9 h-9 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30 flex items-center justify-center flex-shrink-0 transition-all group"
              title="Assistir vídeo de execução"
            >
              <Play className="w-4 h-4 fill-current ml-0.5 group-hover:scale-110 transition-transform" />
            </button>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  {embedInfo.providerLabel}
                </span>
                <span className="text-[11px] text-slate-200 font-bold truncate">
                  {videoName || 'Vídeo vinculado'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate mt-0.5 font-mono">
                {videoUrl}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 flex-shrink-0 self-end sm:self-auto">
            {/* Play Button */}
            <button
              type="button"
              onClick={() => setIsPlayerOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1 transition-all"
            >
              <Play className="w-3 h-3 fill-current" />
              <span>Ver Vídeo</span>
            </button>

            {/* Replace from Videoteca */}
            <button
              type="button"
              onClick={() => setIsLibraryOpen(true)}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-indigo-300 hover:text-indigo-200 border border-slate-700 transition-all"
              title="Trocar vídeo pela Videoteca"
            >
              <BookOpen className="w-3.5 h-3.5" />
            </button>

            {/* Edit / Replace URL */}
            <button
              type="button"
              onClick={() => {
                setInputUrl(videoUrl || '');
                setInputTitle(videoName || '');
                setIsEditingUrl(true);
              }}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 transition-all"
              title="Editar link ou colar outro vídeo"
            >
              <Edit2 className="w-3.5 h-3.5" />
            </button>

            {/* Open Google Drive Folder */}
            <a
              href={GOOGLE_DRIVE_VIDEOS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-indigo-400 hover:text-indigo-300 border border-slate-700 transition-all"
              title="Abrir pasta de vídeos no Google Drive"
            >
              <FolderOpen className="w-3.5 h-3.5" />
            </a>

            {/* Remove video */}
            {onRemoveVideo && (
              <button
                type="button"
                onClick={onRemoveVideo}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-slate-700 transition-all"
                title="Remover vídeo deste exercício"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      ) : isEditingUrl ? (
        // STATE B: EDITING URL FORM
        <form
          onSubmit={handleSaveUrl}
          className="p-3 rounded-2xl bg-slate-950 border border-indigo-500/40 space-y-2 text-xs"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] font-black uppercase tracking-wider text-indigo-400 flex items-center gap-1">
              <Link className="w-3 h-3" /> Vincular Vídeo ao Exercício
            </span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setIsLibraryOpen(true)}
                className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20"
              >
                <BookOpen className="w-3 h-3" /> Abrir Videoteca
              </button>
              <a
                href={GOOGLE_DRIVE_VIDEOS_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20"
              >
                <FolderOpen className="w-3 h-3" /> Drive
              </a>
            </div>
          </div>

          <div className="space-y-1.5">
            <input
              type="text"
              required
              value={inputUrl}
              onChange={(e) => setInputUrl(e.target.value)}
              placeholder="Cole aqui o link da pasta ou vídeo do Google Drive..."
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-indigo-500 font-mono"
            />
            <input
              type="text"
              value={inputTitle}
              onChange={(e) => setInputTitle(e.target.value)}
              placeholder="Título / Descrição opcional (ex: Execução Correta)"
              className="w-full px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setIsEditingUrl(false)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center gap-1 shadow-md shadow-indigo-600/20"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Salvar Vídeo</span>
            </button>
          </div>
        </form>
      ) : (
        // STATE C: EMPTY DROPZONE WITH SMART AUTO-MATCH & VIDEOTECA
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`relative rounded-2xl border-2 border-dashed p-3 sm:p-3.5 text-center transition-all ${
            isDragging
              ? 'border-indigo-400 bg-indigo-500/20 scale-[1.01]'
              : 'border-slate-800 hover:border-slate-700 bg-slate-950/60'
          }`}
        >
          <div className="flex flex-col lg:flex-row items-center justify-between gap-3 text-left">
            <div className="flex items-center gap-3 min-w-0">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                  isDragging
                    ? 'bg-indigo-500 text-slate-950 font-bold'
                    : 'bg-indigo-500/15 text-indigo-400 border border-indigo-500/30'
                }`}
              >
                <Video className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-xs font-bold text-slate-200">
                    Demonstração em Vídeo
                  </p>
                  {smartMatch && (
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30 flex items-center gap-1 animate-pulse">
                      <Sparkles className="w-2.5 h-2.5" />
                      Vídeo detectado
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-400 truncate">
                  {smartMatch
                    ? `Encontrado: ${smartMatch.videoName}`
                    : 'Vincule automaticamente, selecione da videoteca ou arraste um vídeo'}
                </p>
              </div>
            </div>

            {/* Action buttons inside slot */}
            <div className="flex items-center gap-2 flex-wrap flex-shrink-0 w-full lg:w-auto justify-end">
              {/* SMART AUTO-VINCULAR BUTTON (1-CLICK) */}
              {smartMatch && onUpdateVideo && (
                <button
                  type="button"
                  id={`btn-smart-match-${exerciseName.replace(/\s+/g, '-').toLowerCase()}`}
                  onClick={handleApplySmartMatch}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 text-xs font-black flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all hover:scale-105"
                  title={`Vincular automaticamente o vídeo de "${smartMatch.videoName}"`}
                >
                  <Sparkles className="w-3.5 h-3.5 fill-current" />
                  <span>Auto-Vincular</span>
                </button>
              )}

              {/* Botão de abrir Seletor de Videoteca */}
              <button
                type="button"
                onClick={() => setIsLibraryOpen(true)}
                className="px-2.5 py-1.5 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 text-indigo-300 border border-indigo-500/30 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
                title="Abrir catálogo com mais de 35 vídeos de demonstração"
              >
                <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                <span>Videoteca</span>
              </button>

              {/* Botão de abrir Drive de Vídeos do professor */}
              <a
                href={GOOGLE_DRIVE_VIDEOS_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="px-2 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-indigo-300 border border-slate-700 text-xs font-bold flex items-center gap-1 transition-all"
                title="Abrir acervo de vídeos do professor no Google Drive"
              >
                <FolderOpen className="w-3 h-3 text-indigo-400" />
                <span className="hidden sm:inline">Drive</span>
              </a>

              {/* Botão de colar Link */}
              <button
                type="button"
                onClick={() => {
                  setInputUrl('');
                  setInputTitle('');
                  setIsEditingUrl(true);
                }}
                className="px-2 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 text-xs font-bold flex items-center gap-1 transition-all"
                title="Inserir link manual"
              >
                <Link className="w-3 h-3 text-emerald-400" />
                <span>Link</span>
              </button>

              {/* Botão de upload local */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-slate-200 border border-slate-700 transition-all"
                title="Carregar arquivo de vídeo do computador"
              >
                <UploadCloud className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Video Modal Player */}
      <VideoPlayerModal
        isOpen={isPlayerOpen}
        onClose={() => setIsPlayerOpen(false)}
        videoUrl={videoUrl}
        videoName={videoName}
        exerciseName={exerciseName}
        muscleGroup={muscleGroup}
        notes={notes}
      />

      {/* Video Library Modal */}
      <VideoLibraryModal
        isOpen={isLibraryOpen}
        onClose={() => setIsLibraryOpen(false)}
        onSelectVideo={(url, name) => {
          if (onUpdateVideo) {
            onUpdateVideo(url, name);
          }
        }}
        targetExerciseName={exerciseName}
        targetMuscleGroup={muscleGroup}
      />
    </div>
  );
};

