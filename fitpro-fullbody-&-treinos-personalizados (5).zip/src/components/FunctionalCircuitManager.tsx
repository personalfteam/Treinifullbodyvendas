import React, { useState } from 'react';
import {
  Flame,
  Plus,
  Trash2,
  Copy,
  Clock,
  Users,
  Sparkles,
  Share2,
  Printer,
  Play,
  FolderOpen,
  Video,
  Check,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  HelpCircle,
  Dumbbell,
  Layers,
  ArrowRight,
  Zap
} from 'lucide-react';
import { FunctionalCircuit, CircuitExerciseItem, CoachProfile } from '../types';
import { INITIAL_FUNCTIONAL_CIRCUITS } from '../data/initialCircuits';
import { GOOGLE_DRIVE_VIDEOS_URL } from '../utils/videoUtils';
import { ExerciseVideoSlot } from './ExerciseVideoSlot';
import { exportPlanToPdf, generateWhatsAppCircuitText, openWhatsAppWithText } from '../utils/pdfExport';
import { CircuitTimerModal } from './CircuitTimerModal';
import { PrintableCircuitPdf } from './PrintableCircuitPdf';
import { findBestVideoMatch } from '../data/videoLibrary';

interface FunctionalCircuitManagerProps {
  coachProfile?: CoachProfile;
  onOpenCoachProfile?: () => void;
}

const STORAGE_KEY_CIRCUITS = 'fitpro_functional_circuits_v1';

export const FunctionalCircuitManager: React.FC<FunctionalCircuitManagerProps> = ({
  coachProfile,
}) => {
  // Load circuits from localStorage or initial
  const [circuits, setCircuits] = useState<FunctionalCircuit[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CIRCUITS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_FUNCTIONAL_CIRCUITS;
  });

  const [selectedCircuitId, setSelectedCircuitId] = useState<string>(
    INITIAL_FUNCTIONAL_CIRCUITS[0]?.id || ''
  );

  const [isTimerOpen, setIsTimerOpen] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [copiedWhatsApp, setCopiedWhatsApp] = useState(false);
  const [activeSectionTab, setActiveSectionTab] = useState<'all' | 'warmup' | 'mobility' | 'main'>('all');
  const [autoLinkToast, setAutoLinkToast] = useState<string | null>(null);

  const currentCircuit =
    circuits.find((c) => c.id === selectedCircuitId) || circuits[0] || INITIAL_FUNCTIONAL_CIRCUITS[0];

  // Save to localStorage
  const saveCircuits = (updated: FunctionalCircuit[]) => {
    setCircuits(updated);
    try {
      localStorage.setItem(STORAGE_KEY_CIRCUITS, JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  // Auto-link all exercises in the current circuit
  const handleAutoLinkAllVideos = () => {
    let linkedCount = 0;
    const matchItem = (item: CircuitExerciseItem): CircuitExerciseItem => {
      if (!item.videoUrl) {
        const match = findBestVideoMatch(item.name);
        if (match) {
          linkedCount++;
          return {
            ...item,
            videoUrl: match.videoUrl,
            videoName: match.videoName,
          };
        }
      }
      return item;
    };

    const updated: FunctionalCircuit = {
      ...currentCircuit,
      warmupExercises: currentCircuit.warmupExercises.map(matchItem),
      mobilityExercises: currentCircuit.mobilityExercises.map(matchItem),
      mainExercises: currentCircuit.mainExercises.map(matchItem),
    };

    handleUpdateCurrentCircuit(updated);
    if (linkedCount > 0) {
      setAutoLinkToast(`⚡ ${linkedCount} exercício(s) foram vinculados automaticamente a vídeos!`);
    } else {
      setAutoLinkToast(`⚡ Todos os exercícios deste circuito já possuem vídeos vinculados!`);
    }
    setTimeout(() => setAutoLinkToast(null), 3500);
  };

  // Update current circuit
  const handleUpdateCurrentCircuit = (updated: FunctionalCircuit) => {
    const list = circuits.map((c) => (c.id === updated.id ? updated : c));
    saveCircuits(list);
  };

  // Helper to auto-enrich exercise on creation
  const enrichStation = (ex: CircuitExerciseItem): CircuitExerciseItem => {
    if (ex.videoUrl) return ex;
    const match = findBestVideoMatch(ex.name);
    if (match) {
      return {
        ...ex,
        videoUrl: match.videoUrl,
        videoName: match.videoName,
      };
    }
    return ex;
  };

  // Create new circuit
  const handleCreateNewCircuit = () => {
    const newId = `circuit-${Date.now()}`;
    const newCircuit: FunctionalCircuit = {
      id: newId,
      title: 'Novo Circuito Funcional em Grupo',
      groupCategory: 'Turma Geral',
      objective: 'Condicionamento cardiorrespiratório e força funcional.',
      intensity: 'Intermediário',
      rounds: 3,
      workTimeSeconds: 40,
      transitionTimeSeconds: 15,
      roundRestSeconds: 60,
      estimatedTotalMinutes: 45,
      coachInstructions:
        'Dividir a turma nas estações. Ao apito inicial, todos executam por 40s e trocam de estação nos 15s de transição.',
      warmupExercises: [
        enrichStation({
          id: `w-${Date.now()}-1`,
          stationNumber: 1,
          name: 'Polichinelo Dinâmico + Skipping Baixo',
          targetFocus: 'Aquecimento Cardiorrespiratório',
          equipment: 'Peso Corporal',
          durationOrReps: '45s',
          description: 'Aterrissar suave na ponta dos pés.',
        }),
        enrichStation({
          id: `w-${Date.now()}-2`,
          stationNumber: 2,
          name: 'Corrida Estacionária (Skipping Alto)',
          targetFocus: 'Elevação da Frequência Cardíaca',
          equipment: 'Peso Corporal',
          durationOrReps: '45s',
        }),
      ],
      mobilityExercises: [
        enrichStation({
          id: `m-${Date.now()}-1`,
          stationNumber: 1,
          name: 'Mobilidade de Quadril 90/90 no Solo',
          targetFocus: 'Rotação de Quadril e Glúteos',
          equipment: 'Colchonete',
          durationOrReps: '45s alternando',
        }),
        enrichStation({
          id: `m-${Date.now()}-2`,
          stationNumber: 2,
          name: 'Gato e Vaca (Cat-Cow) para Coluna',
          targetFocus: 'Mobilidade Torácica e Lombar',
          equipment: 'Colchonete',
          durationOrReps: '45s suave',
        }),
      ],
      mainExercises: Array.from({ length: 8 }).map((_, idx) => enrichStation({
        id: `main-${Date.now()}-${idx + 1}`,
        stationNumber: idx + 1,
        name: `Estação ${idx + 1}: ${
          [
            'Kettlebell Swing',
            'Flexão de Braço Dinâmica',
            'Agachamento Goblet',
            'Remada no TRX / Fita',
            'Slam Ball Potência',
            'Prancha com Escalador',
            'Step-Up no Caixote',
            'Corda Naval (Battle Rope)',
          ][idx]
        }`,
        targetFocus: [
          'Cadeia Posterior & Glúteos',
          'Peitoral & Core',
          'Quadríceps & Glúteos',
          'Dorsais & Bíceps',
          'Potência Global & Cardio',
          'Core & Abdômen',
          'Membros Inferiores Unilateral',
          'Condicionamento Metabólico & Ombros',
        ][idx],
        equipment: [
          'Kettlebell',
          'Peso Corporal',
          'Halter / Dumbbell',
          'Fita TRX',
          'Slam Ball',
          'Colchonete',
          'Caixote / Banco',
          'Corda Naval',
        ][idx],
        durationOrReps: '40s de trabalho',
        description: 'Executar com cadência controlada e respiração rítmica.',
        beginnerAlternative: 'Versão adaptada com apoio ou menor carga.',
        advancedAlternative: 'Versão com salto ou sobrecarga progressiva.',
      })),
      createdAt: new Date().toISOString(),
    };

    saveCircuits([newCircuit, ...circuits]);
    setSelectedCircuitId(newId);
  };

  // Duplicate circuit
  const handleDuplicateCircuit = () => {
    const dupId = `circuit-${Date.now()}`;
    const duplicated: FunctionalCircuit = {
      ...currentCircuit,
      id: dupId,
      title: `${currentCircuit.title} (Cópia)`,
      createdAt: new Date().toISOString(),
    };
    saveCircuits([duplicated, ...circuits]);
    setSelectedCircuitId(dupId);
  };

  // Delete circuit
  const handleDeleteCircuit = (id: string) => {
    if (circuits.length <= 1) {
      alert('É necessário manter ao menos um circuito na plataforma.');
      return;
    }
    if (!confirm(`Deseja realmente excluir o circuito "${currentCircuit.title}"?`)) return;
    const filtered = circuits.filter((c) => c.id !== id);
    saveCircuits(filtered);
    setSelectedCircuitId(filtered[0].id);
  };

  // Add exercise to Main Circuit (extends 8 to 9, 10, etc.)
  const handleAddMainStation = () => {
    const nextNumber = currentCircuit.mainExercises.length + 1;
    const newStation: CircuitExerciseItem = enrichStation({
      id: `main-${Date.now()}-${nextNumber}`,
      stationNumber: nextNumber,
      name: `Estação ${nextNumber}: Novo Exercício Funcional`,
      targetFocus: 'Geral / Funcional',
      equipment: 'Peso Corporal ou Acessório',
      durationOrReps: `${currentCircuit.workTimeSeconds}s de trabalho`,
      description: 'Manter alinhamento postural e ritmo constante.',
      beginnerAlternative: 'Adaptação sem impacto.',
      advancedAlternative: 'Sobrecarga ou ritmo acelerado.',
    });

    handleUpdateCurrentCircuit({
      ...currentCircuit,
      mainExercises: [...currentCircuit.mainExercises, newStation],
    });
  };

  // Add Warmup Exercise
  const handleAddWarmupExercise = () => {
    const nextNum = currentCircuit.warmupExercises.length + 1;
    const newEx: CircuitExerciseItem = enrichStation({
      id: `w-${Date.now()}-${nextNum}`,
      stationNumber: nextNum,
      name: `Aquecimento ${nextNum}: Exercício Dinâmico`,
      targetFocus: 'Ativação Cardiorrespiratória',
      equipment: 'Peso Corporal',
      durationOrReps: '45s',
      description: 'Ritmo progressivo e respiração controlada.',
    });

    handleUpdateCurrentCircuit({
      ...currentCircuit,
      warmupExercises: [...currentCircuit.warmupExercises, newEx],
    });
  };

  // Add Mobility Exercise
  const handleAddMobilityExercise = () => {
    const nextNum = currentCircuit.mobilityExercises.length + 1;
    const newEx: CircuitExerciseItem = enrichStation({
      id: `m-${Date.now()}-${nextNum}`,
      stationNumber: nextNum,
      name: `Mobilidade ${nextNum}: Articulação Alvo`,
      targetFocus: 'Mobilidade de Quadril / Coluna / Ombros',
      equipment: 'Colchonete',
      durationOrReps: '45s',
      description: 'Movimento suave explorando amplitude máxima.',
    });

    handleUpdateCurrentCircuit({
      ...currentCircuit,
      mobilityExercises: [...currentCircuit.mobilityExercises, newEx],
    });
  };

  // Remove exercise helper
  const handleRemoveExercise = (
    section: 'warmup' | 'mobility' | 'main',
    exerciseId: string
  ) => {
    if (section === 'main' && currentCircuit.mainExercises.length <= 1) {
      alert('O circuito precisa ter ao menos uma estação.');
      return;
    }

    if (section === 'warmup') {
      handleUpdateCurrentCircuit({
        ...currentCircuit,
        warmupExercises: currentCircuit.warmupExercises.filter((e) => e.id !== exerciseId),
      });
    } else if (section === 'mobility') {
      handleUpdateCurrentCircuit({
        ...currentCircuit,
        mobilityExercises: currentCircuit.mobilityExercises.filter((e) => e.id !== exerciseId),
      });
    } else {
      const remaining = currentCircuit.mainExercises.filter((e) => e.id !== exerciseId);
      // Re-index station numbers
      const reindexed = remaining.map((ex, idx) => ({
        ...ex,
        stationNumber: idx + 1,
      }));
      handleUpdateCurrentCircuit({
        ...currentCircuit,
        mainExercises: reindexed,
      });
    }
  };

  // Update specific exercise field
  const handleUpdateExerciseField = (
    section: 'warmup' | 'mobility' | 'main',
    exerciseId: string,
    field: keyof CircuitExerciseItem,
    value: any
  ) => {
    const updateList = (list: CircuitExerciseItem[]) =>
      list.map((item) => {
        if (item.id === exerciseId) {
          const updatedItem = { ...item, [field]: value };
          // Auto-link video when exercise name changes and no custom video is manually set
          if (field === 'name' && typeof value === 'string' && value.trim().length >= 3) {
            const match = findBestVideoMatch(value);
            if (match && !item.videoUrl) {
              updatedItem.videoUrl = match.videoUrl;
              updatedItem.videoName = match.videoName;
            }
          }
          return updatedItem;
        }
        return item;
      });

    if (section === 'warmup') {
      handleUpdateCurrentCircuit({
        ...currentCircuit,
        warmupExercises: updateList(currentCircuit.warmupExercises),
      });
    } else if (section === 'mobility') {
      handleUpdateCurrentCircuit({
        ...currentCircuit,
        mobilityExercises: updateList(currentCircuit.mobilityExercises),
      });
    } else {
      handleUpdateCurrentCircuit({
        ...currentCircuit,
        mainExercises: updateList(currentCircuit.mainExercises),
      });
    }
  };

  // Export PDF Action
  const handleExportPdf = async () => {
    setIsExportingPdf(true);
    try {
      const fileName = `circuito-${currentCircuit.title.toLowerCase().replace(/\s+/g, '-')}.pdf`;
      await exportPlanToPdf('printable-circuit-pdf-content', fileName);
    } catch (e) {
      console.error(e);
    } finally {
      setIsExportingPdf(false);
    }
  };

  // WhatsApp Broadcast
  const handleShareWhatsApp = () => {
    const text = generateWhatsAppCircuitText(currentCircuit);
    navigator.clipboard.writeText(text);
    setCopiedWhatsApp(true);
    setTimeout(() => setCopiedWhatsApp(false), 2500);
    openWhatsAppWithText(undefined, text);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner & Title Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-orange-500/25 shrink-0">
              <Flame className="w-8 h-8 text-slate-950 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-orange-500/20 text-orange-400 text-[10px] font-black uppercase tracking-wider border border-orange-500/30">
                  Módulo de Treinamento Coletivo
                </span>
                <span className="text-xs text-slate-400">
                  {circuits.length} modelos cadastrados
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white font-display mt-1">
                Circuitos Funcionais para Grupos
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
                Crie treinos com <strong>Aquecimento Geral</strong>, <strong>Mobilidade Articular</strong> e <strong>Treino Principal de 8+ estações</strong> com cronômetro para TV e vídeos demonstrativos.
              </p>
            </div>
          </div>

          {/* Direct Actions */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Auto Link All Videos Button */}
            <button
              id="btn-auto-link-all-circuit-videos"
              onClick={handleAutoLinkAllVideos}
              className="px-3.5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:from-amber-500/30 hover:to-orange-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center gap-2 transition-all hover:scale-[1.02] shadow-sm shadow-amber-500/10"
              title="Vincular automaticamente vídeos da biblioteca a todos os exercícios deste circuito"
            >
              <Zap className="w-4 h-4 text-amber-400 fill-amber-400/30" />
              <span>Auto-Vincular Vídeos</span>
            </button>

            {/* Live TV Timer Trigger */}
            <button
              id="btn-launch-circuit-timer"
              onClick={() => setIsTimerOpen(true)}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition-all hover:scale-[1.02]"
              title="Abrir Cronômetro Interativo para TV da Academia"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Modo TV / Iniciar Timer</span>
            </button>

            {/* Print / Export PDF */}
            <button
              id="btn-export-circuit-pdf"
              onClick={handleExportPdf}
              disabled={isExportingPdf}
              className="px-3.5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-bold flex items-center gap-2 transition-all"
              title="Gerar PDF para imprimir e fixar na academia"
            >
              <Printer className="w-4 h-4 text-cyan-400" />
              <span>{isExportingPdf ? 'Gerando...' : 'Imprimir PDF'}</span>
            </button>

            {/* WhatsApp Text Share */}
            <button
              id="btn-share-circuit-whatsapp"
              onClick={handleShareWhatsApp}
              className="px-3.5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-bold flex items-center gap-2 transition-all"
              title="Copiar texto formatado para o grupo de WhatsApp da turma"
            >
              {copiedWhatsApp ? (
                <Check className="w-4 h-4 text-emerald-400" />
              ) : (
                <Share2 className="w-4 h-4 text-emerald-400" />
              )}
              <span>{copiedWhatsApp ? 'Copiado!' : 'WhatsApp'}</span>
            </button>

            {/* Google Drive Videos */}
            <a
              id="btn-circuit-drive-videos"
              href={GOOGLE_DRIVE_VIDEOS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2.5 rounded-2xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300 text-xs font-bold flex items-center gap-2 transition-all"
              title="Abrir pasta de vídeos de exercícios no Google Drive"
            >
              <FolderOpen className="w-4 h-4 text-indigo-400" />
              <span className="hidden sm:inline">Drive de Vídeos</span>
            </a>

            {/* New Circuit */}
            <button
              id="btn-create-new-circuit"
              onClick={handleCreateNewCircuit}
              className="px-3.5 py-2.5 rounded-2xl bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/40 text-orange-300 text-xs font-bold flex items-center gap-1.5 transition-all"
            >
              <Plus className="w-4 h-4 text-orange-400" />
              <span>Novo Circuito</span>
            </button>
          </div>
        </div>

        {/* Auto Link Toast Banner */}
        {autoLinkToast && (
          <div className="mt-4 p-3 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs sm:text-sm font-semibold flex items-center gap-3 animate-fade-in">
            <Zap className="w-4 h-4 text-amber-400 shrink-0 fill-amber-400" />
            <span>{autoLinkToast}</span>
          </div>
        )}

        {/* Circuit Selector Tabs Pill */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-2 shrink-0">
            Modelos:
          </span>
          {circuits.map((circ) => (
            <button
              key={circ.id}
              onClick={() => setSelectedCircuitId(circ.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-2 ${
                circ.id === currentCircuit.id
                  ? 'bg-orange-500/20 text-orange-300 border border-orange-500/40 shadow-sm'
                  : 'bg-slate-800/80 hover:bg-slate-800 text-slate-400 border border-slate-700/60 hover:text-white'
              }`}
            >
              <Flame
                className={`w-3.5 h-3.5 ${
                  circ.id === currentCircuit.id ? 'text-orange-400' : 'text-slate-500'
                }`}
              />
              <span>{circ.title}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-900/60 text-slate-400">
                {circ.mainExercises.length} estações
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Circuit Parameters & General Settings Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-lg space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="space-y-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400">
              Configurações do Circuito
            </span>
            <input
              type="text"
              value={currentCircuit.title}
              onChange={(e) =>
                handleUpdateCurrentCircuit({ ...currentCircuit, title: e.target.value })
              }
              className="text-xl sm:text-2xl font-black text-white bg-transparent border-b border-transparent hover:border-slate-700 focus:border-emerald-500 focus:outline-none w-full transition-all"
              placeholder="Nome do Circuito Funcional..."
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDuplicateCircuit}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white text-xs font-bold flex items-center gap-1.5 border border-slate-700 transition-all"
              title="Duplicar este circuito como modelo base"
            >
              <Copy className="w-3.5 h-3.5 text-teal-400" />
              <span>Duplicar</span>
            </button>
            <button
              onClick={() => handleDeleteCircuit(currentCircuit.id)}
              className="px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-bold flex items-center gap-1.5 border border-rose-500/30 transition-all"
              title="Excluir este circuito"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Excluir</span>
            </button>
          </div>
        </div>

        {/* Inputs Grid: Category, Objective, Intensity */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-400">Turma / Categoria:</label>
            <input
              type="text"
              value={currentCircuit.groupCategory}
              onChange={(e) =>
                handleUpdateCurrentCircuit({ ...currentCircuit, groupCategory: e.target.value })
              }
              placeholder="Ex: Turma das 07h, Misto, Mulheres..."
              className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-400">Nível de Intensidade:</label>
            <select
              value={currentCircuit.intensity}
              onChange={(e) =>
                handleUpdateCurrentCircuit({
                  ...currentCircuit,
                  intensity: e.target.value as any,
                })
              }
              className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:border-emerald-500"
            >
              <option value="Iniciante">Iniciante (Adaptações leves)</option>
              <option value="Intermediário">Intermediário (Padrão)</option>
              <option value="Avançado">Avançado (Sobrecarga & Potência)</option>
              <option value="Alta Intensidade / HIIT">Alta Intensidade / HIIT</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-400">Objetivo Principal:</label>
            <input
              type="text"
              value={currentCircuit.objective}
              onChange={(e) =>
                handleUpdateCurrentCircuit({ ...currentCircuit, objective: e.target.value })
              }
              placeholder="Ex: Queima calórica e condicionamento"
              className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Intervals & Rounds Timer Parameters */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/70 p-4 rounded-2xl border border-slate-800">
          {/* Voltas / Rounds */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Voltas (Rounds)
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  handleUpdateCurrentCircuit({
                    ...currentCircuit,
                    rounds: Math.max(1, currentCircuit.rounds - 1),
                  })
                }
                className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm"
              >
                -
              </button>
              <span className="text-base font-black text-emerald-400 font-mono w-8 text-center">
                {currentCircuit.rounds}
              </span>
              <button
                type="button"
                onClick={() =>
                  handleUpdateCurrentCircuit({
                    ...currentCircuit,
                    rounds: currentCircuit.rounds + 1,
                  })
                }
                className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm"
              >
                +
              </button>
            </div>
          </div>

          {/* Tempo de Trabalho por Estação */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Ação por Estação
            </span>
            <select
              value={currentCircuit.workTimeSeconds}
              onChange={(e) =>
                handleUpdateCurrentCircuit({
                  ...currentCircuit,
                  workTimeSeconds: Number(e.target.value),
                })
              }
              className="w-full px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs font-bold"
            >
              <option value={30}>30 segundos</option>
              <option value={35}>35 segundos</option>
              <option value={40}>40 segundos (Padrão)</option>
              <option value={45}>45 segundos</option>
              <option value={50}>50 segundos</option>
              <option value={60}>60 segundos (1 min)</option>
            </select>
          </div>

          {/* Troca de Estação / Transição */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Troca / Transição
            </span>
            <select
              value={currentCircuit.transitionTimeSeconds}
              onChange={(e) =>
                handleUpdateCurrentCircuit({
                  ...currentCircuit,
                  transitionTimeSeconds: Number(e.target.value),
                })
              }
              className="w-full px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs font-bold"
            >
              <option value={10}>10 segundos</option>
              <option value={15}>15 segundos (Padrão)</option>
              <option value={20}>20 segundos</option>
              <option value={30}>30 segundos</option>
            </select>
          </div>

          {/* Intervalo entre Voltas */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Pausa entre Voltas
            </span>
            <select
              value={currentCircuit.roundRestSeconds}
              onChange={(e) =>
                handleUpdateCurrentCircuit({
                  ...currentCircuit,
                  roundRestSeconds: Number(e.target.value),
                })
              }
              className="w-full px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs font-bold"
            >
              <option value={45}>45 segundos</option>
              <option value={60}>60 segundos (1 min)</option>
              <option value={75}>75 segundos</option>
              <option value={90}>90 segundos</option>
              <option value={120}>120 segundos (2 min)</option>
            </select>
          </div>
        </div>

        {/* Coach Instructions / Dynamics */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
            <span>Orientações da Turma & Dinâmica de Rotação (Sentido Horário, Duplas, etc.):</span>
          </label>
          <textarea
            rows={2}
            value={currentCircuit.coachInstructions || ''}
            onChange={(e) =>
              handleUpdateCurrentCircuit({
                ...currentCircuit,
                coachInstructions: e.target.value,
              })
            }
            placeholder="Ex: Formar duplas em cada estação. Rotação em sentido horário ao soar o apito..."
            className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
          ></textarea>
        </div>
      </div>

      {/* Sections Filter Tabs (Aquecimento | Mobilidade | Treino Principal 8+ Estações) */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveSectionTab('all')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeSectionTab === 'all'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Visão Completa
        </button>
        <button
          onClick={() => setActiveSectionTab('warmup')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            activeSectionTab === 'warmup'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <span>1. Aquecimento</span>
          <span className="px-1.5 py-0.2 rounded-full bg-slate-800 text-[10px]">
            {currentCircuit.warmupExercises.length}
          </span>
        </button>
        <button
          onClick={() => setActiveSectionTab('mobility')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            activeSectionTab === 'mobility'
              ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <span>2. Mobilidade</span>
          <span className="px-1.5 py-0.2 rounded-full bg-slate-800 text-[10px]">
            {currentCircuit.mobilityExercises.length}
          </span>
        </button>
        <button
          onClick={() => setActiveSectionTab('main')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
            activeSectionTab === 'main'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <span>3. Treino Principal ({currentCircuit.mainExercises.length} Estações)</span>
          <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/30 text-emerald-300 text-[10px] font-black">
            {currentCircuit.mainExercises.length}
          </span>
        </button>
      </div>

      {/* BLOCK 1: AQUECIMENTO GERAL */}
      {(activeSectionTab === 'all' || activeSectionTab === 'warmup') && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-lg space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                🔥
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                  <span>1. Aquecimento Geral Dinâmico</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold">
                    {currentCircuit.warmupExercises.length} exercícios
                  </span>
                </h2>
                <p className="text-xs text-slate-400">
                  Elevação da frequência cardíaca, vasodilatação e preparação neuromuscular.
                </p>
              </div>
            </div>

            <button
              id="btn-add-warmup-exercise"
              onClick={handleAddWarmupExercise}
              className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 transition-all self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Exercício de Aquecimento</span>
            </button>
          </div>

          {/* Warmup Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentCircuit.warmupExercises.map((w, wIdx) => (
              <div
                key={w.id}
                className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3 relative group"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 flex-1">
                    <span className="w-6 h-6 rounded-md bg-amber-500/20 text-amber-300 text-xs font-black flex items-center justify-center">
                      #{wIdx + 1}
                    </span>
                    <input
                      type="text"
                      value={w.name}
                      onChange={(e) =>
                        handleUpdateExerciseField('warmup', w.id, 'name', e.target.value)
                      }
                      placeholder="Nome do aquecimento..."
                      className="font-bold text-white text-sm bg-transparent border-b border-transparent hover:border-slate-700 focus:border-amber-500 focus:outline-none flex-1"
                    />
                  </div>
                  <button
                    onClick={() => handleRemoveExercise('warmup', w.id)}
                    className="p-1 text-slate-500 hover:text-rose-400 opacity-60 group-hover:opacity-100 transition-all"
                    title="Remover aquecimento"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400">Foco / Ativação:</label>
                    <input
                      type="text"
                      value={w.targetFocus}
                      onChange={(e) =>
                        handleUpdateExerciseField('warmup', w.id, 'targetFocus', e.target.value)
                      }
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 text-xs"
                      placeholder="Ex: Cardio & Isquiotibiais"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400">Tempo / Reps:</label>
                    <input
                      type="text"
                      value={w.durationOrReps}
                      onChange={(e) =>
                        handleUpdateExerciseField('warmup', w.id, 'durationOrReps', e.target.value)
                      }
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 text-xs"
                      placeholder="Ex: 45s ou 20 reps"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400">Dica de Execução:</label>
                  <input
                    type="text"
                    value={w.description || ''}
                    onChange={(e) =>
                      handleUpdateExerciseField('warmup', w.id, 'description', e.target.value)
                    }
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-xs"
                    placeholder="Instruções para o aluno..."
                  />
                </div>

                {/* Video Demonstration Slot */}
                <ExerciseVideoSlot
                  videoUrl={w.videoUrl}
                  videoName={w.videoName}
                  exerciseName={w.name}
                  muscleGroup={w.targetFocus}
                  notes={w.description}
                  onUpdateVideo={(url, name) => {
                    handleUpdateExerciseField('warmup', w.id, 'videoUrl', url);
                    handleUpdateExerciseField('warmup', w.id, 'videoName', name);
                  }}
                  onRemoveVideo={() => {
                    handleUpdateExerciseField('warmup', w.id, 'videoUrl', undefined);
                    handleUpdateExerciseField('warmup', w.id, 'videoName', undefined);
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* BLOCK 2: MOBILIDADE ARTICULAR */}
      {(activeSectionTab === 'all' || activeSectionTab === 'mobility') && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-lg space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold">
                🧘
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                  <span>2. Mobilidade Articular & Prevenção</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 font-bold">
                    {currentCircuit.mobilityExercises.length} exercícios
                  </span>
                </h2>
                <p className="text-xs text-slate-400">
                  Liberação e amplitude para tornozelos, quadris, coluna torácica e ombros.
                </p>
              </div>
            </div>

            <button
              id="btn-add-mobility-exercise"
              onClick={handleAddMobilityExercise}
              className="px-3.5 py-2 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 text-xs font-bold flex items-center gap-1.5 transition-all self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Exercício de Mobilidade</span>
            </button>
          </div>

          {/* Mobility Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentCircuit.mobilityExercises.map((m, mIdx) => (
              <div
                key={m.id}
                className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3 relative group"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 flex-1">
                    <span className="w-6 h-6 rounded-md bg-teal-500/20 text-teal-300 text-xs font-black flex items-center justify-center">
                      #{mIdx + 1}
                    </span>
                    <input
                      type="text"
                      value={m.name}
                      onChange={(e) =>
                        handleUpdateExerciseField('mobility', m.id, 'name', e.target.value)
                      }
                      placeholder="Nome do exercício de mobilidade..."
                      className="font-bold text-white text-sm bg-transparent border-b border-transparent hover:border-slate-700 focus:border-teal-500 focus:outline-none flex-1"
                    />
                  </div>
                  <button
                    onClick={() => handleRemoveExercise('mobility', m.id)}
                    className="p-1 text-slate-500 hover:text-rose-400 opacity-60 group-hover:opacity-100 transition-all"
                    title="Remover mobilidade"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400">Articulação / Foco:</label>
                    <input
                      type="text"
                      value={m.targetFocus}
                      onChange={(e) =>
                        handleUpdateExerciseField('mobility', m.id, 'targetFocus', e.target.value)
                      }
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 text-xs"
                      placeholder="Ex: Quadril 90/90 ou Tornozelo"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400">Tempo / Duração:</label>
                    <input
                      type="text"
                      value={m.durationOrReps}
                      onChange={(e) =>
                        handleUpdateExerciseField('mobility', m.id, 'durationOrReps', e.target.value)
                      }
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 text-xs"
                      placeholder="Ex: 45s alternando"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400">Instruções:</label>
                  <input
                    type="text"
                    value={m.description || ''}
                    onChange={(e) =>
                      handleUpdateExerciseField('mobility', m.id, 'description', e.target.value)
                    }
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-xs"
                    placeholder="Instrução postural..."
                  />
                </div>

                {/* Video Demonstration Slot */}
                <ExerciseVideoSlot
                  videoUrl={m.videoUrl}
                  videoName={m.videoName}
                  exerciseName={m.name}
                  muscleGroup={m.targetFocus}
                  notes={m.description}
                  onUpdateVideo={(url, name) => {
                    handleUpdateExerciseField('mobility', m.id, 'videoUrl', url);
                    handleUpdateExerciseField('mobility', m.id, 'videoName', name);
                  }}
                  onRemoveVideo={() => {
                    handleUpdateExerciseField('mobility', m.id, 'videoUrl', undefined);
                    handleUpdateExerciseField('mobility', m.id, 'videoName', undefined);
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* BLOCK 3: TREINO PRINCIPAL EM CIRCUITO (8+ ESTAÇÕES PADRÃO EXPANSÍVEL) */}
      {(activeSectionTab === 'all' || activeSectionTab === 'main') && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-emerald-500/20">
                <Dumbbell className="w-6 h-6 text-slate-950" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg sm:text-xl font-black text-white">
                    3. Treino Principal em Circuito
                  </h2>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-black border border-emerald-500/30">
                    {currentCircuit.mainExercises.length} Estações
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Padrão com <strong>8 estações funcionais</strong> e espaço livre para adicionar mais estações.
                </p>
              </div>
            </div>

            {/* Prominent Add Station Button */}
            <button
              id="btn-add-main-station-top"
              onClick={handleAddMainStation}
              className="px-4 py-2.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-md shadow-emerald-500/20 transition-all self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Estação ({currentCircuit.mainExercises.length + 1})</span>
            </button>
          </div>

          {/* Stations List */}
          <div className="space-y-4">
            {currentCircuit.mainExercises.map((ex, exIdx) => (
              <div
                key={ex.id}
                className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-5 space-y-4 hover:border-slate-700 transition-all relative group"
              >
                {/* Station Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/60 pb-3">
                  <div className="flex items-center gap-3 flex-1">
                    <span className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 text-xs font-black flex items-center justify-center border border-emerald-500/30 shrink-0">
                      #{exIdx + 1}
                    </span>
                    <input
                      type="text"
                      value={ex.name}
                      onChange={(e) =>
                        handleUpdateExerciseField('main', ex.id, 'name', e.target.value)
                      }
                      placeholder="Nome da estação / exercício..."
                      className="font-extrabold text-white text-base sm:text-lg bg-transparent border-b border-transparent hover:border-slate-700 focus:border-emerald-500 focus:outline-none flex-1"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] px-2 py-1 rounded bg-slate-900 text-slate-400 font-bold">
                      Estação {exIdx + 1} de {currentCircuit.mainExercises.length}
                    </span>
                    <button
                      onClick={() => handleRemoveExercise('main', ex.id)}
                      className="p-1.5 text-slate-500 hover:text-rose-400 opacity-60 group-hover:opacity-100 transition-all"
                      title="Excluir esta estação"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Station Attributes Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                      Foco Muscular / Padrão:
                    </label>
                    <input
                      type="text"
                      value={ex.targetFocus}
                      onChange={(e) =>
                        handleUpdateExerciseField('main', ex.id, 'targetFocus', e.target.value)
                      }
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-semibold focus:outline-none focus:border-emerald-500"
                      placeholder="Ex: Cadeia Posterior & Glúteos"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                      Equipamento / Material:
                    </label>
                    <input
                      type="text"
                      value={ex.equipment}
                      onChange={(e) =>
                        handleUpdateExerciseField('main', ex.id, 'equipment', e.target.value)
                      }
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-semibold focus:outline-none focus:border-emerald-500"
                      placeholder="Ex: Kettlebell, TRX, Peso Corporal..."
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                      Tempo de Ação / Reps:
                    </label>
                    <input
                      type="text"
                      value={ex.durationOrReps}
                      onChange={(e) =>
                        handleUpdateExerciseField('main', ex.id, 'durationOrReps', e.target.value)
                      }
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-semibold focus:outline-none focus:border-emerald-500"
                      placeholder="Ex: 40s de trabalho"
                    />
                  </div>
                </div>

                {/* Description & Technical Cues */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Dica Biomecânica / Instrução do Professor:
                  </label>
                  <input
                    type="text"
                    value={ex.description || ''}
                    onChange={(e) =>
                      handleUpdateExerciseField('main', ex.id, 'description', e.target.value)
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-emerald-500"
                    placeholder="Ex: Hinge de quadril explosivo, manter abdômen travado no topo..."
                  />
                </div>

                {/* Adaptations: Beginner & Advanced */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/20 space-y-1">
                    <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">
                      🟢 Adaptação para Aluno Iniciante (Regressão):
                    </span>
                    <input
                      type="text"
                      value={ex.beginnerAlternative || ''}
                      onChange={(e) =>
                        handleUpdateExerciseField('main', ex.id, 'beginnerAlternative', e.target.value)
                      }
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-emerald-200 text-xs"
                      placeholder="Ex: Deadlift sem salto ou apoio com joelhos no chão"
                    />
                  </div>

                  <div className="p-3 rounded-xl bg-rose-950/20 border border-rose-500/20 space-y-1">
                    <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">
                      🔴 Opção para Aluno Avançado (Progressão):
                    </span>
                    <input
                      type="text"
                      value={ex.advancedAlternative || ''}
                      onChange={(e) =>
                        handleUpdateExerciseField('main', ex.id, 'advancedAlternative', e.target.value)
                      }
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-rose-200 text-xs"
                      placeholder="Ex: Salto explosivo com sobrecarga progressiva"
                    />
                  </div>
                </div>

                {/* Video Demonstration Slot (Drag & Drop or Google Drive Link) */}
                <div className="pt-2">
                  <ExerciseVideoSlot
                    videoUrl={ex.videoUrl}
                    videoName={ex.videoName}
                    exerciseName={ex.name}
                    muscleGroup={ex.targetFocus}
                    notes={ex.description}
                    onUpdateVideo={(url, name) => {
                      handleUpdateExerciseField('main', ex.id, 'videoUrl', url);
                      handleUpdateExerciseField('main', ex.id, 'videoName', name);
                    }}
                    onRemoveVideo={() => {
                      handleUpdateExerciseField('main', ex.id, 'videoUrl', undefined);
                      handleUpdateExerciseField('main', ex.id, 'videoName', undefined);
                    }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Bottom Add Station Call to Action Button */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-slate-950 border border-dashed border-slate-750">
            <div className="text-center sm:text-left">
              <h4 className="text-xs font-bold text-white">
                Deseja expandir o circuito para mais estações?
              </h4>
              <p className="text-xs text-slate-400">
                Atualmente com {currentCircuit.mainExercises.length} estações cadastradas.
              </p>
            </div>
            <button
              id="btn-add-main-station-bottom"
              onClick={handleAddMainStation}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Estação #{currentCircuit.mainExercises.length + 1}</span>
            </button>
          </div>
        </div>
      )}

      {/* Offscreen Printable Circuit Container for PDF export and window.print */}
      <div
        className="print:block"
        style={{
          position: 'absolute',
          left: '-9999px',
          top: 0,
          width: '850px',
          backgroundColor: '#ffffff',
          zIndex: -10,
        }}
      >
        <PrintableCircuitPdf circuit={currentCircuit} coachProfile={coachProfile} />
      </div>

      {/* Interactive Circuit Timer Modal */}
      {isTimerOpen && (
        <CircuitTimerModal
          isOpen={isTimerOpen}
          circuit={currentCircuit}
          onClose={() => setIsTimerOpen(false)}
        />
      )}
    </div>
  );
};
