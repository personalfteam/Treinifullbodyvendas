import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  Laptop,
  Check,
  Share2,
  Copy,
  ExternalLink,
  Sparkles,
  Zap,
  WifiOff,
  ShieldCheck,
  X,
  PlusSquare,
  MoreVertical,
  QrCode
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  appName?: string;
  targetRole?: 'coach' | 'student';
  studentShareUrl?: string;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({
  isOpen,
  onClose,
  appName = 'FitPro Treinos',
  targetRole = 'coach',
  studentShareUrl,
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, isDesktop, triggerInstall } =
    usePWAInstall();

  // Selected guide tab
  const [activeTab, setActiveTab] = useState<'android' | 'ios' | 'desktop'>(() => {
    if (isIOS) return 'ios';
    if (isAndroid) return 'android';
    return 'desktop';
  });

  const [copiedLink, setCopiedLink] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  if (!isOpen) return null;

  const currentUrl = studentShareUrl || window.location.href;

  const handleNativeInstall = async () => {
    const success = await triggerInstall();
    if (success) {
      setInstallSuccess(true);
      setTimeout(() => {
        setInstallSuccess(false);
        onClose();
      }, 2000);
    }
  };

  const handleCopyAppUrl = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-6 relative my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-all"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 border-b border-slate-800 pb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Download className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-extrabold text-white font-display">
                Baixar & Instalar App
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                PWA Nativo
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Instale direto no seu <strong>Celular ou Computador</strong> sem precisar de App Store
            </p>
          </div>
        </div>

        {/* Direct One-Click Install Button if supported */}
        {isInstallable && !isInstalled && (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-slate-900 to-teal-950/70 border border-emerald-500/40 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Instalação Automática Disponível!</span>
              </span>
              <span className="text-[10px] text-slate-400">1-Clique</span>
            </div>
            <button
              id="btn-trigger-pwa-install"
              onClick={handleNativeInstall}
              className="w-full py-3.5 px-5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all active:scale-[0.98]"
            >
              <Download className="w-4 h-4" />
              <span>{installSuccess ? 'App Instalado com Sucesso!' : 'Instalar Agora no Dispositivo'}</span>
            </button>
          </div>
        )}

        {isInstalled && (
          <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            <div>
              <p className="font-bold">O aplicativo já está instalado no seu dispositivo!</p>
              <p className="text-[11px] text-slate-400">
                Você pode acessá-lo diretamente pelo ícone na tela inicial ou menu de aplicativos.
              </p>
            </div>
          </div>
        )}

        {/* Device Switcher Tabs */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-300 block">
            Selecione o seu dispositivo para ver o passo a passo:
          </label>
          <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950 rounded-2xl border border-slate-800">
            <button
              onClick={() => setActiveTab('android')}
              className={`py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'android'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Android</span>
            </button>

            <button
              onClick={() => setActiveTab('ios')}
              className={`py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'ios'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>iPhone / iOS</span>
            </button>

            <button
              onClick={() => setActiveTab('desktop')}
              className={`py-2 px-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'desktop'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Laptop className="w-3.5 h-3.5" />
              <span>PC / Mac</span>
            </button>
          </div>
        </div>

        {/* Guided Steps Content */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-3.5 text-xs">
          {activeTab === 'android' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <Smartphone className="w-4 h-4" />
                <span>Como instalar no Android (Google Chrome ou Samsung Internet):</span>
              </div>
              <ol className="space-y-2.5 text-slate-300 list-decimal list-inside leading-relaxed pl-1">
                <li>
                  Toque no menu de <strong>três pontinhos (⋮)</strong> no canto superior direito do navegador.
                </li>
                <li>
                  Procure e selecione a opção <strong>"Instalar aplicativo"</strong> ou <strong>"Adicionar à tela inicial"</strong>.
                </li>
                <li>
                  Confirme em <strong>"Instalar"</strong>. O ícone do FitPro será adicionado instantaneamente à sua tela de início!
                </li>
              </ol>
            </div>
          )}

          {activeTab === 'ios' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <Smartphone className="w-4 h-4" />
                <span>Como instalar no iPhone ou iPad (Safari):</span>
              </div>
              <ol className="space-y-2.5 text-slate-300 list-decimal list-inside leading-relaxed pl-1">
                <li>
                  Abra a página no navegador <strong>Safari</strong> do iPhone.
                </li>
                <li>
                  Toque no botão <strong>Compartilhar</strong> (o ícone de quadrado com uma seta para cima <Share2 className="w-3 h-3 inline text-teal-400" /> na barra inferior).
                </li>
                <li>
                  Role as opções para baixo e toque em <strong>"Adicionar à Tela de Início"</strong> (<PlusSquare className="w-3.5 h-3.5 inline text-emerald-400" />).
                </li>
                <li>
                  Toque em <strong>"Adicionar"</strong> no canto superior direito. Pronto! O app abrirá em tela cheia como um app nativo.
                </li>
              </ol>
            </div>
          )}

          {activeTab === 'desktop' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <Laptop className="w-4 h-4" />
                <span>Como instalar no Computador (Google Chrome, Edge ou Brave):</span>
              </div>
              <ol className="space-y-2.5 text-slate-300 list-decimal list-inside leading-relaxed pl-1">
                <li>
                  No topo do navegador, olhe para a <strong>barra de endereço</strong> e clique no ícone de <strong>instalar app</strong> (<Download className="w-3 h-3 inline text-emerald-400" />) ou nos três pontinhos <strong>⋮</strong>.
                </li>
                <li>
                  Clique em <strong>"Instalar FitPro"</strong>.
                </li>
                <li>
                  O app abrirá em uma janela própria de alta performance, sem barras de navegação!
                </li>
              </ol>
            </div>
          )}
        </div>

        {/* QR Code Section for Scanning on Mobile */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-center gap-4">
          <div className="p-2.5 bg-white rounded-xl shadow-md flex-shrink-0">
            <QRCodeSVG value={currentUrl} size={88} level="M" />
          </div>
          <div className="text-center sm:text-left space-y-1">
            <p className="text-xs font-bold text-white flex items-center justify-center sm:justify-start gap-1.5">
              <QrCode className="w-3.5 h-3.5 text-emerald-400" />
              <span>Instalar pelo Celular via QR Code</span>
            </p>
            <p className="text-[11px] text-slate-400 leading-tight">
              Aponte a câmera do seu celular para este código para abrir o link e instalar diretamente no smartphone.
            </p>
          </div>
        </div>

        {/* Copy App Link Action */}
        <div className="flex items-center gap-2">
          <input
            type="text"
            readOnly
            value={currentUrl}
            className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-300 font-mono focus:outline-none select-all truncate"
          />
          <button
            onClick={handleCopyAppUrl}
            id="btn-copy-install-url"
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md ${
              copiedLink
                ? 'bg-emerald-500 text-slate-950'
                : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
            }`}
          >
            {copiedLink ? (
              <>
                <Check className="w-4 h-4" />
                <span>Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copiar Link</span>
              </>
            )}
          </button>
        </div>

        {/* Value Highlights */}
        <div className="pt-2 border-t border-slate-800/80 grid grid-cols-3 gap-2 text-center text-[10px] text-slate-400">
          <div className="flex flex-col items-center gap-1">
            <Zap className="w-4 h-4 text-amber-400" />
            <span className="font-semibold text-slate-300">Super Rápido</span>
            <span>Sem carregar abas</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <WifiOff className="w-4 h-4 text-teal-400" />
            <span className="font-semibold text-slate-300">Modo Offline</span>
            <span>Acesso mesmo sem sinal</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold text-slate-300">100% Seguro</span>
            <span>Sem gastar memória</span>
          </div>
        </div>
      </div>
    </div>
  );
};
