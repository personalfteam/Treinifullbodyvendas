import React from 'react';
import {
  Dumbbell,
  LineChart,
  Timer,
  Utensils,
  FileText,
  User,
  Sparkles,
  ChevronDown,
  PlusCircle,
  Play,
  Award,
  Smartphone,
  Share2,
  DollarSign,
  ShieldCheck,
  AlertTriangle,
  UserX,
  Download,
  Trash2,
  Video,
  FolderOpen,
  Flame
} from 'lucide-react';
import { Student } from '../types';
import { GOOGLE_DRIVE_VIDEOS_URL } from '../utils/videoUtils';

export type ActiveTab = 'creator' | 'viewer' | 'students' | 'circuits' | 'timer' | 'nutrition' | 'saved_plans';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  students: Student[];
  selectedStudent: Student | null;
  setSelectedStudent: (student: Student | null) => void;
  onNewStudentClick: () => void;
  onDeleteStudent?: (student: Student) => void;
  onOpenCoachProfile?: () => void;
  onOpenStudentPortal?: () => void;
  onOpenShareModal?: () => void;
  onOpenSubscriptionModal?: () => void;
  onOpenInstallAppModal?: () => void;
  isTimerRunning: boolean;
  timerSecondsLeft: number;
  openTimerModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  students,
  selectedStudent,
  setSelectedStudent,
  onNewStudentClick,
  onDeleteStudent,
  onOpenCoachProfile,
  onOpenStudentPortal,
  onOpenShareModal,
  onOpenSubscriptionModal,
  onOpenInstallAppModal,
  isTimerRunning,
  timerSecondsLeft,
  openTimerModal,
}) => {
  const [studentDropdownOpen, setStudentDropdownOpen] = React.useState(false);

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  const getStatusBadge = (st: Student | null) => {
    if (!st) return null;
    if (st.subscriptionStatus === 'canceled') {
      return (
        <span className="flex items-center gap-1 text-[10px] font-bold text-rose-400 bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/30">
          <UserX className="w-3 h-3" /> Bloqueado
        </span>
      );
    }
    if (st.subscriptionStatus === 'pending_payment') {
      return (
        <span className="flex items-center gap-1 text-[10px] font-bold text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/30">
          <AlertTriangle className="w-3 h-3" /> Pendente
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/30">
        <ShieldCheck className="w-3 h-3" /> Ativo
      </span>
    );
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur border-b border-slate-800 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-2">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('creator')}>
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-slate-950 font-black shadow-md shadow-emerald-500/20">
              <Dumbbell className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg sm:text-xl font-extrabold tracking-tight text-white font-display">
                  Fit<span className="text-emerald-400">Pro</span>
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] uppercase font-bold tracking-wider rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Fullbody & Prescrição
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">Plataforma do Educador Físico</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-1.5 lg:gap-2">
            <button
              id="nav-tab-creator"
              onClick={() => setActiveTab('creator')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'creator'
                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>Gerador de Treinos</span>
            </button>

            <button
              id="nav-tab-students"
              onClick={() => setActiveTab('students')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'students'
                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <LineChart className="w-4 h-4 text-teal-400" />
              <span>Alunos & Evolução</span>
            </button>

            <button
              id="nav-tab-circuits"
              onClick={() => setActiveTab('circuits')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'circuits'
                  ? 'bg-orange-500/15 text-orange-300 border border-orange-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Flame className="w-4 h-4 text-orange-400" />
              <span>Circuitos em Grupo</span>
            </button>

            <button
              id="nav-tab-nutrition"
              onClick={() => setActiveTab('nutrition')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'nutrition'
                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Utensils className="w-4 h-4 text-amber-400" />
              <span>Nutrição & TMB</span>
            </button>

            <button
              id="nav-tab-timer"
              onClick={() => setActiveTab('timer')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'timer'
                  ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Timer className="w-4 h-4 text-cyan-400" />
              <span>Cronômetro</span>
            </button>
          </nav>

          {/* Right Action Area */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            {/* Google Drive Video Bank Direct Link */}
            <a
              id="btn-nav-google-drive-videos"
              href={GOOGLE_DRIVE_VIDEOS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-xs font-bold text-indigo-300 transition-all shadow-sm group"
              title="Abrir Banco de Vídeos de Treinos no Google Drive"
            >
              <FolderOpen className="w-3.5 h-3.5 text-indigo-400 group-hover:scale-110 transition-transform" />
              <span className="hidden sm:inline">Drive de Vídeos</span>
              <span className="sm:hidden">Drive</span>
            </a>

            {/* Student Portal Quick Access Link */}
            {onOpenStudentPortal && (
              <button
                id="btn-nav-open-student-portal"
                onClick={onOpenStudentPortal}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-teal-500/20 to-emerald-500/20 hover:from-teal-500/30 hover:to-emerald-500/30 border border-emerald-500/40 text-xs font-bold text-emerald-300 transition-all shadow-sm"
                title="Abrir a Versão do Aluno exatamente como ele vê"
              >
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">App do Aluno</span>
              </button>
            )}

            {/* Download / Install App Button */}
            {onOpenInstallAppModal && (
              <button
                id="btn-nav-install-app"
                onClick={onOpenInstallAppModal}
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-2 rounded-xl bg-gradient-to-r from-emerald-600/20 to-teal-600/20 hover:from-emerald-600/30 hover:to-teal-600/30 border border-emerald-500/40 text-xs font-bold text-emerald-300 transition-all shadow-sm"
                title="Baixar & Instalar App no Celular ou Computador (PWA)"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Baixar App</span>
              </button>
            )}

            {/* Share Student Link Modal Button */}
            {onOpenShareModal && (
              <button
                id="btn-nav-share-student-link"
                onClick={onOpenShareModal}
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs text-slate-200 hover:text-white transition-all"
                title="Enviar App para o Aluno via WhatsApp ou Link com QR Code"
              >
                <Share2 className="w-3.5 h-3.5 text-teal-400" />
                <span className="hidden lg:inline">Enviar Link</span>
              </button>
            )}

            {/* Subscription / Cancel Plan Button */}
            {onOpenSubscriptionModal && selectedStudent && (
              <button
                id="btn-nav-subscription-modal"
                onClick={onOpenSubscriptionModal}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-2 rounded-xl border text-xs font-semibold transition-all ${
                  selectedStudent.subscriptionStatus === 'canceled'
                    ? 'bg-rose-950/60 border-rose-500/50 text-rose-300 hover:bg-rose-900/80'
                    : selectedStudent.subscriptionStatus === 'pending_payment'
                    ? 'bg-amber-950/60 border-amber-500/50 text-amber-300 hover:bg-amber-900/80'
                    : 'bg-slate-800 hover:bg-slate-750 border-slate-700 text-slate-300'
                }`}
                title="Gerenciar mensalidade e status de acesso do aluno (Cancelar / Bloquear)"
              >
                <DollarSign className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden xl:inline">Mensalidade</span>
              </button>
            )}

            {/* Coach Profile & Branding customization */}
            {onOpenCoachProfile && (
              <button
                id="btn-open-coach-profile"
                onClick={onOpenCoachProfile}
                className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-xs text-slate-300 hover:text-white transition-all"
                title="Personalizar Cadastro do Professor / CREF / Marca / PIX"
              >
                <Award className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Meu Perfil & CREF</span>
                <span className="sm:hidden">CREF</span>
              </button>
            )}

            {/* Live Rest Timer Pill if Active */}
            {isTimerRunning && (
              <button
                id="btn-active-timer-badge"
                onClick={openTimerModal}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-bold animate-pulse hover:bg-cyan-900 transition-all shadow-md shadow-cyan-500/20"
                title="Descanso em andamento - Clique para abrir"
              >
                <Timer className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                <span>{formatTime(timerSecondsLeft)}</span>
              </button>
            )}

            {/* Active Student Selector Pill */}
            <div className="relative">
              <button
                id="btn-student-selector-dropdown"
                onClick={() => setStudentDropdownOpen(!studentDropdownOpen)}
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-xs sm:text-sm font-medium text-slate-200 transition-all"
              >
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                  {selectedStudent ? selectedStudent.name.charAt(0) : <User className="w-3.5 h-3.5" />}
                </div>
                <div className="text-left hidden sm:block max-w-[120px] truncate">
                  <div className="flex items-center gap-1">
                    <span className="text-xs text-slate-400">Aluno</span>
                    {getStatusBadge(selectedStudent)}
                  </div>
                  <p className="font-semibold text-white truncate">{selectedStudent?.name || 'Selecionar Aluno'}</p>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {studentDropdownOpen && (
                <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl z-50 p-2 text-xs">
                  <div className="px-3 py-2 border-b border-slate-800 flex items-center justify-between">
                    <span className="font-bold text-slate-300">Lista de Alunos ({students.length})</span>
                    <button
                      onClick={() => {
                        setStudentDropdownOpen(false);
                        onNewStudentClick();
                      }}
                      className="text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-semibold"
                    >
                      <PlusCircle className="w-3.5 h-3.5" /> Novo
                    </button>
                  </div>
                  <div className="max-h-64 overflow-y-auto py-1 space-y-1">
                    {students.map((st) => (
                      <div
                        key={st.id}
                        onClick={() => {
                          setSelectedStudent(st);
                          setStudentDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between transition-all cursor-pointer group ${
                          selectedStudent?.id === st.id
                            ? 'bg-emerald-500/20 text-emerald-300 font-semibold'
                            : 'text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <div className="truncate pr-2 flex-1">
                          <div className="flex items-center gap-1.5">
                            <p className="text-sm font-medium text-white truncate">{st.name}</p>
                            {getStatusBadge(st)}
                          </div>
                          <p className="text-[11px] text-slate-400 truncate">
                            {st.gender === 'feminino' ? 'Fem' : 'Masc'} • {st.age}a • {st.weightKg}kg • R$ {st.monthlyFee || 150}
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          {onDeleteStudent && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setStudentDropdownOpen(false);
                                onDeleteStudent(st);
                              }}
                              className="p-1.5 rounded-md text-slate-500 hover:text-rose-400 hover:bg-rose-500/20 opacity-60 group-hover:opacity-100 transition-all"
                              title={`Excluir ${st.name}`}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {selectedStudent?.id === st.id && (
                            <span className="w-2 h-2 rounded-full bg-emerald-400 flex-shrink-0"></span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Tab Bar */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-800/80 gap-1 text-[11px]">
          <button
            onClick={() => setActiveTab('creator')}
            className={`flex flex-col items-center gap-1 px-2 py-1 rounded-md ${
              activeTab === 'creator' ? 'text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Gerador</span>
          </button>
          <button
            onClick={() => setActiveTab('students')}
            className={`flex flex-col items-center gap-1 px-2 py-1 rounded-md ${
              activeTab === 'students' ? 'text-teal-400 font-bold' : 'text-slate-400'
            }`}
          >
            <LineChart className="w-4 h-4" />
            <span>Alunos</span>
          </button>
          <button
            onClick={() => setActiveTab('circuits')}
            className={`flex flex-col items-center gap-1 px-2 py-1 rounded-md ${
              activeTab === 'circuits' ? 'text-orange-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Flame className="w-4 h-4" />
            <span>Circuitos</span>
          </button>
          <button
            onClick={() => setActiveTab('nutrition')}
            className={`flex flex-col items-center gap-1 px-2 py-1 rounded-md ${
              activeTab === 'nutrition' ? 'text-amber-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Utensils className="w-4 h-4" />
            <span>Dieta</span>
          </button>
          <button
            onClick={() => setActiveTab('timer')}
            className={`flex flex-col items-center gap-1 px-2 py-1 rounded-md ${
              activeTab === 'timer' ? 'text-cyan-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Timer className="w-4 h-4" />
            <span>Cronômetro</span>
          </button>
        </div>
      </div>
    </header>
  );
};
