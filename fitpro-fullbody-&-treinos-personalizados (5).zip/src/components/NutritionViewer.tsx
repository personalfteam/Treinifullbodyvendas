import React from 'react';
import {
  Utensils,
  Flame,
  Droplet,
  PieChart as PieChartIcon,
  Sparkles,
  Clock,
  CheckCircle2,
  Share2,
  FileDown,
  Info,
  Apple,
  Pill
} from 'lucide-react';
import { NutritionPlan, Student } from '../types';
import { openWhatsAppWithText } from '../utils/pdfExport';

interface NutritionViewerProps {
  nutritionPlan: NutritionPlan;
  student: Student;
  onNavigateToWorkout?: () => void;
}

export const NutritionViewer: React.FC<NutritionViewerProps> = ({
  nutritionPlan,
  student,
  onNavigateToWorkout,
}) => {
  const { dailyCalories, tmb, macros, waterIntakeMl, strategy, meals, supplementSuggestions } = nutritionPlan;

  const handleShareDietWhatsApp = () => {
    const lines = [
      `🥗 *PLANO NUTRICIONAL FITPRO - ${student.name.toUpperCase()}*`,
      `📊 *Meta:* ${dailyCalories} kcal/dia (TMB: ${tmb} kcal)`,
      `🥩 *Proteínas:* ${macros.proteinGrams}g | 🍚 *Carboidratos:* ${macros.carbsGrams}g | 🥑 *Gorduras:* ${macros.fatGrams}g`,
      `💧 *Hidratação Diária:* ${(waterIntakeMl / 1000).toFixed(1)}L de água`,
      `💡 _Estratégia: ${strategy}_`,
      ``,
      `*REFEIÇÕES SUGERIDAS:*`,
    ];

    meals.forEach((m) => {
      lines.push(``);
      lines.push(`🍽️ *${m.name}* (${m.time}) - ~${m.calories} kcal [${m.proteinGrams}g Proteína]`);
      m.foods.forEach((f) => lines.push(`  • ${f}`));
      if (m.notes) lines.push(`  _Obs: ${m.notes}_`);
    });

    if (supplementSuggestions?.length > 0) {
      lines.push(``);
      lines.push(`💊 *SUPLEMENTOS INDICADOS:*`);
      supplementSuggestions.forEach((s) => lines.push(`  • ${s}`));
    }

    lines.push(``);
    lines.push(`📲 _Prescrito pelo seu Educador Físico no FitPro_`);

    openWhatsAppWithText(student.phone, lines.join('\n'));
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <Utensils className="w-5 h-5" />
            </span>
            <h1 className="text-2xl font-extrabold text-white font-display">
              Planejamento Nutricional & Dieta
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400">
            Plano alimentar calculado para o gasto metabólico e objetivo de <strong>{student.name}</strong>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-share-diet-whatsapp"
            onClick={handleShareDietWhatsApp}
            className="px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-600/20 transition-all"
          >
            <Share2 className="w-4 h-4" />
            <span>Enviar Dieta via WhatsApp</span>
          </button>
        </div>
      </div>

      {/* Calories & Macros Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Calories */}
        <div className="bg-gradient-to-br from-slate-900 to-amber-950/40 border border-amber-500/30 rounded-3xl p-5 space-y-2 shadow-md">
          <div className="flex items-center justify-between text-amber-400">
            <span className="text-xs font-bold uppercase tracking-wider">Meta Diária</span>
            <Flame className="w-5 h-5" />
          </div>
          <p className="text-3xl font-black text-white font-display">{dailyCalories} <span className="text-sm font-semibold text-slate-400">kcal</span></p>
          <p className="text-xs text-slate-400">
            Taxa Metabólica Basal (TMB): <strong className="text-slate-200">{tmb} kcal</strong>
          </p>
        </div>

        {/* Proteínas */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-2 shadow-md">
          <div className="flex items-center justify-between text-rose-400">
            <span className="text-xs font-bold uppercase tracking-wider">Proteínas</span>
            <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-rose-500/20">{macros.proteinPercentage}%</span>
          </div>
          <p className="text-3xl font-black text-white font-display">{macros.proteinGrams} <span className="text-sm font-semibold text-slate-400">g</span></p>
          <p className="text-xs text-slate-400">
            ~{(macros.proteinGrams / student.weightKg).toFixed(1)}g por kg corporal
          </p>
        </div>

        {/* Carboidratos */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-2 shadow-md">
          <div className="flex items-center justify-between text-amber-400">
            <span className="text-xs font-bold uppercase tracking-wider">Carboidratos</span>
            <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-amber-500/20">{macros.carbsPercentage}%</span>
          </div>
          <p className="text-3xl font-black text-white font-display">{macros.carbsGrams} <span className="text-sm font-semibold text-slate-400">g</span></p>
          <p className="text-xs text-slate-400">
            Energia para contração muscular e glicogênio
          </p>
        </div>

        {/* Gorduras & Água */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-2 shadow-md">
          <div className="flex items-center justify-between text-cyan-400">
            <span className="text-xs font-bold uppercase tracking-wider">Hidratação / Gorduras</span>
            <Droplet className="w-5 h-5" />
          </div>
          <p className="text-3xl font-black text-white font-display">{(waterIntakeMl / 1000).toFixed(1)} <span className="text-sm font-semibold text-slate-400">L água</span></p>
          <p className="text-xs text-slate-400">
            Gorduras boas: <strong className="text-slate-200">{macros.fatGrams}g</strong> ({macros.fatPercentage}%)
          </p>
        </div>
      </div>

      {/* Strategy Banner */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 flex items-start gap-3.5 shadow-md">
        <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
          <Sparkles className="w-4 h-4" />
        </div>
        <div>
          <h3 className="font-bold text-sm text-white">Diretriz Estratégica Nutricional</h3>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 leading-relaxed">{strategy}</p>
        </div>
      </div>

      {/* Meal Plan List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white font-display flex items-center gap-2">
            <Apple className="w-5 h-5 text-emerald-400" />
            <span>Cardápio & Refeições Diárias</span>
          </h2>
          <span className="text-xs text-slate-400">{meals.length} refeições estruturadas</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {meals.map((meal, idx) => (
            <div
              key={meal.id || idx}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-3 shadow-md hover:border-slate-700 transition-all"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <span className="w-7 h-7 rounded-lg bg-slate-800 text-amber-400 font-bold text-xs flex items-center justify-center">
                    {idx + 1}
                  </span>
                  <div>
                    <h3 className="font-bold text-sm text-white">{meal.name}</h3>
                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-500" /> {meal.time}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-bold text-amber-300 block">~{meal.calories} kcal</span>
                  <span className="text-[10px] text-slate-400">{meal.proteinGrams}g proteína</span>
                </div>
              </div>

              {/* Food Items */}
              <ul className="space-y-1.5 text-xs text-slate-300">
                {meal.foods.map((food, fIdx) => (
                  <li key={fIdx} className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold mt-0.5">•</span>
                    <span>{food}</span>
                  </li>
                ))}
              </ul>

              {meal.notes && (
                <p className="text-[11px] text-slate-400 pt-2 border-t border-slate-800/80 leading-relaxed italic">
                  💡 {meal.notes}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Supplement Recommendations */}
      {supplementSuggestions && supplementSuggestions.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-md">
          <h3 className="font-bold text-base text-white font-display flex items-center gap-2">
            <Pill className="w-5 h-5 text-cyan-400" />
            <span>Sugestões de Suplementação Estratégica</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {supplementSuggestions.map((supp, sIdx) => (
              <div
                key={sIdx}
                className="p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/60 text-xs text-slate-300 flex items-start gap-2.5"
              >
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span>{supp}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
