import React from 'react';
import { FunctionalCircuit, CoachProfile } from '../types';

interface PrintableCircuitPdfProps {
  circuit: FunctionalCircuit;
  coachProfile?: CoachProfile;
}

export const PrintableCircuitPdf: React.FC<PrintableCircuitPdfProps> = ({
  circuit,
  coachProfile,
}) => {
  return (
    <div
      id="printable-circuit-pdf-content"
      className="bg-white text-slate-900 font-sans p-8 max-w-[850px] mx-auto text-xs leading-normal"
      style={{ minHeight: '1100px' }}
    >
      {/* Header with Coach Branding */}
      <div className="border-b-2 border-slate-900 pb-4 mb-5 flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl font-black tracking-tight text-slate-950 font-display">
              FIT<span className="text-emerald-600">PRO</span> FUNCTIONAL
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-black text-[10px] tracking-wider uppercase">
              Circuito em Grupo
            </span>
          </div>
          <h1 className="text-lg font-extrabold text-slate-900 mt-1 uppercase">
            {circuit.title}
          </h1>
          <p className="text-slate-600 font-medium text-[11px] mt-0.5">
            🎯 {circuit.objective}
          </p>
        </div>

        {/* Coach Details */}
        <div className="text-right text-[10px] text-slate-600 space-y-0.5">
          <p className="font-extrabold text-slate-900 text-xs">
            {coachProfile?.fullName || coachProfile?.name || 'Prof. Educador Físico'}
          </p>
          <p className="font-bold text-emerald-700">CREF: {coachProfile?.cref || '000000-G/UF'}</p>
          {coachProfile?.brandOrGym && <p>{coachProfile.brandOrGym}</p>}
          {coachProfile?.phone && <p>WhatsApp: {coachProfile.phone}</p>}
          <p className="text-slate-400">Data: {new Date().toLocaleDateString('pt-BR')}</p>
        </div>
      </div>

      {/* Circuit Parameters Grid */}
      <div className="grid grid-cols-4 gap-2.5 mb-5 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-center">
        <div>
          <p className="text-[10px] uppercase font-bold text-slate-500">Turma / Categoria</p>
          <p className="font-black text-slate-900 text-xs mt-0.5">{circuit.groupCategory}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase font-bold text-slate-500">Voltas (Rounds)</p>
          <p className="font-black text-emerald-700 text-sm mt-0.5">{circuit.rounds} Voltas</p>
        </div>
        <div>
          <p className="text-[10px] uppercase font-bold text-slate-500">Trabalho / Troca</p>
          <p className="font-black text-slate-900 text-xs mt-0.5">
            {circuit.workTimeSeconds}s / {circuit.transitionTimeSeconds}s
          </p>
        </div>
        <div>
          <p className="text-[10px] uppercase font-bold text-slate-500">Intervalo de Volta</p>
          <p className="font-black text-slate-900 text-xs mt-0.5">{circuit.roundRestSeconds}s</p>
        </div>
      </div>

      {/* Coach Instructions Banner */}
      {circuit.coachInstructions && (
        <div className="mb-5 p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-950 text-[11px]">
          <span className="font-bold uppercase tracking-wider text-[10px] text-amber-800 block mb-0.5">
            📢 Dinâmica da Turma & Instruções:
          </span>
          {circuit.coachInstructions}
        </div>
      )}

      {/* Section 1: Aquecimento Geral */}
      {circuit.warmupExercises.length > 0 && (
        <div className="mb-5">
          <div className="flex items-center gap-2 border-b border-slate-300 pb-1 mb-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-900">
              1. Aquecimento Geral Dinâmico ({circuit.warmupExercises.length} Exercícios)
            </h2>
          </div>
          <table className="w-full text-left border-collapse border border-slate-200 text-[10.5px]">
            <thead>
              <tr className="bg-slate-100 text-slate-700 uppercase font-bold text-[9.5px]">
                <th className="p-2 border border-slate-200 w-10 text-center">#</th>
                <th className="p-2 border border-slate-200">Exercício</th>
                <th className="p-2 border border-slate-200">Foco / Ativação</th>
                <th className="p-2 border border-slate-200 w-24">Tempo / Reps</th>
              </tr>
            </thead>
            <tbody>
              {circuit.warmupExercises.map((w, idx) => (
                <tr key={w.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                  <td className="p-2 border border-slate-200 text-center font-bold">{idx + 1}</td>
                  <td className="p-2 border border-slate-200 font-bold text-slate-900">
                    {w.name}
                    {w.description && (
                      <span className="block text-[9.5px] font-normal text-slate-600 mt-0.5">
                        {w.description}
                      </span>
                    )}
                  </td>
                  <td className="p-2 border border-slate-200 text-slate-700">{w.targetFocus}</td>
                  <td className="p-2 border border-slate-200 font-bold text-slate-900">
                    {w.durationOrReps}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Section 2: Mobilidade Articular */}
      {circuit.mobilityExercises.length > 0 && (
        <div className="mb-5">
          <div className="flex items-center gap-2 border-b border-slate-300 pb-1 mb-2">
            <span className="w-2.5 h-2.5 rounded-full bg-teal-500"></span>
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-900">
              2. Mobilidade Articular & Prevenção ({circuit.mobilityExercises.length} Exercícios)
            </h2>
          </div>
          <table className="w-full text-left border-collapse border border-slate-200 text-[10.5px]">
            <thead>
              <tr className="bg-slate-100 text-slate-700 uppercase font-bold text-[9.5px]">
                <th className="p-2 border border-slate-200 w-10 text-center">#</th>
                <th className="p-2 border border-slate-200">Exercício de Mobilidade</th>
                <th className="p-2 border border-slate-200">Articulação / Foco</th>
                <th className="p-2 border border-slate-200 w-24">Duração</th>
              </tr>
            </thead>
            <tbody>
              {circuit.mobilityExercises.map((m, idx) => (
                <tr key={m.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                  <td className="p-2 border border-slate-200 text-center font-bold">{idx + 1}</td>
                  <td className="p-2 border border-slate-200 font-bold text-slate-900">
                    {m.name}
                    {m.description && (
                      <span className="block text-[9.5px] font-normal text-slate-600 mt-0.5">
                        {m.description}
                      </span>
                    )}
                  </td>
                  <td className="p-2 border border-slate-200 text-slate-700">{m.targetFocus}</td>
                  <td className="p-2 border border-slate-200 font-bold text-slate-900">
                    {m.durationOrReps}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Section 3: Treino Principal em Circuito (8+ Estações) */}
      <div className="mb-6">
        <div className="flex items-center justify-between border-b-2 border-slate-900 pb-1 mb-2">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-600"></span>
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-900">
              3. Treino Principal em Circuito ({circuit.mainExercises.length} Estações)
            </h2>
          </div>
          <span className="text-[10px] font-extrabold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
            {circuit.rounds}x ({circuit.workTimeSeconds}s trabalho / {circuit.transitionTimeSeconds}s troca)
          </span>
        </div>

        <table className="w-full text-left border-collapse border border-slate-300 text-[10.5px]">
          <thead>
            <tr className="bg-slate-900 text-white uppercase font-bold text-[9.5px]">
              <th className="p-2 border border-slate-700 w-12 text-center">Estação</th>
              <th className="p-2 border border-slate-700">Exercício & Instrução</th>
              <th className="p-2 border border-slate-700 w-36">Foco / Equipamento</th>
              <th className="p-2 border border-slate-700 w-44">Adaptações (Iniciante / Avançado)</th>
            </tr>
          </thead>
          <tbody>
            {circuit.mainExercises.map((ex, idx) => (
              <tr key={ex.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                <td className="p-2.5 border border-slate-200 text-center font-black text-xs text-slate-900 bg-slate-100">
                  #{idx + 1}
                </td>
                <td className="p-2.5 border border-slate-200">
                  <p className="font-extrabold text-slate-950 text-[11px]">{ex.name}</p>
                  {ex.description && (
                    <p className="text-[10px] text-slate-600 mt-0.5 leading-snug">{ex.description}</p>
                  )}
                  {ex.videoUrl && (
                    <p className="text-[9px] font-bold text-indigo-600 mt-0.5">
                      📹 Vídeo de demonstração disponível no sistema
                    </p>
                  )}
                </td>
                <td className="p-2.5 border border-slate-200">
                  <p className="font-bold text-slate-900 text-[10px]">{ex.targetFocus}</p>
                  <p className="text-[9.5px] text-slate-500 mt-0.5 font-medium">
                    🛠️ {ex.equipment || 'Peso Corporal'}
                  </p>
                </td>
                <td className="p-2.5 border border-slate-200 text-[9.5px] space-y-1">
                  {ex.beginnerAlternative && (
                    <p className="text-emerald-800">
                      <span className="font-bold">Iniciante:</span> {ex.beginnerAlternative}
                    </p>
                  )}
                  {ex.advancedAlternative && (
                    <p className="text-rose-800">
                      <span className="font-bold">Avançado:</span> {ex.advancedAlternative}
                    </p>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-[9.5px] text-slate-500">
        <div>
          <p className="font-bold text-slate-700">FitPro - Treinamento Funcional & Prescrição</p>
          <p>Treine com segurança, hidrate-se e respeite o limite de cada aluno.</p>
        </div>
        <div className="text-right font-medium">
          <p>
            {coachProfile?.fullName || coachProfile?.name} • CREF {coachProfile?.cref || '000000-G/UF'}
          </p>
        </div>
      </div>
    </div>
  );
};
