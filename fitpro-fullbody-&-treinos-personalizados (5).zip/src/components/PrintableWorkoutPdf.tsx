import React from 'react';
import { Dumbbell, Utensils, ShieldCheck, CheckSquare, Calendar, User, Heart, Award, QrCode, Phone, Mail } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { WorkoutPlan, Student, CoachProfile } from '../types';

interface PrintableWorkoutPdfProps {
  plan: WorkoutPlan;
  student: Student;
  coachProfile?: CoachProfile;
}

export const PrintableWorkoutPdf: React.FC<PrintableWorkoutPdfProps> = ({ plan, student, coachProfile }) => {
  const brandTitle = coachProfile?.customHeaderTitle || coachProfile?.brandOrGym || 'FITPRO TRAINER';
  const coachName = coachProfile?.name || 'Prof. Educador Físico';
  const coachCref = coachProfile?.cref || 'CREF Registrado';

  // Build direct student URL for the QR code
  const baseUrl = typeof window !== 'undefined' ? window.location.origin + window.location.pathname : '';
  const studentUrl = `${baseUrl}?view=student&studentId=${student.id}`;

  return (
    <div
      id="printable-pdf-document"
      className="bg-white text-slate-900 p-8 sm:p-12 max-w-4xl mx-auto rounded-none shadow-none font-sans print-sheet border border-slate-200"
      style={{ minHeight: '1100px' }}
    >
      {/* Document Header */}
      <div className="border-b-2 border-slate-900 pb-5 flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-xl bg-slate-950 text-white flex items-center justify-center font-black text-xl flex-shrink-0">
            FP
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tight text-slate-950 font-display leading-tight">
              {brandTitle}
            </h1>
            <p className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
              {coachProfile?.brandOrGym || 'Prescrição & Periodização Física Individualizada'}
            </p>
            <p className="text-[11px] text-slate-500 font-medium">
              Responsável Técnico: <strong className="text-slate-900">{coachName}</strong> • {coachCref}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* QR Code for Interactive App */}
          <div className="flex flex-col items-center bg-slate-50 p-2 rounded-xl border border-slate-300">
            <QRCodeSVG value={studentUrl} size={64} level="M" />
            <span className="text-[8px] font-extrabold text-slate-700 mt-1 uppercase tracking-tight">App do Aluno</span>
          </div>

          <div className="text-right text-xs space-y-1">
            <p className="font-extrabold text-slate-950 text-xs">FICHA OFICIAL DE TREINO</p>
            <p className="text-slate-600 text-[11px]">
              Emissão: <strong>{new Date().toLocaleDateString('pt-BR')}</strong>
            </p>
            <span className="inline-block px-2.5 py-0.5 rounded bg-slate-950 text-white text-[10px] font-black uppercase">
              {plan.modality === 'casa' ? 'Treino em Casa' : plan.modality} • {plan.splitType}
            </span>
          </div>
        </div>
      </div>

      {/* Student Biometrics Section */}
      <div className="my-5 p-4 rounded-xl bg-slate-50 border border-slate-300">
        <h2 className="text-xs font-black text-slate-900 uppercase tracking-wider mb-2.5 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
          <User className="w-3.5 h-3.5 text-slate-700" /> Identificação & Dados Biométricos do Aluno
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold">Aluno(a)</span>
            <span className="font-black text-slate-950 text-sm">{student.name}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold">Gênero / Idade</span>
            <span className="font-bold text-slate-900">{student.gender === 'feminino' ? 'Feminino' : 'Masculino'} • {student.age} anos</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold">Peso / Altura</span>
            <span className="font-bold text-slate-900">{student.weightKg} kg • {student.heightCm} cm</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold">Frequência</span>
            <span className="font-bold text-slate-900">{student.frequencyDaysPerWeek}x por semana</span>
          </div>
          <div className="sm:col-span-2">
            <span className="text-slate-500 block text-[10px] uppercase font-bold">Objetivo Principal</span>
            <span className="font-bold text-slate-950">{student.goal}</span>
          </div>
          <div className="sm:col-span-2">
            <span className="text-slate-500 block text-[10px] uppercase font-bold">Nível / Restrições Médicas</span>
            <span className="font-bold text-slate-900">
              {student.level} {student.limitations ? `— Obs: ${student.limitations}` : '— Sem restrições relatadas'}
            </span>
          </div>
        </div>
      </div>

      {/* Strategy Summary / Coach Directive */}
      {(plan.objectiveSummary || plan.coachCustomNotes) && (
        <div className="mb-5 p-3 rounded-xl bg-slate-100 border-l-4 border-slate-950 text-xs text-slate-800 space-y-1">
          {plan.objectiveSummary && (
            <p><strong>Diretriz do Programa:</strong> {plan.objectiveSummary}</p>
          )}
          {plan.coachCustomNotes && (
            <p><strong>Orientações do Treinador:</strong> {plan.coachCustomNotes}</p>
          )}
        </div>
      )}

      {/* Workouts Table */}
      <div className="space-y-6">
        {plan.workouts.map((day, dIdx) => (
          <div key={day.id || dIdx} className="space-y-2 page-break-inside-avoid">
            <div className="flex items-center justify-between bg-slate-950 text-white px-3.5 py-2 rounded-lg">
              <h3 className="font-black text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-white/20 flex items-center justify-center text-[10px]">
                  {day.code || String.fromCharCode(65 + dIdx)}
                </span>
                <span>{day.name}</span>
                <span className="text-slate-300 font-normal lowercase">— {day.focus}</span>
              </h3>
              <span className="text-[11px] font-semibold text-slate-200">
                Descanso sugerido: <strong>{day.suggestedRestSeconds}s</strong>
              </span>
            </div>

            <table className="w-full text-left text-xs border-collapse border border-slate-300">
              <thead>
                <tr className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300 text-[11px]">
                  <th className="p-2 border-r border-slate-300 w-8 text-center">#</th>
                  <th className="p-2 border-r border-slate-300">Exercício / Grupo</th>
                  <th className="p-2 border-r border-slate-300 w-16 text-center">Séries</th>
                  <th className="p-2 border-r border-slate-300 w-20 text-center">Reps</th>
                  <th className="p-2 border-r border-slate-300 w-24 text-center">Carga (kg)</th>
                  <th className="p-2 border-r border-slate-300 w-20 text-center">Descanso</th>
                  <th className="p-2 w-48">Orientações / Técnica</th>
                </tr>
              </thead>
              <tbody>
                {day.exercises.map((ex, eIdx) => (
                  <tr key={ex.id || eIdx} className={eIdx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                    <td className="p-2 border-t border-r border-slate-300 text-center font-bold text-slate-600">
                      {eIdx + 1}
                    </td>
                    <td className="p-2 border-t border-r border-slate-300">
                      <span className="font-bold text-slate-950 block text-xs">{ex.name}</span>
                      <span className="text-[10px] text-slate-500 font-medium">{ex.muscleGroup}</span>
                    </td>
                    <td className="p-2 border-t border-r border-slate-300 text-center font-bold text-slate-900">
                      {ex.sets}x
                    </td>
                    <td className="p-2 border-t border-r border-slate-300 text-center font-bold text-slate-900">
                      {ex.reps}
                    </td>
                    <td className="p-2 border-t border-r border-slate-300 text-center font-extrabold text-slate-950">
                      {ex.userCurrentLoadKg || ex.suggestedLoadKg || 10} kg
                    </td>
                    <td className="p-2 border-t border-r border-slate-300 text-center text-slate-700">
                      {ex.restSeconds}s
                    </td>
                    <td className="p-2 border-t border-slate-300 text-[11px] text-slate-700 leading-tight">
                      {ex.technique && ex.technique !== 'Tradicional' && (
                        <span className="font-extrabold text-slate-950 block text-[10px] uppercase">
                          [{ex.technique}]
                        </span>
                      )}
                      {ex.notes || 'Executar com cadência controlada.'}
                      {ex.videoUrl && (
                        <span className="block text-[9px] font-bold text-slate-600 mt-0.5">
                          📹 Vídeo demonstrativo no App do Aluno
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
      </div>

      {/* Nutrition Plan Section in PDF */}
      {plan.nutritionPlan && (
        <div className="mt-8 pt-6 border-t-2 border-slate-900 space-y-4 page-break-inside-avoid">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-black text-slate-950 uppercase tracking-wide flex items-center gap-1.5">
              <Utensils className="w-4 h-4" /> Planejamento Nutricional Integrado
            </h2>
            <div className="text-xs font-bold text-slate-800">
              Meta: <strong>{plan.nutritionPlan.dailyCalories} kcal</strong> • Água: <strong>{(plan.nutritionPlan.waterIntakeMl / 1000).toFixed(1)}L/dia</strong>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center text-xs p-2.5 rounded-lg bg-slate-100 border border-slate-200">
            <div>
              <span className="text-slate-500 text-[10px] block font-bold uppercase">Proteínas</span>
              <strong className="text-slate-950">{plan.nutritionPlan.macros.proteinGrams}g ({plan.nutritionPlan.macros.proteinPercentage}%)</strong>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block font-bold uppercase">Carboidratos</span>
              <strong className="text-slate-950">{plan.nutritionPlan.macros.carbsGrams}g ({plan.nutritionPlan.macros.carbsPercentage}%)</strong>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block font-bold uppercase">Gorduras</span>
              <strong className="text-slate-950">{plan.nutritionPlan.macros.fatGrams}g ({plan.nutritionPlan.macros.fatPercentage}%)</strong>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            {plan.nutritionPlan.meals.map((meal, mIdx) => (
              <div key={mIdx} className="p-3 rounded-lg border border-slate-200 bg-white">
                <div className="flex justify-between font-bold text-slate-900 border-b border-slate-200 pb-1 mb-1.5">
                  <span>{meal.name} ({meal.time})</span>
                  <span>~{meal.calories} kcal</span>
                </div>
                <ul className="text-[11px] text-slate-700 space-y-0.5">
                  {meal.foods.map((food, fIdx) => (
                    <li key={fIdx}>• {food}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Footer & Signature space */}
      <div className="mt-10 pt-6 border-t-2 border-slate-900 flex items-end justify-between text-xs text-slate-600">
        <div className="space-y-1 max-w-sm">
          <p className="font-extrabold text-slate-900 text-xs">{coachProfile?.brandOrGym || 'FitPro Trainer'}</p>
          <p className="text-[10px] text-slate-500 leading-relaxed">
            {coachProfile?.consultancyNotes || 'Acompanhamento profissional obrigatório para progressão segura de cargas.'}
          </p>
          {coachProfile?.phone && (
            <p className="text-[10px] font-bold text-slate-800">WhatsApp Treinador: {coachProfile.phone}</p>
          )}
          <p className="text-[9px] text-slate-400">
            Aponte a câmera para o QR Code acima para abrir a versão interativa com cronômetro.
          </p>
        </div>
        <div className="text-center w-64">
          <div className="border-b border-slate-400 pb-1 mb-1 font-bold text-slate-900 text-xs">
            {coachName}
          </div>
          <p className="text-[10px] text-slate-700 font-bold">{coachCref}</p>
          <p className="text-[9px] text-slate-400 uppercase tracking-wider">Educador Físico / Responsável Técnico</p>
        </div>
      </div>
    </div>
  );
};

