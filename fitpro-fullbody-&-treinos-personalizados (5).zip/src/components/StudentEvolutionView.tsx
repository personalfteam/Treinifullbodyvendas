import React, { useState } from 'react';
import {
  TrendingUp,
  PlusCircle,
  Calendar,
  Weight,
  User,
  Activity,
  Dumbbell,
  FileText,
  ChevronRight,
  Sparkles,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
  Phone,
  DollarSign,
  Share2,
  Smartphone,
  AlertTriangle,
  UserX,
  Trash2
} from 'lucide-react';
import {
  LineChart as ReLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  AreaChart,
  Area
} from 'recharts';
import { Student, EvolutionRecord, WorkoutPlan } from '../types';

interface StudentEvolutionViewProps {
  students: Student[];
  selectedStudent: Student | null;
  onSelectStudent: (student: Student) => void;
  onAddNewStudent: () => void;
  onDeleteStudent?: (student: Student) => void;
  onAddEvolutionRecord: (studentId: string, record: EvolutionRecord) => void;
  onLoadPlan: (plan: WorkoutPlan) => void;
  onOpenShareModal?: (student: Student) => void;
  onOpenSubscriptionModal?: (student: Student) => void;
  onOpenStudentPortal?: (studentId: string) => void;
}

export const StudentEvolutionView: React.FC<StudentEvolutionViewProps> = ({
  students,
  selectedStudent,
  onSelectStudent,
  onAddNewStudent,
  onDeleteStudent,
  onAddEvolutionRecord,
  onLoadPlan,
  onOpenShareModal,
  onOpenSubscriptionModal,
  onOpenStudentPortal,
}) => {
  const [showAddRecordModal, setShowAddRecordModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // New Record Form State
  const [recDate, setRecDate] = useState(new Date().toISOString().split('T')[0]);
  const [recWeight, setRecWeight] = useState(selectedStudent?.weightKg || 65);
  const [recBodyFat, setRecBodyFat] = useState<number | undefined>(undefined);
  const [recSquat, setRecSquat] = useState<number | undefined>(undefined);
  const [recLegPress, setRecLegPress] = useState<number | undefined>(undefined);
  const [recBench, setRecBench] = useState<number | undefined>(undefined);
  const [recDeadlift, setRecDeadlift] = useState<number | undefined>(undefined);
  const [recHip, setRecHip] = useState<number | undefined>(undefined);
  const [recWaist, setRecWaist] = useState<number | undefined>(undefined);
  const [recThigh, setRecThigh] = useState<number | undefined>(undefined);
  const [recNotes, setRecNotes] = useState('');

  const currentStudent = selectedStudent || students[0];

  const filteredStudents = students.filter((s) =>
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.goal.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const historyData = (currentStudent?.evolutionHistory || []).map((h) => ({
    date: h.date ? new Date(h.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) : 'Data',
    peso: h.weightKg,
    gordura: h.bodyFatPercent,
    agachamento: h.squatMaxKg,
    legPress: h.legPressMaxKg,
    supino: h.benchPressMaxKg,
    terra: h.deadliftMaxKg,
    quadril: h.hipCm,
    cintura: h.waistCm,
    coxa: h.thighCm,
  }));

  const handleSaveRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentStudent) return;

    const newRecord: EvolutionRecord = {
      id: `rec-${Date.now()}`,
      date: recDate,
      weightKg: Number(recWeight) || currentStudent.weightKg,
      bodyFatPercent: recBodyFat ? Number(recBodyFat) : undefined,
      squatMaxKg: recSquat ? Number(recSquat) : undefined,
      legPressMaxKg: recLegPress ? Number(recLegPress) : undefined,
      benchPressMaxKg: recBench ? Number(recBench) : undefined,
      deadliftMaxKg: recDeadlift ? Number(recDeadlift) : undefined,
      hipCm: recHip ? Number(recHip) : undefined,
      waistCm: recWaist ? Number(recWaist) : undefined,
      thighCm: recThigh ? Number(recThigh) : undefined,
      notes: recNotes.trim(),
    };

    onAddEvolutionRecord(currentStudent.id, newRecord);
    setShowAddRecordModal(false);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-teal-500/20 text-teal-400">
              <TrendingUp className="w-5 h-5" />
            </span>
            <h1 className="text-2xl font-extrabold text-white font-display">
              Evolução & Acompanhamento de Alunos
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400">
            Acompanhe o histórico de cargas, peso corporal e medidas antropométricas em gráficos interativos.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-add-new-student-modal"
            onClick={onAddNewStudent}
            className="px-4 py-2.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition-all"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Cadastrar Novo Aluno</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Student List Sidebar + Detail Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* SIDEBAR: Students List */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-md h-fit">
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-sm text-white">Alunos ({students.length})</h2>
            <input
              type="text"
              placeholder="Buscar aluno..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 w-36"
            />
          </div>

          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {filteredStudents.map((st) => (
              <div
                key={st.id}
                onClick={() => onSelectStudent(st)}
                className={`w-full text-left p-3 rounded-2xl border transition-all flex items-center justify-between cursor-pointer group ${
                  currentStudent?.id === st.id
                    ? 'bg-emerald-500/15 border-emerald-500/50 text-white shadow-sm'
                    : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800/80'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm flex-shrink-0">
                    {st.name.charAt(0)}
                  </div>
                  <div className="truncate">
                    <p className="font-bold text-sm text-white truncate">{st.name}</p>
                    <p className="text-[11px] text-slate-400 truncate">
                      {st.gender === 'feminino' ? 'Fem' : 'Masc'} • {st.age}a • {st.weightKg}kg • {st.goal}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {onDeleteStudent && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteStudent(st);
                      }}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/20 opacity-70 group-hover:opacity-100 transition-all"
                      title={`Excluir aluno ${st.name}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                  <ChevronRight className="w-4 h-4 text-slate-500" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* MAIN PANEL: Current Student Evolution & Charts */}
        {currentStudent ? (
          <div className="lg:col-span-2 space-y-6">
            {/* Student Profile Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-md">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 text-slate-950 font-black flex items-center justify-center text-lg shadow-md">
                    {currentStudent.name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-black text-white font-display">{currentStudent.name}</h2>
                      {currentStudent.subscriptionStatus === 'canceled' ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center gap-1">
                          <UserX className="w-3 h-3" /> Bloqueado / Cancelado
                        </span>
                      ) : currentStudent.subscriptionStatus === 'pending_payment' ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" /> Mensalidade Pendente
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" /> Plano Ativo
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400">
                      {currentStudent.level} • {currentStudent.frequencyDaysPerWeek}x na semana • {currentStudent.goal} • R$ {currentStudent.monthlyFee || 150}/mês
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
                  {onOpenSubscriptionModal && (
                    <button
                      id="btn-evolution-manage-subscription"
                      onClick={() => onOpenSubscriptionModal(currentStudent)}
                      className={`px-3.5 py-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all ${
                        currentStudent.subscriptionStatus === 'canceled'
                          ? 'bg-rose-950/60 border-rose-500/50 text-rose-300 hover:bg-rose-900'
                          : currentStudent.subscriptionStatus === 'pending_payment'
                          ? 'bg-amber-950/60 border-amber-500/50 text-amber-300 hover:bg-amber-900'
                          : 'bg-slate-800 hover:bg-slate-750 text-amber-300 border-slate-700'
                      }`}
                      title="Gerenciar mensalidade, cancelar ou desbloquear plano"
                    >
                      <DollarSign className="w-3.5 h-3.5" />
                      <span>{currentStudent.subscriptionStatus === 'canceled' ? 'Desbloquear / Reativar' : 'Cancelar / Mensalidade'}</span>
                    </button>
                  )}

                  {onOpenShareModal && (
                    <button
                      id="btn-evolution-share-student-link"
                      onClick={() => onOpenShareModal(currentStudent)}
                      className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all"
                      title="Enviar link do app para o aluno"
                    >
                      <Share2 className="w-3.5 h-3.5 text-teal-400" />
                      <span>Link do Aluno</span>
                    </button>
                  )}

                  {onOpenStudentPortal && (
                    <button
                      id="btn-evolution-test-student-portal"
                      onClick={() => onOpenStudentPortal(currentStudent.id)}
                      className="px-3.5 py-2 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/40 text-teal-300 text-xs font-bold flex items-center gap-1.5 transition-all"
                      title="Ver como o aluno visualiza o app"
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>Ver App</span>
                    </button>
                  )}

                  <button
                    id="btn-open-add-evolution-record"
                    onClick={() => setShowAddRecordModal(true)}
                    className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/20"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Nova Medição</span>
                  </button>

                  {onDeleteStudent && (
                    <button
                      id="btn-evolution-delete-student"
                      onClick={() => onDeleteStudent(currentStudent)}
                      className="p-2 sm:px-3 sm:py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-400 text-xs font-bold flex items-center gap-1.5 transition-all"
                      title="Excluir este aluno do sistema"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Excluir Aluno</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Bio Metric Pill Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-3 text-center">
                  <span className="text-[10px] text-slate-400 block">Peso Atual</span>
                  <span className="text-base font-black text-white">{currentStudent.weightKg} kg</span>
                </div>
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-3 text-center">
                  <span className="text-[10px] text-slate-400 block">Altura</span>
                  <span className="text-base font-black text-white">{currentStudent.heightCm} cm</span>
                </div>
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-3 text-center">
                  <span className="text-[10px] text-slate-400 block">IMC Estimado</span>
                  <span className="text-base font-black text-emerald-400">
                    {(currentStudent.weightKg / Math.pow(currentStudent.heightCm / 100, 2)).toFixed(1)}
                  </span>
                </div>
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-3 text-center">
                  <span className="text-[10px] text-slate-400 block">Registros Históricos</span>
                  <span className="text-base font-black text-white">{currentStudent.evolutionHistory.length}</span>
                </div>
              </div>

              {currentStudent.limitations && (
                <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-start gap-2">
                  <span className="font-bold">Observações / Restrições:</span>
                  <span>{currentStudent.limitations}</span>
                </div>
              )}
            </div>

            {/* CHART 1: Evolução de Cargas de Exercícios (kg) */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-md">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-base text-white font-display">
                    Progressão de Cargas Máximas (kg)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Evolução da força em exercícios chave ao longo das avaliações
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-400 text-xs font-bold flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" /> Sobrecarga Progressiva
                </span>
              </div>

              <div className="h-64 sm:h-72 w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <ReLineChart data={historyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} unit="kg" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderColor: '#334155',
                        borderRadius: '16px',
                        color: '#f8fafc',
                        fontSize: '12px',
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                    <Line
                      type="monotone"
                      dataKey="agachamento"
                      name="Agachamento (kg)"
                      stroke="#10b981"
                      strokeWidth={3}
                      dot={{ r: 4, fill: '#10b981' }}
                    />
                    <Line
                      type="monotone"
                      dataKey="legPress"
                      name="Leg Press (kg)"
                      stroke="#06b6d4"
                      strokeWidth={2}
                      dot={{ r: 4, fill: '#06b6d4' }}
                    />
                    <Line
                      type="monotone"
                      dataKey="supino"
                      name="Supino (kg)"
                      stroke="#f59e0b"
                      strokeWidth={2}
                      dot={{ r: 4, fill: '#f59e0b' }}
                    />
                    <Line
                      type="monotone"
                      dataKey="terra"
                      name="Lev. Terra (kg)"
                      stroke="#ec4899"
                      strokeWidth={2}
                      dot={{ r: 4, fill: '#ec4899' }}
                    />
                  </ReLineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* CHART 2: Peso Corporal (kg) e % Gordura */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-md">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-base text-white font-display">
                    Composição Corporal: Peso (kg) & Gordura (%)
                  </h3>
                  <p className="text-xs text-slate-400">Acompanhamento das oscilações antropométricas</p>
                </div>
              </div>

              <div className="h-60 sm:h-64 w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={historyData}>
                    <defs>
                      <linearGradient id="colorPeso" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} domain={['dataMin - 3', 'dataMax + 3']} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderColor: '#334155',
                        borderRadius: '16px',
                        color: '#f8fafc',
                        fontSize: '12px',
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                    <Area
                      type="monotone"
                      dataKey="peso"
                      name="Peso Corporal (kg)"
                      stroke="#10b981"
                      fillOpacity={1}
                      fill="url(#colorPeso)"
                      strokeWidth={3}
                    />
                    <Line
                      type="monotone"
                      dataKey="gordura"
                      name="% Gordura Corporal"
                      stroke="#f43f5e"
                      strokeWidth={2}
                      dot={{ r: 4 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Medidas Antropométricas Table / Cards */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-md">
              <h3 className="font-bold text-base text-white font-display">Histórico de Medições</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left text-slate-300">
                  <thead className="bg-slate-800/80 text-slate-400 uppercase font-semibold">
                    <tr>
                      <th className="p-3 rounded-l-xl">Data</th>
                      <th className="p-3">Peso</th>
                      <th className="p-3">% Gordura</th>
                      <th className="p-3">Agachamento</th>
                      <th className="p-3">Leg Press</th>
                      <th className="p-3">Quadril / Cintura</th>
                      <th className="p-3 rounded-r-xl">Anotações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {currentStudent.evolutionHistory.map((rec) => (
                      <tr key={rec.id} className="hover:bg-slate-800/40">
                        <td className="p-3 font-semibold text-white">{rec.date}</td>
                        <td className="p-3 font-bold text-emerald-400">{rec.weightKg} kg</td>
                        <td className="p-3">{rec.bodyFatPercent ? `${rec.bodyFatPercent}%` : '-'}</td>
                        <td className="p-3">{rec.squatMaxKg ? `${rec.squatMaxKg} kg` : '-'}</td>
                        <td className="p-3">{rec.legPressMaxKg ? `${rec.legPressMaxKg} kg` : '-'}</td>
                        <td className="p-3">
                          {rec.hipCm ? `${rec.hipCm}cm` : '-'} / {rec.waistCm ? `${rec.waistCm}cm` : '-'}
                        </td>
                        <td className="p-3 text-slate-400 truncate max-w-[160px]">{rec.notes || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : (
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center text-slate-400 space-y-3">
            <User className="w-12 h-12 mx-auto text-slate-600" />
            <p className="text-base font-bold text-slate-300">Nenhum aluno selecionado</p>
            <p className="text-xs max-w-sm mx-auto">
              Selecione um aluno na lista ao lado ou cadastre um novo para visualizar o gráfico de evolução de cargas.
            </p>
          </div>
        )}
      </div>

      {/* MODAL: Nova Medição / Carga */}
      {showAddRecordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 my-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base">
                Registrar Evolução: {currentStudent?.name}
              </h3>
              <button
                onClick={() => setShowAddRecordModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveRecord} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Data da Medição</label>
                  <input
                    type="date"
                    required
                    value={recDate}
                    onChange={(e) => setRecDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Peso Corporal (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={recWeight}
                    onChange={(e) => setRecWeight(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">% Gordura Estimado</label>
                  <input
                    type="number"
                    step="0.1"
                    placeholder="Ex: 22.5"
                    value={recBodyFat || ''}
                    onChange={(e) => setRecBodyFat(e.target.value ? Number(e.target.value) : undefined)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Carga Agachamento (kg)</label>
                  <input
                    type="number"
                    placeholder="Ex: 40"
                    value={recSquat || ''}
                    onChange={(e) => setRecSquat(e.target.value ? Number(e.target.value) : undefined)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Carga Leg Press (kg)</label>
                  <input
                    type="number"
                    placeholder="Ex: 120"
                    value={recLegPress || ''}
                    onChange={(e) => setRecLegPress(e.target.value ? Number(e.target.value) : undefined)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Carga Supino Reto (kg)</label>
                  <input
                    type="number"
                    placeholder="Ex: 60"
                    value={recBench || ''}
                    onChange={(e) => setRecBench(e.target.value ? Number(e.target.value) : undefined)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Quadril (cm)</label>
                  <input
                    type="number"
                    step="0.5"
                    placeholder="Ex: 100"
                    value={recHip || ''}
                    onChange={(e) => setRecHip(e.target.value ? Number(e.target.value) : undefined)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Cintura (cm)</label>
                  <input
                    type="number"
                    step="0.5"
                    placeholder="Ex: 70"
                    value={recWaist || ''}
                    onChange={(e) => setRecWaist(e.target.value ? Number(e.target.value) : undefined)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Observações da Avaliação</label>
                <textarea
                  rows={2}
                  value={recNotes}
                  onChange={(e) => setRecNotes(e.target.value)}
                  placeholder="Ex: Aluna aumentou 10kg no agachamento mantendo execução limpa."
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                ></textarea>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddRecordModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400 shadow-md"
                >
                  Salvar Medição
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
