import React, { useState } from 'react';
import { User, X, PlusCircle, Sparkles, Trash2 } from 'lucide-react';
import { Student, Gender, FitnessLevel, PrimaryGoal } from '../types';

interface StudentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (student: Student) => void;
  onDelete?: (student: Student) => void;
  initialStudent?: Student | null;
}

export const StudentModal: React.FC<StudentModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  initialStudent,
}) => {
  const [name, setName] = useState(initialStudent?.name || '');
  const [gender, setGender] = useState<Gender>(initialStudent?.gender || 'feminino');
  const [age, setAge] = useState<number>(initialStudent?.age || 26);
  const [weightKg, setWeightKg] = useState<number>(initialStudent?.weightKg || 62);
  const [heightCm, setHeightCm] = useState<number>(initialStudent?.heightCm || 165);
  const [level, setLevel] = useState<FitnessLevel>(initialStudent?.level || 'Iniciante');
  const [goal, setGoal] = useState<PrimaryGoal>(initialStudent?.goal || 'Hipertrofia de Membros Inferiores');
  const [frequencyDays, setFrequencyDays] = useState<number>(initialStudent?.frequencyDaysPerWeek || 3);
  const [phone, setPhone] = useState(initialStudent?.phone || '');
  const [limitations, setLimitations] = useState(initialStudent?.limitations || '');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const student: Student = {
      id: initialStudent?.id || `student-${Date.now()}`,
      name: name.trim(),
      gender,
      age: Number(age) || 25,
      weightKg: Number(weightKg) || 60,
      heightCm: Number(heightCm) || 165,
      level,
      goal,
      frequencyDaysPerWeek: Number(frequencyDays) || 3,
      phone: phone.trim(),
      limitations: limitations.trim(),
      createdAt: initialStudent?.createdAt || new Date().toISOString(),
      evolutionHistory: initialStudent?.evolutionHistory || [
        {
          id: `evo-init-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          weightKg: Number(weightKg) || 60,
          notes: 'Cadastro inicial do aluno.',
        },
      ],
    };

    onSave(student);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-6 my-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">
                {initialStudent ? 'Editar Cadastro de Aluno' : 'Cadastrar Novo Aluno'}
              </h3>
              <p className="text-xs text-slate-400">Dados biométricos e anamnese</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Nome Completo *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Beatriz Lima"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Gênero</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as Gender)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
              >
                <option value="feminino">Feminino</option>
                <option value="masculino">Masculino</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Idade</label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Peso (kg)</label>
              <input
                type="number"
                step="0.1"
                value={weightKg}
                onChange={(e) => setWeightKg(Number(e.target.value))}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Altura (cm)</label>
              <input
                type="number"
                value={heightCm}
                onChange={(e) => setHeightCm(Number(e.target.value))}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Nível de Treino</label>
              <select
                value={level}
                onChange={(e) => setLevel(e.target.value as FitnessLevel)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
              >
                <option value="Iniciante">Iniciante</option>
                <option value="Intermediário">Intermediário</option>
                <option value="Avançado">Avançado</option>
                <option value="Atleta">Atleta</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Frequência Semanal</label>
              <select
                value={frequencyDays}
                onChange={(e) => setFrequencyDays(Number(e.target.value))}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
              >
                <option value={2}>2 dias</option>
                <option value={3}>3 dias</option>
                <option value={4}>4 dias</option>
                <option value={5}>5 dias</option>
                <option value={6}>6 dias</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Objetivo Principal</label>
            <select
              value={goal}
              onChange={(e) => setGoal(e.target.value as PrimaryGoal)}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
            >
              <option value="Hipertrofia de Membros Inferiores">Hipertrofia de Membros Inferiores</option>
              <option value="Hipertrofia Geral">Hipertrofia Geral</option>
              <option value="Emagrecimento & Queima de Gordura">Emagrecimento & Queima de Gordura</option>
              <option value="Força Bruta e Potência">Força Bruta e Potência</option>
              <option value="Mobilidade Articular e Flexibilidade">Mobilidade Articular e Flexibilidade</option>
              <option value="Condicionamento Físico & Resistência">Condicionamento Físico & Resistência</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">WhatsApp (com DDD)</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Ex: 11999998888"
              className="w-full px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Limitações / Lesões</label>
            <textarea
              rows={2}
              value={limitations}
              onChange={(e) => setLimitations(e.target.value)}
              placeholder="Ex: Dor no joelho direito, sem agachamento profundo..."
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
            ></textarea>
          </div>

          <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-800">
            {initialStudent && onDelete ? (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onDelete(initialStudent);
                }}
                className="px-3.5 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-bold flex items-center gap-1.5 transition-all"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Excluir Aluno</span>
              </button>
            ) : (
              <div></div>
            )}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 font-semibold text-xs"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400 shadow-md text-xs"
              >
                Salvar Aluno
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
