import React, { useState, useEffect } from 'react';
import {
  Dumbbell,
  Utensils,
  TrendingUp,
  MessageCircle,
  Play,
  CheckCircle2,
  Timer,
  Calendar,
  AlertTriangle,
  Lock,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Award,
  Flame,
  Droplets,
  RotateCcw,
  Check,
  ChevronRight,
  ExternalLink,
  ChevronDown,
  Info,
  Download,
  FileDown,
  Printer
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line
} from 'recharts';
import {
  Student,
  WorkoutPlan,
  WorkoutDay,
  Exercise,
  CoachProfile
} from '../types';
import { InstallAppModal } from './InstallAppModal';
import { PrintableWorkoutPdf } from './PrintableWorkoutPdf';
import { exportPlanToPdf } from '../utils/pdfExport';
import { ExerciseVideoSlot } from './ExerciseVideoSlot';

interface StudentPortalViewProps {
  student: Student;
  plan: WorkoutPlan;
  coachProfile: CoachProfile;
  onSwitchToCoachView?: () => void;
  onUpdateExerciseLoad: (dayId: string, exerciseId: string, loadKg: number) => void;
  onStartSession?: (day: WorkoutDay) => void;
  isCoachPreview?: boolean;
  studentsList?: Student[];
  onSelectStudent?: (studentId: string) => void;
}

export const StudentPortalView: React.FC<StudentPortalViewProps> = ({
  student,
  plan,
  coachProfile,
  onSwitchToCoachView,
  onUpdateExerciseLoad,
  onStartSession,
  isCoachPreview = false,
  studentsList = [],
  onSelectStudent,
}) => {
  const [activeTab, setActiveTab] = useState<'workout' | 'nutrition' | 'evolution' | 'coach'>('workout');
  const [selectedDayCode, setSelectedDayCode] = useState<string>(
    plan.workouts[0]?.code || 'A'
  );
  const [waterIntakeMl, setWaterIntakeMl] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`fitpro_student_water_${student.id}`);
      return saved ? Number(saved) : 1250;
    } catch (e) {
      return 1250;
    }
  });

  const [completedExercises, setCompletedExercises] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem(`fitpro_student_completed_${student.id}`);
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  });

  const [studentLoads, setStudentLoads] = useState<Record<string, number>>({});

  useEffect(() => {
    localStorage.setItem(`fitpro_student_water_${student.id}`, waterIntakeMl.toString());
  }, [waterIntakeMl, student.id]);

  useEffect(() => {
    localStorage.setItem(`fitpro_student_completed_${student.id}`, JSON.stringify(completedExercises));
  }, [completedExercises, student.id]);

  const isBlocked = student.subscriptionStatus === 'canceled' || student.subscriptionStatus === 'pending_payment';

  const currentWorkoutDay =
    plan.workouts.find((w) => w.code === selectedDayCode) || plan.workouts[0] || null;

  const toggleExerciseCheck = (exId: string) => {
    setCompletedExercises((prev) => ({
      ...prev,
      [exId]: !prev[exId],
    }));
  };

  const handleAddWater = (amount: number) => {
    setWaterIntakeMl((prev) => Math.min(6000, Math.max(0, prev + amount)));
  };

  const handleSendWhatsAppToCoach = (customMsg?: string) => {
    const coachPhone = (coachProfile.phone || '').replace(/\D/g, '');
    let msg = customMsg || `Olá *${coachProfile.name}*! Sou o(a) *${student.name}* do app de treinos. `;
    if (isBlocked) {
      msg += `Gostaria de falar sobre minha mensalidade para liberar o acesso aos meus treinos e dieta!`;
    } else {
      msg += `Gostaria de tirar uma dúvida sobre a ficha de *${plan.title}*.`;
    }
    const url = coachPhone
      ? `https://wa.me/55${coachPhone}?text=${encodeURIComponent(msg)}`
      : `https://wa.me/?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  // Evolution chart data
  const historyData = (student.evolutionHistory || []).map((h) => ({
    date: h.date ? new Date(h.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) : 'Data',
    peso: h.weightKg,
    gordura: h.bodyFatPercent,
    agachamento: h.squatMaxKg,
    legPress: h.legPressMaxKg,
    supino: h.benchPressMaxKg,
    terra: h.deadliftMaxKg,
  }));

  // Target water calculation
  const targetWaterMl = plan.nutritionPlan?.waterIntakeMl || Math.round(student.weightKg * 35);
  const waterProgress = Math.min(100, Math.round((waterIntakeMl / targetWaterMl) * 100));

  const [copiedPix, setCopiedPix] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  const handleDownloadPdf = async () => {
    setIsExportingPdf(true);
    try {
      await exportPlanToPdf('printable-pdf-document', `Treino-${student.name.replace(/\s+/g, '_')}.pdf`);
    } catch (err) {
      console.error('Error generating PDF for student:', err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleCopyPix = () => {
    if (coachProfile.pixKey) {
      navigator.clipboard.writeText(coachProfile.pixKey);
      setCopiedPix(true);
      setTimeout(() => setCopiedPix(false), 2500);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased selection:bg-emerald-500 selection:text-slate-950 pb-20">
      {/* Top Banner: Only show Coach controls if in Coach Preview mode */}
      {isCoachPreview ? (
        <div className="bg-slate-900 border-b border-slate-800 px-4 py-2.5">
          <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-slate-300 font-medium">
                👨‍🏫 <strong>Modo Prévia do Treinador</strong> • Simulando Visão do Aluno
              </span>
            </div>

            <div className="flex items-center gap-2">
              {studentsList.length > 1 && onSelectStudent && (
                <select
                  value={student.id}
                  onChange={(e) => onSelectStudent(e.target.value)}
                  className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg px-2 py-1 focus:outline-none"
                >
                  {studentsList.map((st) => (
                    <option key={st.id} value={st.id}>
                      Ver aluno: {st.name} ({st.subscriptionStatus === 'canceled' ? 'Cancelado' : st.subscriptionStatus === 'pending_payment' ? 'Pendente' : 'Ativo'})
                    </option>
                  ))}
                </select>
              )}

              {onSwitchToCoachView && (
                <button
                  id="btn-return-coach-mode"
                  onClick={onSwitchToCoachView}
                  className="px-3 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5 transition-all"
                >
                  <span>👨‍🏫 Voltar ao Painel do Professor</span>
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-900/80 border-b border-slate-800/80 px-4 py-2">
          <div className="max-w-4xl mx-auto flex items-center justify-between text-[11px] text-slate-400">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>📱 <strong>Área do Aluno FitPro</strong> • Acesso Individual & Protegido</span>
            </div>
            <span className="text-slate-500 font-mono hidden sm:inline">
              Prescrito por {coachProfile.name}
            </span>
          </div>
        </div>
      )}

      {/* Student App Main Header */}
      <header className="bg-slate-900/90 backdrop-blur-md border-b border-slate-800 sticky top-0 z-30 shadow-md">
        <div className="max-w-4xl mx-auto px-4 py-3.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 font-black flex items-center justify-center text-lg shadow-md shadow-emerald-500/20">
                {student.name.charAt(0)}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base sm:text-lg font-black text-white font-display">
                    {student.name}
                  </h1>
                  {isBlocked ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                      Plano Suspenso
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      Plano Ativo
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 flex items-center gap-1">
                  <span>Treinador:</span>
                  <strong className="text-slate-200">{coachProfile.name}</strong>
                  <span className="text-slate-500">• CREF {coachProfile.cref}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* PDF Print/Download for Student */}
              <button
                id="btn-student-download-pdf"
                onClick={handleDownloadPdf}
                disabled={isExportingPdf}
                className="p-2.5 sm:px-3 sm:py-2 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
                title="Baixar ou Imprimir Ficha de Treino em PDF"
              >
                <FileDown className={`w-4 h-4 text-teal-400 ${isExportingPdf ? 'animate-bounce' : ''}`} />
                <span className="hidden sm:inline">{isExportingPdf ? 'Gerando...' : 'PDF Ficha'}</span>
              </button>

              {/* Install App button for student */}
              <button
                id="btn-student-install-app"
                onClick={() => setIsInstallModalOpen(true)}
                className="p-2.5 sm:px-3 sm:py-2 rounded-xl bg-gradient-to-r from-emerald-600/20 to-teal-600/20 hover:from-emerald-600/30 hover:to-teal-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
                title="Instalar App no seu Celular ou Computador"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span className="hidden sm:inline">Baixar App</span>
              </button>

              {/* Direct WhatsApp to coach button */}
              <button
                onClick={() => handleSendWhatsAppToCoach()}
                className="p-2.5 sm:px-3.5 sm:py-2 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/30 text-[#25D366] text-xs font-bold flex items-center gap-1.5 transition-all"
                title="Falar com meu treinador no WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
                <span className="hidden sm:inline">WhatsApp Treinador</span>
              </button>
            </div>
          </div>

          {/* Real-time Update Notification Pill */}
          {!isBlocked && (
            <div className="mt-3 py-1.5 px-3 rounded-xl bg-emerald-950/40 border border-emerald-500/20 text-[11px] text-emerald-300 flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>
                  Ficha sincronizada em tempo real com seu professor <strong>{coachProfile.name}</strong>
                </span>
              </span>
              <span className="text-[10px] text-emerald-400/80 font-mono hidden sm:inline">
                {plan.workouts.length} treinos configurados
              </span>
            </div>
          )}
        </div>
      </header>

      {/* IF BLOCKED: DISPLAY POLITE SUBSCRIPTION / LOCKOUT SCREEN */}
      {isBlocked ? (
        <main className="max-w-lg mx-auto px-4 py-12 text-center space-y-6 flex-1 flex flex-col justify-center">
          <div className="w-20 h-20 rounded-3xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center mx-auto text-3xl shadow-xl shadow-rose-500/10">
            <Lock className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <span className="px-3 py-1 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold uppercase tracking-wider">
              Acesso Temporariamente Pausado
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
              Mensalidade de Treinos Pendente
            </h2>
            <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
              Olá <strong className="text-white">{student.name}</strong>, o acesso à sua ficha de treinos e planejamento nutricional está temporariamente suspenso pelo seu treinador <strong>{coachProfile.name}</strong>.
            </p>
          </div>

          {student.cancellationReason && (
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-400 space-y-1 text-left">
              <span className="font-bold text-slate-300 block">Mensagem da Consultoria:</span>
              <p className="text-rose-300 font-medium">{student.cancellationReason}</p>
            </div>
          )}

          {student.monthlyFee && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800/80 to-slate-900 border border-slate-700 text-xs text-center space-y-1">
              <span className="text-slate-400">Valor da Mensalidade:</span>
              <p className="text-xl font-black text-emerald-400">R$ {student.monthlyFee},00</p>
              <p className="text-[11px] text-slate-400">Vencimento todo dia {student.dueDay || 10}</p>
            </div>
          )}

          {/* Direct PIX Key Payment for Student */}
          {coachProfile.pixKey && (
            <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/30 text-xs text-left space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-400 flex items-center gap-1.5">
                  <span>🔑 Chave PIX do Professor para Pagamento</span>
                </span>
                <span className="text-[10px] text-slate-400 uppercase font-mono">
                  {coachProfile.pixKeyType || 'PIX'}
                </span>
              </div>
              <div className="flex items-center gap-2 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <span className="font-mono text-emerald-400 text-xs truncate flex-1 font-bold">
                  {coachProfile.pixKey}
                </span>
                <button
                  onClick={handleCopyPix}
                  className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold transition-all flex items-center gap-1"
                >
                  {copiedPix ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : null}
                  <span>{copiedPix ? 'Copiado!' : 'Copiar PIX'}</span>
                </button>
              </div>
              <p className="text-[10px] text-slate-400">
                Após efetuar a transferência, envie o comprovante no WhatsApp abaixo para liberação imediata.
              </p>
            </div>
          )}

          <div className="space-y-3 pt-2">
            <button
              id="btn-student-contact-coach-whatsapp"
              onClick={() => handleSendWhatsAppToCoach('Olá professor! Gostaria de regularizar minha mensalidade da consultoria de treinos para liberar meu acesso ao app.')}
              className="w-full py-4 px-6 rounded-2xl bg-[#25D366] hover:bg-[#20bd5a] text-slate-950 font-black text-sm flex items-center justify-center gap-2.5 shadow-lg shadow-[#25D366]/20 transition-all"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Enviar Comprovante / Falar no WhatsApp</span>
            </button>

            {isCoachPreview && onSwitchToCoachView && (
              <button
                onClick={onSwitchToCoachView}
                className="w-full py-2.5 px-4 rounded-xl text-xs text-slate-400 hover:text-slate-200 transition-all"
              >
                (Painel do Professor: clique aqui para reativar o aluno)
              </button>
            )}
          </div>
        </main>
      ) : (
        /* ACTIVE APP CONTENT */
        <main className="max-w-4xl mx-auto px-4 py-6 space-y-6 flex-1 w-full">
          {/* Navigation Tabs for Student */}
          <div className="grid grid-cols-4 gap-1.5 sm:gap-2 bg-slate-900/90 p-1.5 rounded-2xl border border-slate-800">
            <button
              id="student-tab-workout"
              onClick={() => setActiveTab('workout')}
              className={`py-2.5 px-2 rounded-xl text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-2 transition-all ${
                activeTab === 'workout'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Dumbbell className="w-4 h-4" />
              <span>Meu Treino</span>
            </button>

            <button
              id="student-tab-nutrition"
              onClick={() => setActiveTab('nutrition')}
              className={`py-2.5 px-2 rounded-xl text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-2 transition-all ${
                activeTab === 'nutrition'
                  ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Utensils className="w-4 h-4" />
              <span>Dieta & Água</span>
            </button>

            <button
              id="student-tab-evolution"
              onClick={() => setActiveTab('evolution')}
              className={`py-2.5 px-2 rounded-xl text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-2 transition-all ${
                activeTab === 'evolution'
                  ? 'bg-teal-400 text-slate-950 shadow-md shadow-teal-400/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>Evolução</span>
            </button>

            <button
              id="student-tab-coach"
              onClick={() => setActiveTab('coach')}
              className={`py-2.5 px-2 rounded-xl text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-2 transition-all ${
                activeTab === 'coach'
                  ? 'bg-cyan-400 text-slate-950 shadow-md shadow-cyan-400/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>Treinador</span>
            </button>
          </div>

          {/* TAB 1: WORKOUT TAB */}
          {activeTab === 'workout' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              {/* Workout Meta Summary Card */}
              <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                      {plan.modality.toUpperCase()} • DIVISÃO {plan.splitType}
                    </span>
                    <h2 className="text-xl sm:text-2xl font-black text-white font-display">
                      {plan.title}
                    </h2>
                    <p className="text-xs text-slate-300 max-w-xl">
                      {plan.objectiveSummary}
                    </p>
                  </div>

                  {currentWorkoutDay && (
                    <button
                      id="btn-student-start-active-workout"
                      onClick={() => onStartSession(currentWorkoutDay)}
                      className="px-6 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition-all transform hover:scale-[1.02]"
                    >
                      <Play className="w-4 h-4 fill-current" />
                      <span>Iniciar Treino com Cronômetro</span>
                    </button>
                  )}
                </div>

                {/* Day selector buttons */}
                <div className="pt-2 border-t border-slate-800/80 flex flex-wrap gap-2">
                  {plan.workouts.map((wDay) => (
                    <button
                      key={wDay.id}
                      onClick={() => setSelectedDayCode(wDay.code)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
                        selectedDayCode === wDay.code
                          ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                      }`}
                    >
                      <span className="w-5 h-5 rounded-md bg-slate-950/20 flex items-center justify-center text-[11px]">
                        {wDay.code}
                      </span>
                      <span>{wDay.name}</span>
                      <span className="text-[10px] opacity-75">({wDay.exercises.length} ex)</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Day focus & Coach Notes */}
              {currentWorkoutDay && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-base font-bold text-white flex items-center gap-2">
                        <span>{currentWorkoutDay.name}</span>
                        <span className="text-xs text-slate-400 font-normal">
                          • Foco: <strong className="text-emerald-300">{currentWorkoutDay.focus}</strong>
                        </span>
                      </h3>
                      <p className="text-xs text-slate-400">
                        Marque os exercícios conforme concluir e ajuste suas cargas reais.
                      </p>
                    </div>

                    <span className="text-xs text-slate-400 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl font-medium">
                      ⏱️ Descanso: {currentWorkoutDay.suggestedRestSeconds}s
                    </span>
                  </div>

                  {/* Exercises Cards */}
                  <div className="space-y-3">
                    {currentWorkoutDay.exercises.map((ex, index) => {
                      const isDone = completedExercises[ex.id];
                      return (
                        <div
                          key={ex.id}
                          className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                            isDone
                              ? 'bg-slate-900/60 border-emerald-500/40 opacity-80'
                              : 'bg-slate-900 border-slate-800 shadow-md hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-start gap-3 flex-1">
                              {/* Exercise Checkbox */}
                              <button
                                onClick={() => toggleExerciseCheck(ex.id)}
                                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all flex-shrink-0 mt-0.5 ${
                                  isDone
                                    ? 'bg-emerald-500 text-slate-950 font-bold'
                                    : 'bg-slate-800 border border-slate-700 text-slate-500 hover:text-slate-300'
                                }`}
                              >
                                {isDone ? <Check className="w-5 h-5 stroke-[3]" /> : <span className="text-xs font-bold">{index + 1}</span>}
                              </button>

                              <div className="space-y-1 flex-1">
                                <div className="flex flex-wrap items-center gap-2">
                                  <h4 className={`text-sm sm:text-base font-bold ${isDone ? 'line-through text-slate-400' : 'text-white'}`}>
                                    {ex.name}
                                  </h4>
                                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-800 text-emerald-400 border border-slate-700">
                                    {ex.muscleGroup}
                                  </span>
                                  {ex.technique && ex.technique !== 'Tradicional' && (
                                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-300 border border-amber-500/30">
                                      ⚡ {ex.technique}
                                    </span>
                                  )}
                                </div>

                                <p className="text-xs text-slate-400">
                                  {ex.notes || 'Executar com cadência controlada e amplitude completa.'}
                                </p>

                                {/* Prescription Badges & Weight input */}
                                <div className="pt-2 flex flex-wrap items-center gap-2 text-xs">
                                  <span className="bg-slate-800/80 px-2.5 py-1 rounded-lg text-slate-300 font-semibold">
                                    {ex.sets} séries
                                  </span>
                                  <span className="bg-slate-800/80 px-2.5 py-1 rounded-lg text-slate-300 font-semibold">
                                    {ex.reps} reps
                                  </span>
                                  <span className="bg-slate-800/80 px-2.5 py-1 rounded-lg text-cyan-300 font-semibold">
                                    ⏱️ {ex.restSeconds}s pausa
                                  </span>

                                  {/* Student Real-time Load input */}
                                  <div className="flex items-center gap-1.5 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700 ml-auto">
                                    <span className="text-[11px] text-slate-400">Sua Carga:</span>
                                    <input
                                      type="number"
                                      min="0"
                                      step="1"
                                      value={studentLoads[ex.id] !== undefined ? studentLoads[ex.id] : (ex.userCurrentLoadKg || ex.suggestedLoadKg || 0)}
                                      onChange={(e) => {
                                        const val = Number(e.target.value);
                                        setStudentLoads((prev) => ({ ...prev, [ex.id]: val }));
                                        onUpdateExerciseLoad(currentWorkoutDay.id, ex.id, val);
                                      }}
                                      className="w-14 bg-slate-900 border border-slate-700 text-emerald-400 font-bold text-xs rounded px-1.5 py-0.5 text-center focus:outline-none focus:border-emerald-500"
                                    />
                                    <span className="text-[11px] text-slate-400 font-bold">kg</span>
                                  </div>
                                </div>

                                {/* Vídeo do Exercício para o Aluno assistir */}
                                {(ex.videoUrl || isCoachPreview) && (
                                  <div className="pt-2">
                                    <ExerciseVideoSlot
                                      videoUrl={ex.videoUrl}
                                      videoName={ex.videoName}
                                      exerciseName={ex.name}
                                      muscleGroup={ex.muscleGroup}
                                      notes={ex.notes}
                                      readOnly={!isCoachPreview}
                                    />
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: NUTRITION & WATER */}
          {activeTab === 'nutrition' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              {/* Daily Water Tracker */}
              <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                      <Droplets className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-white font-display">
                        Meta Diária de Água & Hidratação
                      </h3>
                      <p className="text-xs text-slate-400">
                        {waterIntakeMl} ml consumidos de <strong>{targetWaterMl} ml</strong> recomendados
                      </p>
                    </div>
                  </div>

                  <span className="text-xl font-black text-cyan-400 font-mono self-start sm:self-auto">
                    {waterProgress}%
                  </span>
                </div>

                {/* Progress Bar */}
                <div className="w-full bg-slate-800 h-3.5 rounded-full overflow-hidden p-0.5">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-teal-400 h-full rounded-full transition-all duration-300"
                    style={{ width: `${waterProgress}%` }}
                  ></div>
                </div>

                {/* Quick Add Buttons */}
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    onClick={() => handleAddWater(250)}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-slate-700 text-xs font-bold transition-all"
                  >
                    + 250 ml (Copo)
                  </button>
                  <button
                    onClick={() => handleAddWater(500)}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-slate-700 text-xs font-bold transition-all"
                  >
                    + 500 ml (Garrafa)
                  </button>
                  <button
                    onClick={() => handleAddWater(-250)}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-400 text-xs transition-all"
                  >
                    - 250 ml
                  </button>
                </div>
              </div>

              {/* Nutrition Plan from Coach */}
              {plan.nutritionPlan ? (
                <div className="space-y-6">
                  {/* Macros Header */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
                      <span className="text-xs text-slate-400 block">Calorias Diárias</span>
                      <span className="text-xl font-black text-amber-400 font-display">
                        {plan.nutritionPlan.dailyCalories} kcal
                      </span>
                    </div>
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
                      <span className="text-xs text-slate-400 block">Proteínas</span>
                      <span className="text-xl font-black text-rose-400 font-display">
                        {plan.nutritionPlan.macros.proteinGrams}g
                      </span>
                    </div>
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
                      <span className="text-xs text-slate-400 block">Carboidratos</span>
                      <span className="text-xl font-black text-amber-400 font-display">
                        {plan.nutritionPlan.macros.carbsGrams}g
                      </span>
                    </div>
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
                      <span className="text-xs text-slate-400 block">Gorduras Boas</span>
                      <span className="text-xl font-black text-teal-400 font-display">
                        {plan.nutritionPlan.macros.fatGrams}g
                      </span>
                    </div>
                  </div>

                  {/* Meals List */}
                  <div className="space-y-3">
                    <h3 className="font-bold text-white text-base">Planejamento das Refeições:</h3>
                    {plan.nutritionPlan.meals.map((meal) => (
                      <div
                        key={meal.id}
                        className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-2.5 shadow-md"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 font-mono text-xs font-bold">
                              {meal.time}
                            </span>
                            <h4 className="font-bold text-sm text-white">{meal.name}</h4>
                          </div>
                          <span className="text-xs text-slate-400 font-semibold">
                            {meal.calories} kcal
                          </span>
                        </div>

                        <ul className="space-y-1 text-xs text-slate-300 pl-2">
                          {meal.foods.map((food, fIdx) => (
                            <li key={fIdx} className="flex items-center gap-2">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                              <span>{food}</span>
                            </li>
                          ))}
                        </ul>

                        {meal.notes && (
                          <p className="text-[11px] text-slate-400 italic pt-1 border-t border-slate-800/80">
                            💡 Dica: {meal.notes}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center text-slate-400 space-y-2">
                  <Utensils className="w-10 h-10 mx-auto text-slate-600" />
                  <p className="font-bold text-slate-300">Nenhum plano alimentar cadastrado ainda</p>
                  <p className="text-xs">
                    Solicite ao seu treinador {coachProfile.name} a inclusão de um plano nutricional.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: EVOLUTION */}
          {activeTab === 'evolution' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-base text-white font-display">
                      Sua Evolução de Cargas (kg)
                    </h3>
                    <p className="text-xs text-slate-400">
                      Progressão de força registrada nas suas avaliações
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-teal-500/15 text-teal-300 text-xs font-bold">
                    📈 Sobrecarga Progressiva
                  </span>
                </div>

                <div className="h-64 sm:h-72 w-full pt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={historyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                      <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} tickLine={false} />
                      <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} unit="kg" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#0f172a',
                          borderColor: '#334155',
                          borderRadius: '16px',
                          color: '#f8fafc',
                          fontSize: '12px',
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                      <Line type="monotone" dataKey="agachamento" name="Agachamento (kg)" stroke="#10b981" strokeWidth={3} dot={{ r: 5 }} />
                      <Line type="monotone" dataKey="legPress" name="Leg Press (kg)" stroke="#06b6d4" strokeWidth={2} dot={{ r: 4 }} />
                      <Line type="monotone" dataKey="supino" name="Supino (kg)" stroke="#f59e0b" strokeWidth={2} dot={{ r: 4 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Weight Chart */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
                <h3 className="font-bold text-base text-white font-display">Evolução do Peso Corporal</h3>
                <div className="h-56 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={historyData}>
                      <defs>
                        <linearGradient id="studentColorPeso" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                      <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} tickLine={false} />
                      <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} unit="kg" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#0f172a',
                          borderColor: '#334155',
                          borderRadius: '16px',
                          color: '#f8fafc',
                          fontSize: '12px',
                        }}
                      />
                      <Area type="monotone" dataKey="peso" name="Peso (kg)" stroke="#10b981" fill="url(#studentColorPeso)" strokeWidth={3} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: COACH PROFILE & DIRECT WHATSAPP */}
          {activeTab === 'coach' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl text-center">
                <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center mx-auto text-2xl font-black shadow-lg shadow-emerald-500/20">
                  {coachProfile.name.charAt(0)}
                </div>

                <div className="space-y-1">
                  <h3 className="text-xl sm:text-2xl font-black text-white font-display">
                    {coachProfile.name}
                  </h3>
                  {coachProfile.fullName && coachProfile.fullName !== coachProfile.name && (
                    <p className="text-xs text-slate-400">{coachProfile.fullName}</p>
                  )}
                  <p className="text-xs text-emerald-400 font-bold uppercase tracking-wider">
                    CREF {coachProfile.cref} • {coachProfile.brandOrGym}
                  </p>
                </div>

                {coachProfile.bio && (
                  <p className="text-xs text-slate-300 max-w-lg mx-auto leading-relaxed italic">
                    "{coachProfile.bio}"
                  </p>
                )}

                {coachProfile.consultancyNotes && (
                  <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 text-xs text-slate-300 max-w-lg mx-auto leading-relaxed text-left">
                    <span className="font-bold text-white block mb-1">📌 Orientações do Professor:</span>
                    <p>{coachProfile.consultancyNotes}</p>
                  </div>
                )}

                {/* Coach contact & social badges */}
                <div className="flex flex-wrap items-center justify-center gap-2 pt-1 text-xs">
                  {coachProfile.instagram && (
                    <span className="px-3 py-1.5 rounded-xl bg-slate-800 text-teal-300 border border-slate-700 font-semibold flex items-center gap-1.5">
                      <span>📸 {coachProfile.instagram}</span>
                    </span>
                  )}
                  {coachProfile.email && (
                    <span className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 font-semibold flex items-center gap-1.5">
                      <span>✉️ {coachProfile.email}</span>
                    </span>
                  )}
                  {coachProfile.phone && (
                    <span className="px-3 py-1.5 rounded-xl bg-slate-800 text-emerald-400 border border-slate-700 font-semibold flex items-center gap-1.5">
                      <span>📱 WhatsApp: {coachProfile.phone}</span>
                    </span>
                  )}
                </div>

                <div className="pt-2 max-w-md mx-auto space-y-3">
                  <button
                    onClick={() => setIsInstallModalOpen(true)}
                    className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2.5 shadow-lg shadow-emerald-500/20 transition-all"
                  >
                    <Download className="w-5 h-5" />
                    <span>Instalar App no Celular / Computador</span>
                  </button>

                  <button
                    onClick={() => handleSendWhatsAppToCoach()}
                    className="w-full py-3.5 px-6 rounded-2xl bg-[#25D366] hover:bg-[#20bd5a] text-slate-950 font-black text-sm flex items-center justify-center gap-2.5 shadow-lg shadow-[#25D366]/20 transition-all"
                  >
                    <MessageCircle className="w-5 h-5" />
                    <span>Falar com {coachProfile.name} no WhatsApp</span>
                  </button>

                  <p className="text-[11px] text-slate-400">
                    Tire dúvidas sobre execução de exercícios, ajuste de cargas e tire fotos dos seus pratos.
                  </p>
                </div>
              </div>
            </div>
          )}
        </main>
      )}

      {/* PWA / Native App Install Modal for Student */}
      <InstallAppModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        appName={`Treinos ${student.name}`}
        targetRole="student"
        studentShareUrl={window.location.href}
      />

      {/* Hidden Printable PDF Container for offscreen capture & print */}
      <div
        id="printable-pdf-document"
        style={{ position: 'absolute', left: '-9999px', top: 0, width: '800px', opacity: 1 }}
        aria-hidden="true"
      >
        <PrintableWorkoutPdf
          plan={plan}
          student={student}
          coachProfile={coachProfile}
        />
      </div>
    </div>
  );
};
