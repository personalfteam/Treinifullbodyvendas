import React, { useState } from 'react';
import {
  Share2,
  Copy,
  Check,
  ExternalLink,
  MessageCircle,
  QrCode,
  Smartphone,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  X,
  Download,
  Send
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { Student, WorkoutPlan, CoachProfile } from '../types';

interface StudentShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student;
  plan: WorkoutPlan;
  coachProfile: CoachProfile;
  onOpenStudentView: (studentId: string) => void;
  onOpenInstallAppModal?: () => void;
}

export const StudentShareModal: React.FC<StudentShareModalProps> = ({
  isOpen,
  onClose,
  student,
  plan,
  coachProfile,
  onOpenStudentView,
  onOpenInstallAppModal,
}) => {
  const [copied, setCopied] = useState(false);
  const [showQrCode, setShowQrCode] = useState(false);

  if (!isOpen) return null;

  // Build the student direct URL
  const baseUrl = window.location.origin + window.location.pathname;
  const studentUrl = `${baseUrl}?view=student&studentId=${student.id}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(studentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `App de Treinos de ${student.name} • ${coachProfile.name}`,
          text: `Olá ${student.name}! Acesse sua ficha de treinos e dieta personalizada aqui:`,
          url: studentUrl,
        });
      } catch (err) {
        // User cancelled or share failed
        console.log('Share dismissed', err);
      }
    } else {
      handleCopyLink();
    }
  };

  const handleWhatsAppSend = () => {
    const isInactive =
      student.subscriptionStatus === 'canceled' ||
      student.subscriptionStatus === 'pending_payment';

    let text = `🏋️‍♂️ *Olá ${student.name}!* Tudo bem?\n\n`;
    if (isInactive) {
      text += `Aqui é o seu treinador *${coachProfile.name}* (${coachProfile.brandOrGym}).\n`;
      text += `Avisando sobre sua mensalidade da consultoria de treinos. Assim que regularizar, seu acesso aos novos treinos será liberado!\n\n`;
      if (coachProfile.pixKey) {
        text += `🔑 *Chave PIX (${coachProfile.pixKeyType || 'PIX'}):* ${coachProfile.pixKey}\n\n`;
      }
      text += `📲 Qualquer dúvida estou à disposição!`;
    } else {
      text += `Seu treino personalizado de *${plan.title}* foi atualizado e sincronizado no seu app exclusivo!\n\n`;
      text += `📱 *Acesse seu App e Ficha de Treinos aqui:*\n${studentUrl}\n\n`;
      text += `💪 *Divisão:* ${plan.splitType} (${plan.workouts.map((w) => w.name).join(', ')})\n`;
      text += `⏱️ *Dica:* Você pode baixar o app no seu celular tocando em "Instalar App" dentro do link!\n\n`;
      text += `Bons treinos! Qualquer dúvida na execução, é só me chamar.\n_${coachProfile.name} - CREF ${coachProfile.cref}_`;
    }

    const cleanPhone = (student.phone || '').replace(/\D/g, '');
    const url = cleanPhone
      ? `https://wa.me/55${cleanPhone}?text=${encodeURIComponent(text)}`
      : `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-6 relative my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-all"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 border-b border-slate-800 pb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center text-xl font-bold shadow-md shadow-emerald-500/20">
            <Send className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-extrabold text-white font-display">
                Enviar App para o Aluno
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Link Exclusivo
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Acesso individual e protegido de <strong className="text-emerald-300">{student.name}</strong>
            </p>
          </div>
        </div>

        {/* Status notice */}
        {student.subscriptionStatus === 'canceled' ? (
          <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 flex-shrink-0 text-rose-400 mt-0.5" />
            <div>
              <p className="font-bold">Acesso do Aluno Bloqueado (Cancelado)</p>
              <p className="text-rose-400/90 text-[11px]">
                Ao acessar o link, o aluno verá a tela de aviso de mensalidade com sua chave PIX.
              </p>
            </div>
          </div>
        ) : student.subscriptionStatus === 'pending_payment' ? (
          <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-amber-300 text-xs flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 flex-shrink-0 text-amber-400 mt-0.5" />
            <div>
              <p className="font-bold">Mensalidade Pendente</p>
              <p className="text-amber-400/90 text-[11px]">
                O aluno verá aviso de pagamento pendente ao acessar o portal.
              </p>
            </div>
          </div>
        ) : (
          <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 flex-shrink-0 text-emerald-400" />
            <div>
              <p className="font-bold">Plano Ativo & Sincronizado</p>
              <p className="text-slate-400 text-[11px]">
                Toda alteração na ficha reflete instantaneamente no link do aluno.
              </p>
            </div>
          </div>
        )}

        {/* Link input & copy */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
            <span>Link do App de {student.name}:</span>
            <span className="text-[11px] text-emerald-400">Celular ou Computador</span>
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={studentUrl}
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-300 font-mono focus:outline-none select-all truncate"
            />
            <button
              onClick={handleCopyLink}
              id="btn-copy-student-share-link"
              className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md ${
                copied
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
              }`}
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copiar</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* QR Code toggle section */}
        {showQrCode && (
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-center gap-4 animate-in fade-in duration-200">
            <div className="p-2 bg-white rounded-xl shadow-md flex-shrink-0">
              <QRCodeSVG value={studentUrl} size={110} level="M" />
            </div>
            <div className="text-center sm:text-left space-y-1">
              <p className="text-xs font-bold text-white flex items-center justify-center sm:justify-start gap-1.5">
                <QrCode className="w-3.5 h-3.5 text-emerald-400" />
                <span>QR Code para o Aluno Escanear</span>
              </p>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Mostre este código para {student.name} na academia. Ele pode apontar a câmera do celular para abrir o app na hora!
              </p>
            </div>
          </div>
        )}

        {/* Action Buttons Grid */}
        <div className="space-y-2.5 pt-1">
          {/* Send on WhatsApp button */}
          <button
            onClick={handleWhatsAppSend}
            id="btn-send-whatsapp-student-link"
            className="w-full py-3.5 px-4 rounded-2xl bg-[#25D366] hover:bg-[#20bd5a] text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#25D366]/20 transition-all active:scale-[0.99]"
          >
            <MessageCircle className="w-4 h-4 stroke-[2.5]" />
            <span>Enviar pelo WhatsApp de {student.name.split(' ')[0]}</span>
          </button>

          {/* Quick Share / QR Code row */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleNativeShare}
              id="btn-native-share-student-link"
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 hover:text-white border border-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
            >
              <Share2 className="w-3.5 h-3.5 text-teal-400" />
              <span>Compartilhar</span>
            </button>

            <button
              onClick={() => setShowQrCode(!showQrCode)}
              id="btn-toggle-qr-code"
              className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                showQrCode
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-slate-800 hover:bg-slate-750 text-slate-200 hover:text-white border-slate-700'
              }`}
            >
              <QrCode className="w-3.5 h-3.5 text-emerald-400" />
              <span>{showQrCode ? 'Ocultar QR Code' : 'Ver QR Code'}</span>
            </button>
          </div>

          {/* Test / View as Student button */}
          <button
            onClick={() => {
              onClose();
              onOpenStudentView(student.id);
            }}
            id="btn-preview-as-student"
            className="w-full py-2.5 px-4 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/20 font-semibold text-xs flex items-center justify-center gap-2 transition-all"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Testar como Aluno ({student.name})</span>
          </button>
        </div>

        {/* Feature summary bullets */}
        <div className="pt-2 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            <span>Sem necessidade de senha</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-teal-400"></span>
            <span>Salva cargas no celular</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
            <span>Cronômetro integrado</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
            <span>Instalável no celular ou PC</span>
          </div>
        </div>
      </div>
    </div>
  );
};
