import React, { useState } from 'react';
import {
  X,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  UserX,
  UserCheck,
  ShieldAlert,
  ShieldCheck,
  CreditCard,
  Phone,
  MessageCircle
} from 'lucide-react';
import { Student, SubscriptionStatus, CoachProfile } from '../types';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student;
  coachProfile: CoachProfile;
  onUpdateSubscription: (studentId: string, updates: {
    subscriptionStatus: SubscriptionStatus;
    monthlyFee?: number;
    dueDay?: number;
    cancellationReason?: string;
    lastPaymentDate?: string;
  }) => void;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  isOpen,
  onClose,
  student,
  coachProfile,
  onUpdateSubscription,
}) => {
  const [status, setStatus] = useState<SubscriptionStatus>(
    student.subscriptionStatus || 'active'
  );
  const [monthlyFee, setMonthlyFee] = useState<number>(student.monthlyFee || 150);
  const [dueDay, setDueDay] = useState<number>(student.dueDay || 10);
  const [cancellationReason, setCancellationReason] = useState<string>(
    student.cancellationReason || ''
  );
  const [lastPaymentDate, setLastPaymentDate] = useState<string>(
    student.lastPaymentDate || new Date().toISOString().split('T')[0]
  );

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSubscription(student.id, {
      subscriptionStatus: status,
      monthlyFee: Number(monthlyFee) || 0,
      dueDay: Number(dueDay) || 10,
      cancellationReason: status !== 'active' ? cancellationReason.trim() : '',
      lastPaymentDate: lastPaymentDate,
    });
    onClose();
  };

  const handleInstantCancel = () => {
    setStatus('canceled');
    if (!cancellationReason) {
      setCancellationReason('Inadimplência / Mensalidade não identificada');
    }
  };

  const handleInstantReactivate = () => {
    setStatus('active');
    setCancellationReason('');
    setLastPaymentDate(new Date().toISOString().split('T')[0]);
  };

  const handleSendPaymentReminder = () => {
    const text = `Olá *${student.name}*! Tudo bem?\n\nAqui é o *${coachProfile.name}* (${coachProfile.brandOrGym}).\nIdentificamos uma pendência no pagamento da sua mensalidade da consultoria (R$ ${monthlyFee},00 com vencimento todo dia ${dueDay}).\n\nPor favor, nos envie o comprovante para manter sua ficha de treino e dieta liberadas no app! 🙏\nObrigado!`;
    const cleanPhone = (student.phone || '').replace(/\D/g, '');
    const url = cleanPhone
      ? `https://wa.me/55${cleanPhone}?text=${encodeURIComponent(text)}`
      : `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-6 relative my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-all"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 border-b border-slate-800 pb-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center text-xl font-bold shadow-md">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-white font-display">
              Gestão de Mensalidade & Acesso
            </h2>
            <p className="text-xs text-slate-400">
              Aluno: <strong className="text-emerald-400">{student.name}</strong>
            </p>
          </div>
        </div>

        {/* Status Pills Selector */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-200 block">
            Status do Plano & Acesso ao App:
          </label>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              id="btn-status-active"
              onClick={() => setStatus('active')}
              className={`p-3 rounded-2xl border text-center transition-all ${
                status === 'active'
                  ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 ring-2 ring-emerald-500/50 shadow-md font-bold'
                  : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <div className="flex items-center justify-center gap-1.5 mb-1 text-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Ativo</span>
              </div>
              <p className="text-[10px] text-emerald-400/80">Acesso Total</p>
            </button>

            <button
              type="button"
              id="btn-status-pending"
              onClick={() => setStatus('pending_payment')}
              className={`p-3 rounded-2xl border text-center transition-all ${
                status === 'pending_payment'
                  ? 'bg-amber-950/60 border-amber-500 text-amber-300 ring-2 ring-amber-500/50 shadow-md font-bold'
                  : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <div className="flex items-center justify-center gap-1.5 mb-1 text-xs">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>Pendente</span>
              </div>
              <p className="text-[10px] text-amber-400/80">Atraso de Pagamento</p>
            </button>

            <button
              type="button"
              id="btn-status-canceled"
              onClick={() => setStatus('canceled')}
              className={`p-3 rounded-2xl border text-center transition-all ${
                status === 'canceled'
                  ? 'bg-rose-950/60 border-rose-500 text-rose-300 ring-2 ring-rose-500/50 shadow-md font-bold'
                  : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <div className="flex items-center justify-center gap-1.5 mb-1 text-xs">
                <UserX className="w-4 h-4 text-rose-400" />
                <span>Cancelado</span>
              </div>
              <p className="text-[10px] text-rose-400/80">Acesso Bloqueado</p>
            </button>
          </div>
        </div>

        {/* Warning card when canceled or pending */}
        {status === 'canceled' && (
          <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/40 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-rose-300">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span>Bloqueio de Ficha Ativado:</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              O aluno <strong>não conseguirá ver os treinos nem a dieta</strong> no link do app. Ao abrir, verá uma tela informando que o plano está suspenso e o botão para falar com você no WhatsApp.
            </p>
          </div>
        )}

        {status === 'pending_payment' && (
          <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Aviso de Cobrança:</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              O aluno verá um banner de cobrança no app solicitando o envio do comprovante para o professor.
            </p>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Valor da Mensalidade (R$)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400 font-bold">R$</span>
                <input
                  type="number"
                  min="0"
                  step="5"
                  value={monthlyFee}
                  onChange={(e) => setMonthlyFee(Number(e.target.value))}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-semibold text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Dia de Vencimento
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400 font-bold">Dia</span>
                <input
                  type="number"
                  min="1"
                  max="31"
                  value={dueDay}
                  onChange={(e) => setDueDay(Number(e.target.value))}
                  className="w-full pl-11 pr-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-semibold text-xs focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Data do Último Pagamento Registrado
            </label>
            <input
              type="date"
              value={lastPaymentDate}
              onChange={(e) => setLastPaymentDate(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
            />
          </div>

          {status !== 'active' && (
            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Motivo do Cancelamento / Bloqueio (visível para você e aviso ao aluno)
              </label>
              <input
                type="text"
                placeholder="Ex: Mensalidade de Setembro pendente"
                value={cancellationReason}
                onChange={(e) => setCancellationReason(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-rose-500"
              />
            </div>
          )}

          {/* Direct WhatsApp reminder button */}
          {student.phone && (
            <button
              type="button"
              onClick={handleSendPaymentReminder}
              className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 flex items-center justify-center gap-2 text-xs font-semibold transition-all"
            >
              <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
              <span>Enviar Lembrete de Mensalidade pelo WhatsApp</span>
            </button>
          )}

          {/* Quick toggle actions */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            {status === 'active' ? (
              <button
                type="button"
                id="btn-quick-cancel-action"
                onClick={handleInstantCancel}
                className="px-3.5 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-xs font-bold transition-all flex items-center gap-1.5"
              >
                <UserX className="w-3.5 h-3.5" />
                <span>Cancelar Plano (Bloquear)</span>
              </button>
            ) : (
              <button
                type="button"
                id="btn-quick-reactivate-action"
                onClick={handleInstantReactivate}
                className="px-3.5 py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 text-xs font-bold transition-all flex items-center gap-1.5"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Reativar / Desbloquear</span>
              </button>
            )}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
              >
                Fechar
              </button>
              <button
                type="submit"
                id="btn-save-subscription-status"
                className="px-5 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400 shadow-md transition-all"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
