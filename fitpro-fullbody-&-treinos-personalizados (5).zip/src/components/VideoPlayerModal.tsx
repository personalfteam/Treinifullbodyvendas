import React from 'react';
import { X, Play, ExternalLink, Sparkles, FolderOpen, ShieldCheck, Film } from 'lucide-react';
import { getVideoEmbedInfo, GOOGLE_DRIVE_VIDEOS_URL } from '../utils/videoUtils';

interface VideoPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoUrl?: string;
  videoName?: string;
  exerciseName: string;
  muscleGroup?: string;
  notes?: string;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({
  isOpen,
  onClose,
  videoUrl,
  videoName,
  exerciseName,
  muscleGroup,
  notes,
}) => {
  if (!isOpen || !videoUrl) return null;

  const info = getVideoEmbedInfo(videoUrl);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-750 rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between gap-3 bg-slate-900/95">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center flex-shrink-0">
              <Play className="w-5 h-5 fill-current ml-0.5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400">
                  Vídeo Direto no App
                </span>
                <span className="px-2 py-0.5 rounded-full bg-slate-800 text-[10px] font-semibold text-slate-300">
                  {info.providerLabel}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-black text-white truncate font-display">
                {exerciseName}
              </h3>
              {muscleGroup && (
                <p className="text-[11px] text-slate-400 truncate">
                  Foco: <span className="text-slate-200 font-semibold">{muscleGroup}</span>
                  {videoName ? ` • ${videoName}` : ''}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <a
              href={GOOGLE_DRIVE_VIDEOS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-indigo-400 hover:text-indigo-300 border border-slate-700 text-xs font-bold hidden sm:flex items-center gap-1.5 transition-all"
              title="Abrir pasta completa no Google Drive"
            >
              <FolderOpen className="w-3.5 h-3.5" />
              <span>Drive Completo</span>
            </a>

            <a
              href={info.originalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 transition-all"
              title="Abrir link original no Google Drive / Navegador"
            >
              <ExternalLink className="w-4 h-4" />
            </a>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-white transition-all"
              title="Fechar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Video Screen Player Body */}
        <div className="p-3 sm:p-5 bg-slate-950 flex-1 flex flex-col items-center justify-center min-h-[320px] sm:min-h-[420px] overflow-hidden relative">
          {info.type === 'direct' ? (
            info.embedUrl?.includes('.gif') || info.embedUrl?.startsWith('data:image/') ? (
              <div className="w-full flex items-center justify-center max-h-[60vh] rounded-2xl bg-black/90 p-2 border border-slate-800 shadow-2xl">
                <img
                  src={info.embedUrl || info.originalUrl}
                  alt={exerciseName}
                  referrerPolicy="no-referrer"
                  className="max-h-[56vh] max-w-full rounded-xl object-contain"
                />
              </div>
            ) : (
              <video
                src={info.embedUrl || info.originalUrl}
                controls
                autoPlay
                playsInline
                loop
                className="w-full max-h-[60vh] rounded-2xl bg-black shadow-2xl object-contain border border-slate-800"
              />
            )
          ) : info.type === 'drive' ? (
            <div className="w-full aspect-video rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-2xl relative">
              <iframe
                src={info.embedUrl!}
                title={exerciseName}
                allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                allowFullScreen
                className="w-full h-full border-0"
              />
            </div>
          ) : info.type === 'drive_folder' ? (
            <div className="w-full h-[60vh] rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 shadow-2xl flex flex-col">
              <div className="px-4 py-2 bg-slate-850 border-b border-slate-750 flex items-center justify-between text-xs text-slate-300">
                <span className="flex items-center gap-1.5 font-bold text-indigo-300">
                  <FolderOpen className="w-4 h-4 text-indigo-400" />
                  <span>Navegador de Pasta do Google Drive (Ao Vivo no App)</span>
                </span>
                <a
                  href={info.originalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-bold"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Abrir no Drive</span>
                </a>
              </div>
              <iframe
                src={info.embedUrl!}
                title="Pasta do Google Drive"
                allow="autoplay; fullscreen"
                allowFullScreen
                className="w-full flex-1 border-0 bg-white"
              />
            </div>
          ) : (
            <div className="text-center p-6 space-y-4 max-w-md">
              <div className="w-16 h-16 rounded-3xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center mx-auto">
                <Film className="w-8 h-8" />
              </div>
              <div>
                <h4 className="text-base font-bold text-white mb-1">Link de Vídeo Externo</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Clique no botão abaixo para acessar o vídeo ou pasta de exercícios do Google Drive:
                </p>
              </div>
              <a
                href={info.originalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 w-full py-3 px-5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/20 transition-all"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Abrir Vídeo no Google Drive</span>
              </a>
            </div>
          )}
        </div>

        {/* Notes & Bio instructions */}
        {notes && (
          <div className="p-4 sm:p-5 bg-slate-900 border-t border-slate-800 text-xs text-slate-300 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-white mb-0.5">Orientações do Educador Físico:</p>
              <p className="text-slate-300 leading-relaxed">{notes}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

