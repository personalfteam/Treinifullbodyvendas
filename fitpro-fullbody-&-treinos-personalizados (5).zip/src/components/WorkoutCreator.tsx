import React, { useState, useEffect, useMemo } from 'react';
import {
  Sparkles,
  Dumbbell,
  Target,
  Flame,
  Activity,
  Layers,
  FileCheck,
  RotateCcw,
  Zap,
  UserCheck,
  ShieldCheck,
  Clock,
  ChevronRight,
  BookOpen,
  ArrowRight,
  AlertCircle,
  Home,
  History,
  CheckCircle2,
  Cpu,
  UserPlus,
  Info,
  FolderOpen,
  Video
} from 'lucide-react';
import {
  Student,
  WorkoutModality,
  SplitType,
  AdvancedTechnique,
  GenerationScope,
  HomeEquipmentType,
  PrimaryGoal,
  FitnessLevel,
  Gender,
  WorkoutPlan,
  Exercise,
} from '../types';
import { requestWorkoutGeneration, getStudentPastExerciseNames } from '../utils/workoutGenerator';
import { GOOGLE_DRIVE_VIDEOS_URL } from '../utils/videoUtils';
import { CustomExerciseUploader } from './CustomExerciseUploader';
import { VideoPlayerModal } from './VideoPlayerModal';

interface WorkoutCreatorProps {
  students: Student[];
  selectedStudent: Student | null;
  onSelectStudent?: (student: Student) => void;
  onSaveStudent: (student: Student) => void;
  onPlanGenerated: (plan: WorkoutPlan) => void;
}

export const WorkoutCreator: React.FC<WorkoutCreatorProps> = ({
  students,
  selectedStudent,
  onSelectStudent,
  onSaveStudent,
  onPlanGenerated,
}) => {
  // Student Profile Form State
  const [isNewStudentMode, setIsNewStudentMode] = useState(false);
  const [name, setName] = useState('');
  const [gender, setGender] = useState<Gender>('feminino');
  const [age, setAge] = useState<number>(28);
  const [weightKg, setWeightKg] = useState<number>(64);
  const [heightCm, setHeightCm] = useState<number>(165);
  const [level, setLevel] = useState<FitnessLevel>('Iniciante');
  const [goal, setGoal] = useState<PrimaryGoal>('Hipertrofia de Membros Inferiores');
  const [frequencyDays, setFrequencyDays] = useState<number>(3);
  const [limitations, setLimitations] = useState('');
  const [phone, setPhone] = useState('');

  // Prescription Parameters
  const [modality, setModality] = useState<WorkoutModality>('fullbody');
  const [homeEquipment, setHomeEquipment] = useState<HomeEquipmentType>('mixed_home');
  const [splitType, setSplitType] = useState<SplitType>('Fullbody');
  const [selectedTechniques, setSelectedTechniques] = useState<AdvancedTechnique[]>(['Tradicional']);
  const [generationScope, setGenerationScope] = useState<GenerationScope>('both');
  const [customCoachNotes, setCustomCoachNotes] = useState('');

  // Engine & Anti-Repetition
  const [generationEngine, setGenerationEngine] = useState<'ai_gemini' | 'algorithmic'>('ai_gemini');
  const [avoidPreviousExercises, setAvoidPreviousExercises] = useState(true);
  const [showHistoryExercises, setShowHistoryExercises] = useState(false);

  // Custom Exercises & Direct GIF Upload / URL Input State
  const [customExercises, setCustomExercises] = useState<Exercise[]>([]);
  const [previewVideo, setPreviewVideo] = useState<{ url: string; name: string } | null>(null);

  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStatus, setGenerationStatus] = useState<string>('');

  // Extract previous exercises for this student from historical saved plans
  const pastExercises = useMemo(() => {
    if (!selectedStudent) return [];
    return getStudentPastExerciseNames(selectedStudent);
  }, [selectedStudent]);

  // Sync when selectedStudent changes
  useEffect(() => {
    if (selectedStudent && !isNewStudentMode) {
      setName(selectedStudent.name);
      setGender(selectedStudent.gender);
      setAge(selectedStudent.age);
      setWeightKg(selectedStudent.weightKg);
      setHeightCm(selectedStudent.heightCm);
      setLevel(selectedStudent.level);
      setGoal(selectedStudent.goal);
      setFrequencyDays(selectedStudent.frequencyDaysPerWeek);
      setLimitations(selectedStudent.limitations || '');
      setPhone(selectedStudent.phone || '');
    }
  }, [selectedStudent, isNewStudentMode]);

  // Adjust default split and techniques based on modality selection
  const handleModalityChange = (newModality: WorkoutModality) => {
    setModality(newModality);
    if (newModality === 'fullbody') {
      setSplitType('Fullbody');
    } else if (newModality === 'casa') {
      setSplitType('Fullbody');
    } else if (newModality === 'inferiores') {
      setSplitType('Superior/Inferior');
      if (goal !== 'Hipertrofia de Membros Inferiores') {
        setGoal('Hipertrofia de Membros Inferiores');
      }
    } else if (newModality === 'mobilidade') {
      setSplitType('Fullbody');
      setGoal('Mobilidade Articular e Flexibilidade');
    } else if (newModality === 'musculacao') {
      setSplitType('A/B/C');
    }
  };

  const toggleTechnique = (tech: AdvancedTechnique) => {
    if (tech === 'Tradicional') {
      setSelectedTechniques(['Tradicional']);
      return;
    }
    const filtered = selectedTechniques.filter((t) => t !== 'Tradicional');
    if (filtered.includes(tech)) {
      const next = filtered.filter((t) => t !== tech);
      setSelectedTechniques(next.length > 0 ? next : ['Tradicional']);
    } else {
      setSelectedTechniques([...filtered, tech]);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Por favor, informe o nome do aluno.');
      return;
    }

    setIsGenerating(true);
    setGenerationStatus(
      generationEngine === 'ai_gemini'
        ? 'Consultando Inteligência Artificial com análise anti-repetição...'
        : 'Processando presets biomecânicos exclusivos...'
    );

    // Determine target ID: new student or selected student
    const studentId = isNewStudentMode || !selectedStudent ? `student-${Date.now()}` : selectedStudent.id;
    const existingStudent = students.find((s) => s.id === studentId);

    // Save or update student in parent state
    const currentStudent: Student = {
      id: studentId,
      name: name.trim(),
      gender,
      age: Number(age) || 25,
      weightKg: Number(weightKg) || 65,
      heightCm: Number(heightCm) || 165,
      level,
      goal,
      frequencyDaysPerWeek: Number(frequencyDays) || 3,
      limitations: limitations.trim(),
      phone: phone.trim(),
      createdAt: existingStudent?.createdAt || new Date().toISOString(),
      savedPlans: existingStudent?.savedPlans || [],
      evolutionHistory: existingStudent?.evolutionHistory || [
        {
          id: `evo-init-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          weightKg: Number(weightKg) || 65,
          notes: 'Avaliação inicial cadastrada no sistema.',
        },
      ],
    };

    onSaveStudent(currentStudent);
    setIsNewStudentMode(false);

    try {
      setTimeout(() => {
        setGenerationStatus(
          avoidPreviousExercises && pastExercises.length > 0
            ? `Excluindo ${pastExercises.length} exercícios anteriores de ${name} e selecionando novas variações...`
            : 'Montando seleção de exercícios exclusivos sem repetição...'
        );
      }, 600);

      const plan = await requestWorkoutGeneration(currentStudent, {
        modality,
        splitType,
        advancedTechniques: selectedTechniques,
        generationScope,
        homeEquipment,
        customNotes: customCoachNotes,
        generationEngine,
        avoidPreviousExercises,
        excludedExerciseNames: avoidPreviousExercises ? pastExercises : [],
        customExercises: customExercises.length > 0 ? customExercises : undefined,
      });

      setGenerationStatus('Finalizando diagrama e cálculo nutricional...');
      setTimeout(() => {
        setIsGenerating(false);
        onPlanGenerated(plan);
      }, 400);
    } catch (err) {
      console.error(err);
      setIsGenerating(false);
      alert('Houve um problema ao gerar o treino. Tente novamente.');
    }
  };

  const goalsList: PrimaryGoal[] = [
    'Hipertrofia de Membros Inferiores',
    'Hipertrofia Geral',
    'Emagrecimento & Queima de Gordura',
    'Força Bruta e Potência',
    'Mobilidade Articular e Flexibilidade',
    'Condicionamento Físico & Resistência',
    'Reabilitação e Prevenção de Lesões',
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8 space-y-8">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-bold tracking-wide uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              Prescrição Inteligente & Anti-Repetição
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight font-display">
              Prescrever Novo Treino
            </h1>
            <p className="text-slate-400 text-sm sm:text-base max-w-2xl leading-relaxed">
              Gere treinos <strong>Fullbody</strong>, divisões <strong>A/B/C</strong>, treinos <strong>Em Casa</strong> ou <strong>Inferiores/Glúteos</strong>. O sistema memoriza o histórico do aluno e não repete os exercícios anteriores.
            </p>
          </div>

          {/* Quick Stats Pill */}
          <div className="flex items-center gap-3 bg-slate-800/80 border border-slate-700/80 rounded-2xl p-3.5 sm:p-4 text-xs">
            <div className="space-y-1">
              <span className="text-slate-400 block font-medium">Alunos Cadastrados</span>
              <span className="text-xl font-black text-white font-display">{students.length}</span>
            </div>
            <div className="h-8 w-px bg-slate-700"></div>
            <div className="space-y-1">
              <span className="text-slate-400 block font-medium">Memória de Exercícios</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <ShieldCheck className="w-4 h-4" /> Ativa
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Student Selection Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-slate-300 font-semibold">
          <UserCheck className="w-4 h-4 text-emerald-400" />
          <span>Selecionar Aluno Rápido:</span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {students.map((st) => (
            <button
              key={st.id}
              type="button"
              id={`quick-select-student-${st.id}`}
              onClick={() => {
                setIsNewStudentMode(false);
                if (onSelectStudent) onSelectStudent(st);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${
                !isNewStudentMode && selectedStudent?.id === st.id
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                  : 'bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700'
              }`}
            >
              <span>{st.name}</span>
              {st.savedPlans && st.savedPlans.length > 0 && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${!isNewStudentMode && selectedStudent?.id === st.id ? 'bg-slate-950/20 text-slate-950 font-bold' : 'bg-slate-700 text-emerald-400 font-medium'}`}>
                  {st.savedPlans.length} {st.savedPlans.length === 1 ? 'treino' : 'treinos'}
                </span>
              )}
            </button>
          ))}
          <button
            type="button"
            id="btn-quick-new-student"
            onClick={() => {
              setIsNewStudentMode(true);
              setName('');
              setAge(25);
              setWeightKg(65);
              setHeightCm(165);
              setLimitations('');
              setPhone('');
              setLevel('Iniciante');
              setGoal('Hipertrofia de Membros Inferiores');
              setFrequencyDays(3);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
              isNewStudentMode
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                : 'bg-slate-800/60 text-slate-400 border border-dashed border-slate-700 hover:text-white hover:border-slate-600'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>+ Novo Aluno</span>
          </button>
        </div>
      </div>

      {/* Main Creation Form */}
      <form onSubmit={handleGenerate} className="space-y-8">
        {/* SECTION 1: Dados do Aluno */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-md">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
                1
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Dados Biométricos do Aluno</h2>
                <p className="text-xs text-slate-400">Campos fundamentais para calibrar o volume, gasto calórico e cargas</p>
              </div>
            </div>
            {selectedStudent && (
              <span className="text-xs text-emerald-400 font-medium px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                Aluno: {selectedStudent.name}
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {/* Nome */}
            <div className="sm:col-span-2 space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">
                Nome Completo do Aluno <span className="text-emerald-400">*</span>
              </label>
              <input
                id="input-student-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Mariana Souza"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 transition-all"
              />
            </div>

            {/* Gênero */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">Gênero Biológico</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  id="btn-gender-fem"
                  onClick={() => setGender('feminino')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all ${
                    gender === 'feminino'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-sm'
                      : 'bg-slate-800/60 text-slate-400 border-slate-700 hover:bg-slate-800'
                  }`}
                >
                  Feminino
                </button>
                <button
                  type="button"
                  id="btn-gender-masc"
                  onClick={() => setGender('masculino')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-semibold border transition-all ${
                    gender === 'masculino'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-sm'
                      : 'bg-slate-800/60 text-slate-400 border-slate-700 hover:bg-slate-800'
                  }`}
                >
                  Masculino
                </button>
              </div>
            </div>

            {/* Idade */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">Idade (anos)</label>
              <input
                id="input-student-age"
                type="number"
                min="12"
                max="99"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-emerald-500 transition-all"
              />
            </div>

            {/* Peso */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">Peso Corporal (kg)</label>
              <input
                id="input-student-weight"
                type="number"
                step="0.1"
                min="30"
                max="250"
                value={weightKg}
                onChange={(e) => setWeightKg(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-emerald-500 transition-all"
              />
            </div>

            {/* Altura */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">Altura (cm)</label>
              <input
                id="input-student-height"
                type="number"
                min="100"
                max="230"
                value={heightCm}
                onChange={(e) => setHeightCm(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-emerald-500 transition-all"
              />
            </div>

            {/* Nível do Aluno */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">Nível de Treinamento</label>
              <select
                id="select-student-level"
                value={level}
                onChange={(e) => setLevel(e.target.value as FitnessLevel)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-emerald-500 transition-all"
              >
                <option value="Iniciante">Iniciante (0-6 meses)</option>
                <option value="Intermediário">Intermediário (6-24 meses)</option>
                <option value="Avançado">Avançado (+2 anos de treino)</option>
                <option value="Atleta">Atleta / Alta Performance</option>
              </select>
            </div>

            {/* Frequência Semanal */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">Frequência Semanal</label>
              <select
                id="select-student-frequency"
                value={frequencyDays}
                onChange={(e) => setFrequencyDays(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm focus:outline-none focus:border-emerald-500 transition-all"
              >
                <option value={2}>2 dias na semana</option>
                <option value={3}>3 dias na semana (Ideal Fullbody)</option>
                <option value={4}>4 dias na semana (A/B ou Upper/Lower)</option>
                <option value={5}>5 dias na semana (A/B/C ou PPL)</option>
                <option value={6}>6 dias na semana (Alta Frequência)</option>
              </select>
            </div>

            {/* Objetivo Principal */}
            <div className="sm:col-span-2 space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">
                Objetivo Principal do Aluno <span className="text-emerald-400">*</span>
              </label>
              <select
                id="select-student-goal"
                value={goal}
                onChange={(e) => setGoal(e.target.value as PrimaryGoal)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm font-medium focus:outline-none focus:border-emerald-500 transition-all"
              >
                {goalsList.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>

            {/* Telefone / WhatsApp */}
            <div className="sm:col-span-2 space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">WhatsApp do Aluno (com DDD)</label>
              <input
                id="input-student-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Ex: 11999998888 (para envio direto)"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 transition-all"
              />
            </div>
          </div>

          {/* DEDICATED HISTORICAL MEMORY & ANTI-REPETITION PANEL */}
          {pastExercises.length > 0 && (
            <div className="mt-4 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-teal-950/30 border border-emerald-500/30 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0">
                    <History className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>Histórico de Treinos & Memória Ativa de {name || 'Aluno'}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        {pastExercises.length} exercícios arquivados
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      O sistema detectou {selectedStudent?.savedPlans?.length || 1} ficha(s) anterior(es). O próximo treino não repetirá estes exercícios.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0">
                  <label className="flex items-center gap-2 cursor-pointer select-none bg-slate-800/90 border border-slate-700 px-3 py-1.5 rounded-xl">
                    <input
                      type="checkbox"
                      id="checkbox-avoid-repeats"
                      checked={avoidPreviousExercises}
                      onChange={(e) => setAvoidPreviousExercises(e.target.checked)}
                      className="w-4 h-4 text-emerald-500 rounded border-slate-600 focus:ring-emerald-500 accent-emerald-500"
                    />
                    <span className="text-xs font-semibold text-emerald-300">Anti-Repetição Ativo</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowHistoryExercises(!showHistoryExercises)}
                    className="text-xs text-slate-400 hover:text-white px-2.5 py-1.5 rounded-xl bg-slate-800/60 border border-slate-700/60 transition-all"
                  >
                    {showHistoryExercises ? 'Ocultar' : 'Ver Lista'}
                  </button>
                </div>
              </div>

              {showHistoryExercises && (
                <div className="pt-2 border-t border-slate-800/80">
                  <span className="text-[11px] font-semibold text-slate-400 block mb-2">
                    Exercícios presentes nas fichas anteriores que serão evitados:
                  </span>
                  <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto pr-1">
                    {pastExercises.map((exName, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700/80 text-[11px]"
                      >
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        {exName}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* SECTION 2: Botões de Modalidade e Estrutura do Treino */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-md">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold text-sm">
              2
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Modalidade & Estrutura de Treino</h2>
              <p className="text-xs text-slate-400">Escolha a ênfase solicitada pelo educador físico</p>
            </div>
          </div>

          {/* Modality Selector Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
            {/* FULLBODY */}
            <button
              type="button"
              id="btn-modality-fullbody"
              onClick={() => handleModalityChange('fullbody')}
              className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden group ${
                modality === 'fullbody'
                  ? 'bg-emerald-950/50 border-emerald-500/60 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-500'
                  : 'bg-slate-800/40 border-slate-700/70 hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Flame className="w-5 h-5" />
                </span>
                {modality === 'fullbody' && (
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-emerald-500 text-slate-950">
                    Selecionado
                  </span>
                )}
              </div>
              <h3 className="font-bold text-sm text-white">Treino Fullbody</h3>
              <p className="text-xs text-slate-400 mt-1">
                Corpo inteiro por sessão. Máxima eficiência metabólica e síntese semanal.
              </p>
            </button>

            {/* TREINOS EM CASA */}
            <button
              type="button"
              id="btn-modality-casa"
              onClick={() => handleModalityChange('casa')}
              className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden group ${
                modality === 'casa'
                  ? 'bg-amber-950/50 border-amber-500/60 shadow-lg shadow-amber-500/10 ring-1 ring-amber-500'
                  : 'bg-slate-800/40 border-slate-700/70 hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Home className="w-5 h-5" />
                </span>
                {modality === 'casa' && (
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-amber-400 text-slate-950">
                    Selecionado
                  </span>
                )}
              </div>
              <h3 className="font-bold text-sm text-white">Treinos em Casa (30 Dias)</h3>
              <p className="text-xs text-slate-400 mt-1">
                Gera opções de Treino A, B e C prontas para 30 dias com vídeos diretos.
              </p>
            </button>

            {/* MUSCULAÇÃO (A/B, A/B/C) */}
            <button
              type="button"
              id="btn-modality-musculacao"
              onClick={() => handleModalityChange('musculacao')}
              className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden group ${
                modality === 'musculacao'
                  ? 'bg-emerald-950/50 border-emerald-500/60 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-500'
                  : 'bg-slate-800/40 border-slate-700/70 hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="w-9 h-9 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center">
                  <Layers className="w-5 h-5" />
                </span>
                {modality === 'musculacao' && (
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-teal-400 text-slate-950">
                    Selecionado
                  </span>
                )}
              </div>
              <h3 className="font-bold text-sm text-white">Musculação (A/B, A/B/C)</h3>
              <p className="text-xs text-slate-400 mt-1">
                Divisões especializadas com pirâmides e bi-sets na academia.
              </p>
            </button>

            {/* INFERIORES / PERNAS EXCLUSIVAS */}
            <button
              type="button"
              id="btn-modality-inferiores"
              onClick={() => handleModalityChange('inferiores')}
              className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden group ${
                modality === 'inferiores'
                  ? 'bg-emerald-950/50 border-emerald-500/60 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-500'
                  : 'bg-slate-800/40 border-slate-700/70 hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="w-9 h-9 rounded-xl bg-pink-500/20 text-pink-400 flex items-center justify-center">
                  <Dumbbell className="w-5 h-5" />
                </span>
                {modality === 'inferiores' && (
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-pink-400 text-slate-950">
                    Selecionado
                  </span>
                )}
              </div>
              <h3 className="font-bold text-sm text-white">Inferiores / Pernas</h3>
              <p className="text-xs text-slate-400 mt-1">
                Treino 100% individualizado de coxas, glúteos e panturrilhas.
              </p>
            </button>

            {/* MOBILIDADE ARTICULAR */}
            <button
              type="button"
              id="btn-modality-mobilidade"
              onClick={() => handleModalityChange('mobilidade')}
              className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden group ${
                modality === 'mobilidade'
                  ? 'bg-emerald-950/50 border-emerald-500/60 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-500'
                  : 'bg-slate-800/40 border-slate-700/70 hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                  <Activity className="w-5 h-5" />
                </span>
                {modality === 'mobilidade' && (
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-cyan-400 text-slate-950">
                    Selecionado
                  </span>
                )}
              </div>
              <h3 className="font-bold text-sm text-white">Mobilidade Articular</h3>
              <p className="text-xs text-slate-400 mt-1">
                Amplitude e descompressão articular para prevenção de lesões.
              </p>
            </button>
          </div>

          {/* Home Workout Equipment Selector (if modality === 'casa') */}
          {modality === 'casa' && (
            <div className="p-5 rounded-2xl bg-amber-950/20 border border-amber-500/40 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <label className="block text-xs font-bold text-amber-300">
                    Equipamentos Disponíveis na Casa do Aluno:
                  </label>
                  <p className="text-[11px] text-amber-400/90 mt-0.5">
                    ✨ O sistema prescreve automaticamente o plano de 30 dias com <strong>Treino A (Inferiores & Glúteos)</strong>, <strong>Treino B (Superiores & Puxar/Empurrar)</strong> e <strong>Treino C (Full Body Metabólico)</strong> vinculados aos vídeos demonstrativos.
                  </p>
                </div>
                <span className="text-[10px] px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold uppercase tracking-wider">
                  Periodização 30 Dias (A, B, C)
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                {[
                  {
                    id: 'mixed_home' as HomeEquipmentType,
                    title: '🔄 Misto / Completo em Casa',
                    desc: 'Peso corporal + elásticos + halteres/pesos livres',
                  },
                  {
                    id: 'bodyweight_only' as HomeEquipmentType,
                    title: '🧘 Peso Corporal (Calistenia)',
                    desc: 'Zero equipamento: chão, sofá, cadeiras e toalha',
                  },
                  {
                    id: 'elastic_bands' as HomeEquipmentType,
                    title: '🎗️ Acessórios & Elásticos',
                    desc: 'Minibands, superbands, caneleiras e fitas',
                  },
                  {
                    id: 'dumbbells_free_weights' as HomeEquipmentType,
                    title: '🏋️ Pesos Livres & Halteres',
                    desc: 'Halteres reguláveis, kettlebell, anilhas ou barras',
                  },
                ].map((eq) => (
                  <button
                    key={eq.id}
                    type="button"
                    onClick={() => setHomeEquipment(eq.id)}
                    className={`p-3 rounded-xl text-left border transition-all ${
                      homeEquipment === eq.id
                        ? 'bg-amber-500/20 border-amber-400 text-amber-200 ring-1 ring-amber-400 font-bold'
                        : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700/80'
                    }`}
                  >
                    <span className="block text-xs text-white font-bold">{eq.title}</span>
                    <span className="block text-[10px] text-slate-400 font-normal mt-0.5">{eq.desc}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Sub-splits if Musculação selected */}
          {modality === 'musculacao' && (
            <div className="p-4 rounded-2xl bg-slate-800/50 border border-slate-700/60 space-y-3">
              <label className="block text-xs font-bold text-slate-200">Escolha a Divisão de Treino:</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(['A/B', 'A/B/C', 'Superior/Inferior', 'Push/Pull/Legs'] as SplitType[]).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setSplitType(st)}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-all ${
                      splitType === st
                        ? 'bg-teal-500/20 text-teal-300 border-teal-500/50 font-bold'
                        : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:bg-slate-700/80'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Técnicas Avançadas (Pirâmides, Drop-Sets, Bi-Sets) */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-200">
                Técnicas Avançadas & Periodização (Selecione uma ou mais):
              </label>
              <span className="text-[11px] text-slate-400">Adaptadas aos níveis dos alunos</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
              {[
                { name: 'Tradicional', desc: 'Séries e reps lineares' },
                { name: 'Pirâmide', desc: '12-10-8-6 carga progressiva' },
                { name: 'Drop-set', desc: 'Redução de carga até a falha' },
                { name: 'Bi-set', desc: '2 exercícios conjugados sem pausa' },
                { name: 'Rest-pause', desc: 'Micro-pausas de 10s' },
                { name: 'Excêntrica Lenta', desc: 'Fase negativa de 3-4s' },
              ].map((tech) => {
                const isSelected = selectedTechniques.includes(tech.name as AdvancedTechnique);
                return (
                  <button
                    key={tech.name}
                    type="button"
                    onClick={() => toggleTechnique(tech.name as AdvancedTechnique)}
                    className={`p-3 rounded-xl text-left border transition-all ${
                      isSelected
                        ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 shadow-sm'
                        : 'bg-slate-800/40 text-slate-400 border-slate-700/70 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-white">{tech.name}</span>
                      {isSelected && <Zap className="w-3.5 h-3.5 text-emerald-400" />}
                    </div>
                    <span className="text-[10px] text-slate-400 leading-tight block">{tech.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* SECTION 3: Exercícios Personalizados & Upload de GIFs / URLs Diretas */}
        <CustomExerciseUploader
          customExercises={customExercises}
          onChangeCustomExercises={setCustomExercises}
          onPreviewVideo={(url, name) => setPreviewVideo({ url, name })}
        />

        {/* SECTION 4: Motor de Geração, Escopo e Discriminações */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-md">
          <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-sm">
              4
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Motor de Criação & Discriminações do Professor</h2>
              <p className="text-xs text-slate-400">Escolha entre Inteligência Artificial ou Algoritmo Rápido e defina observações</p>
            </div>
          </div>

          {/* Engine Selector (IA vs Algoritmo) */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-200">Modo de Geração do Treino:</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                id="btn-engine-ai"
                onClick={() => setGenerationEngine('ai_gemini')}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  generationEngine === 'ai_gemini'
                    ? 'bg-emerald-950/40 border-emerald-500 text-white ring-1 ring-emerald-500 shadow-md'
                    : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span className="font-bold text-sm text-white">Inteligência Artificial (Gemini AI)</span>
                  </div>
                  {generationEngine === 'ai_gemini' && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500 text-slate-950">Ativo</span>
                  )}
                </div>
                <p className="text-xs text-slate-400">
                  Análise neural profunda que interpreta as restrições, histórico e notas do professor para criar fichas únicas.
                </p>
              </button>

              <button
                type="button"
                id="btn-engine-algo"
                onClick={() => setGenerationEngine('algorithmic')}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  generationEngine === 'algorithmic'
                    ? 'bg-emerald-950/40 border-emerald-500 text-white ring-1 ring-emerald-500 shadow-md'
                    : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-teal-400" />
                    <span className="font-bold text-sm text-white">Algorítmico Rápido (Biomecânico)</span>
                  </div>
                  {generationEngine === 'algorithmic' && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-teal-400 text-slate-950">Ativo</span>
                  )}
                </div>
                <p className="text-xs text-slate-400">
                  Geração instantânea baseada no banco de dados biomecânico com exclusão estrita de repetições.
                </p>
              </button>
            </div>
          </div>

          {/* Generation Scope Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-200">O que deseja gerar?</label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                id="btn-scope-both"
                onClick={() => setGenerationScope('both')}
                className={`p-3.5 rounded-2xl border text-left transition-all ${
                  generationScope === 'both'
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-white ring-1 ring-emerald-500/40 shadow-md'
                    : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-sm text-white mb-1">
                  <span>🏋️ + 🥗</span> Treino + Dieta Completa
                </div>
                <p className="text-xs text-slate-400">Prescrição completa integrada com cálculo de TMB e macros.</p>
              </button>

              <button
                type="button"
                id="btn-scope-workout"
                onClick={() => setGenerationScope('workout_only')}
                className={`p-3.5 rounded-2xl border text-left transition-all ${
                  generationScope === 'workout_only'
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-white ring-1 ring-emerald-500/40 shadow-md'
                    : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-sm text-white mb-1">
                  <span>🏋️</span> Apenas Ficha de Treino
                </div>
                <p className="text-xs text-slate-400">Focado exclusivamente na rotina de exercícios, séries e cargas.</p>
              </button>

              <button
                type="button"
                id="btn-scope-diet"
                onClick={() => setGenerationScope('diet_only')}
                className={`p-3.5 rounded-2xl border text-left transition-all ${
                  generationScope === 'diet_only'
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-white ring-1 ring-emerald-500/40 shadow-md'
                    : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-sm text-white mb-1">
                  <span>🥗</span> Apenas Plano Nutricional
                </div>
                <p className="text-xs text-slate-400">Cardápio calculado para os objetivos e calorias diárias.</p>
              </button>
            </div>
          </div>

          {/* Campo para o professor discriminar tudo que quer no treino */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-200">
                Discriminações & Pedidos Específicos do Professor:
              </label>
              <span className="text-[11px] text-emerald-400 font-medium">Personalização Total</span>
            </div>
            <textarea
              id="textarea-coach-notes"
              rows={3}
              value={customCoachNotes}
              onChange={(e) => setCustomCoachNotes(e.target.value)}
              placeholder="Ex: 'Aluna relata desconforto na lombar, evitar agachamento livre pesado. Dar ênfase máxima em elevação pélvica, mesa flexora com pico de contração de 2s e cadeira abdutora. Na dieta, prefere opções sem lactose.'"
              className="w-full px-4 py-3 rounded-2xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 transition-all leading-relaxed"
            ></textarea>
          </div>

          {/* Banco de Vídeos do Google Drive Callout */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-950/30 via-slate-900 to-indigo-950/20 border border-indigo-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-inner">
            <div className="flex items-start sm:items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 mt-0.5 sm:mt-0">
                <Video className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white flex items-center gap-2">
                  <span>Banco de Vídeos & Personalização de Exercícios</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 font-bold">
                    Arrastar & Soltar
                  </span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Cada exercício da ficha possui um espaço exclusivo para você arrastar vídeos de demonstração ou colar links do Google Drive.
                </p>
              </div>
            </div>
            <a
              id="btn-creator-drive-videos"
              href={GOOGLE_DRIVE_VIDEOS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-indigo-600/20 shrink-0"
              title="Acessar pasta de vídeos no Google Drive"
            >
              <FolderOpen className="w-4 h-4" />
              <span>Abrir Drive de Vídeos</span>
            </a>
          </div>
        </div>

        {/* Action Button: Gerar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-white">Garantia de Treino Exclusivo</p>
              <p className="text-xs text-slate-400">
                {avoidPreviousExercises && pastExercises.length > 0
                  ? `Proteção anti-repetição ativada: ${pastExercises.length} exercícios arquivados de ${name || 'aluno'} serão substituídos por variações novas.`
                  : `Zero repetição idêntica. Calibrado para as características individuais de ${name || 'seu aluno'}.`}
              </p>
            </div>
          </div>

          <button
            type="submit"
            id="btn-submit-generate-workout"
            disabled={isGenerating}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition-all transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isGenerating ? (
              <>
                <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
                <span>{generationStatus || 'Gerando Prescrição...'}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>{generationEngine === 'ai_gemini' ? 'Gerar com IA (Anti-Repetição)' : 'Gerar Treino Biomecânico'}</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </>
            )}
          </button>
        </div>
      </form>

      {/* Video Player Modal for instant GIF/Video verification */}
      {previewVideo && (
        <VideoPlayerModal
          isOpen={!!previewVideo}
          onClose={() => setPreviewVideo(null)}
          videoUrl={previewVideo.url}
          exerciseName={previewVideo.name}
        />
      )}
    </div>
  );
};
