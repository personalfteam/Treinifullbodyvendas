import React, { useState } from 'react';
import {
  FileDown,
  Printer,
  Share2,
  Play,
  Dumbbell,
  Timer,
  Sparkles,
  Plus,
  Trash2,
  Edit2,
  Check,
  Zap,
  Info,
  ChevronRight,
  Flame,
  Utensils,
  ArrowLeft,
  Calendar,
  Save,
  CheckCircle2,
  MessageCircle,
  Copy,
  Sliders,
  DollarSign,
  Smartphone,
  UserX,
  ShieldCheck,
  AlertTriangle,
  FolderOpen,
  Video,
  ArrowLeftRight,
  BookOpen
} from 'lucide-react';
import { WorkoutPlan, Student, WorkoutDay, Exercise, AdvancedTechnique } from '../types';
import { exportPlanToPdf, openWhatsAppWithText, generateWhatsAppWorkoutText } from '../utils/pdfExport';
import { GOOGLE_DRIVE_VIDEOS_URL } from '../utils/videoUtils';
import { ExerciseVideoSlot } from './ExerciseVideoSlot';

interface WorkoutViewerProps {
  plan: WorkoutPlan;
  student: Student;
  onUpdatePlan: (updatedPlan: WorkoutPlan) => void;
  onStartSession: (day: WorkoutDay) => void;
  onNavigateToCreator: () => void;
  onNavigateToNutrition: () => void;
  onOpenShareModal?: (student: Student) => void;
  onOpenSubscriptionModal?: (student: Student) => void;
  onOpenStudentPortal?: (studentId: string) => void;
  onDeleteStudent?: (student: Student) => void;
}

export const WorkoutViewer: React.FC<WorkoutViewerProps> = ({
  plan,
  student,
  onUpdatePlan,
  onStartSession,
  onNavigateToCreator,
  onNavigateToNutrition,
  onOpenShareModal,
  onOpenSubscriptionModal,
  onOpenStudentPortal,
  onDeleteStudent,
}) => {
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(0);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  
  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingExercise, setEditingExercise] = useState<Exercise | null>(null);
  const [isEditingMetadata, setIsEditingMetadata] = useState(false);

  // New Exercise Form State
  const [newExName, setNewExName] = useState('');
  const [newExSets, setNewExSets] = useState(3);
  const [newExReps, setNewExReps] = useState('10-12');
  const [newExLoad, setNewExLoad] = useState(15);
  const [newExRest, setNewExRest] = useState(60);
  const [newExMuscle, setNewExMuscle] = useState('Geral');
  const [newExTechnique, setNewExTechnique] = useState('Tradicional');
  const [newExNotes, setNewExNotes] = useState('');
  const [newExVideoUrl, setNewExVideoUrl] = useState('');
  const [newExVideoName, setNewExVideoName] = useState('');

  // Plan Meta Editing State
  const [editTitle, setEditTitle] = useState(plan.title);
  const [editObjective, setEditObjective] = useState(plan.objectiveSummary);
  const [editCoachNotes, setEditCoachNotes] = useState(plan.coachCustomNotes || '');

  const currentDay: WorkoutDay | undefined = plan.workouts[selectedDayIndex] || plan.workouts[0];

  // Handle Load (kg) change for an exercise
  const handleLoadChange = (exerciseId: string, newLoad: number) => {
    const updatedWorkouts = plan.workouts.map((day, dIdx) => {
      if (dIdx !== selectedDayIndex) return day;
      return {
        ...day,
        exercises: day.exercises.map((ex) => {
          if (ex.id !== exerciseId) return ex;
          return {
            ...ex,
            userCurrentLoadKg: Math.max(0, newLoad),
            suggestedLoadKg: Math.max(0, newLoad),
          };
        }),
      };
    });

    onUpdatePlan({
      ...plan,
      workouts: updatedWorkouts,
    });
  };

  // Handle Updating Exercise Video (from Drag & Drop or URL)
  const handleUpdateExerciseVideo = (exerciseId: string, videoUrl: string, videoName?: string) => {
    const updatedWorkouts = plan.workouts.map((day, dIdx) => {
      if (dIdx !== selectedDayIndex) return day;
      return {
        ...day,
        exercises: day.exercises.map((ex) => {
          if (ex.id !== exerciseId) return ex;
          return {
            ...ex,
            videoUrl: videoUrl.trim(),
            videoName: videoName?.trim() || ex.videoName || 'Vídeo de Execução',
          };
        }),
      };
    });

    onUpdatePlan({
      ...plan,
      workouts: updatedWorkouts,
    });
  };

  // Handle Removing Exercise Video
  const handleRemoveExerciseVideo = (exerciseId: string) => {
    const updatedWorkouts = plan.workouts.map((day, dIdx) => {
      if (dIdx !== selectedDayIndex) return day;
      return {
        ...day,
        exercises: day.exercises.map((ex) => {
          if (ex.id !== exerciseId) return ex;
          const updated = { ...ex };
          delete updated.videoUrl;
          delete updated.videoName;
          return updated;
        }),
      };
    });

    onUpdatePlan({
      ...plan,
      workouts: updatedWorkouts,
    });
  };

  // Handle removing an exercise
  const handleRemoveExercise = (exerciseId: string) => {
    if (!confirm('Deseja remover este exercício da ficha?')) return;
    const updatedWorkouts = plan.workouts.map((day, dIdx) => {
      if (dIdx !== selectedDayIndex) return day;
      return {
        ...day,
        exercises: day.exercises.filter((ex) => ex.id !== exerciseId),
      };
    });

    onUpdatePlan({
      ...plan,
      workouts: updatedWorkouts,
    });
  };

  // Handle duplicate exercise
  const handleDuplicateExercise = (exercise: Exercise) => {
    const duplicatedEx: Exercise = {
      ...exercise,
      id: `ex-dup-${Date.now()}`,
      name: `${exercise.name} (Variação/Cópia)`,
    };

    const updatedWorkouts = plan.workouts.map((day, dIdx) => {
      if (dIdx !== selectedDayIndex) return day;
      return {
        ...day,
        exercises: [...day.exercises, duplicatedEx],
      };
    });

    onUpdatePlan({
      ...plan,
      workouts: updatedWorkouts,
    });
  };

  // Handle adding custom exercise
  const handleAddExerciseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExName.trim() || !currentDay) return;

    const newEx: Exercise = {
      id: `ex-custom-${Date.now()}`,
      name: newExName.trim(),
      muscleGroup: newExMuscle.trim() || 'Geral',
      sets: Number(newExSets) || 3,
      reps: newExReps || '10-12',
      suggestedLoadKg: Number(newExLoad) || 0,
      userCurrentLoadKg: Number(newExLoad) || 0,
      restSeconds: Number(newExRest) || 60,
      technique: newExTechnique || 'Tradicional',
      notes: newExNotes.trim() || 'Adicionado pelo professor.',
      videoUrl: newExVideoUrl.trim() || undefined,
      videoName: newExVideoName.trim() || undefined,
      isCompleted: false,
    };

    const updatedWorkouts = plan.workouts.map((day, dIdx) => {
      if (dIdx !== selectedDayIndex) return day;
      return {
        ...day,
        exercises: [...day.exercises, newEx],
      };
    });

    onUpdatePlan({
      ...plan,
      workouts: updatedWorkouts,
    });

    setNewExName('');
    setNewExNotes('');
    setNewExVideoUrl('');
    setNewExVideoName('');
    setShowAddModal(false);
  };

  // Handle saving edited exercise
  const handleSaveEditedExercise = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingExercise || !currentDay) return;

    const updatedWorkouts = plan.workouts.map((day, dIdx) => {
      if (dIdx !== selectedDayIndex) return day;
      return {
        ...day,
        exercises: day.exercises.map((ex) => (ex.id === editingExercise.id ? editingExercise : ex)),
      };
    });

    onUpdatePlan({
      ...plan,
      workouts: updatedWorkouts,
    });

    setEditingExercise(null);
  };

  // Handle saving plan metadata
  const handleSaveMetadata = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdatePlan({
      ...plan,
      title: editTitle.trim() || plan.title,
      objectiveSummary: editObjective.trim() || plan.objectiveSummary,
      coachCustomNotes: editCoachNotes.trim(),
    });
    setIsEditingMetadata(false);
  };

  const handleDownloadPdf = async () => {
    setIsExportingPdf(true);
    await exportPlanToPdf('printable-pdf-document', `treino-${student.name.toLowerCase().replace(/\s+/g, '-')}.pdf`);
    setIsExportingPdf(false);
  };

  const handleShareWhatsApp = () => {
    const text = generateWhatsAppWorkoutText(plan, student);
    openWhatsAppWithText(student.phone, text);
  };

  const handleCopyStudentLink = () => {
    const baseUrl = window.location.origin + window.location.pathname;
    const url = `${baseUrl}?view=student&studentId=${student.id}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Prominent Workout Delivery & Share Card */}
      <div className="bg-gradient-to-r from-emerald-950/70 via-slate-900 to-teal-950/60 border border-emerald-500/40 rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-bold uppercase tracking-wide">
              <Sparkles className="w-3.5 h-3.5" />
              Treino Pronto para Entrega
            </div>
            <h2 className="text-lg sm:text-xl font-black text-white font-display">
              Entregar esta ficha para {student.name}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Envie o link exclusivo do app para o aluno acessar a ficha com demonstrações em vídeo, registrar cargas e usar o cronômetro.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              id="btn-deliver-whatsapp"
              onClick={handleShareWhatsApp}
              className="px-4 py-3 rounded-2xl bg-[#25D366] hover:bg-[#20bd5a] text-slate-950 font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-[#25D366]/25 transition-all active:scale-95"
            >
              <MessageCircle className="w-4 h-4 stroke-[2.5]" />
              <span>Enviar no WhatsApp</span>
            </button>

            <button
              id="btn-deliver-copy-link"
              onClick={handleCopyStudentLink}
              className={`px-4 py-3 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all shadow-md ${
                copiedLink
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-slate-800 hover:bg-slate-750 text-white border border-slate-700'
              }`}
            >
              {copiedLink ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Link Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copiar Link do App</span>
                </>
              )}
            </button>

            {onOpenStudentPortal && (
              <button
                id="btn-deliver-test-app"
                onClick={() => onOpenStudentPortal(student.id)}
                className="px-4 py-3 rounded-2xl bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 text-xs font-bold flex items-center gap-2 transition-all"
                title="Ver como o aluno visualiza o app"
              >
                <Smartphone className="w-4 h-4" />
                <span>Ver como Aluno</span>
              </button>
            )}

            {onOpenShareModal && (
              <button
                id="btn-deliver-qr-modal"
                onClick={() => onOpenShareModal(student)}
                className="p-3 rounded-2xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 transition-all"
                title="Opções de compartilhamento e QR Code"
              >
                <Share2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl">
        <div className="flex items-center gap-3">
          <button
            onClick={onNavigateToCreator}
            className="p-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-all"
            title="Voltar ao Gerador"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-extrabold text-white font-display">
                Ficha de Treino: {student.name}
              </h1>
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-xs font-bold uppercase">
                {plan.modality === 'casa' ? 'Treino em Casa' : plan.modality}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {student.gender === 'feminino' ? 'Aluna' : 'Aluno'} • {student.age} anos • {student.weightKg}kg • Foco: {student.goal}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Drive de Vídeos Direct Link */}
          <a
            id="btn-workout-drive-videos"
            href={GOOGLE_DRIVE_VIDEOS_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3.5 py-2 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm group"
            title="Abrir Banco de Vídeos no Google Drive"
          >
            <FolderOpen className="w-4 h-4 text-indigo-400 group-hover:scale-110 transition-transform" />
            <span>Drive de Vídeos</span>
          </a>

          {onOpenStudentPortal && (
            <button
              id="btn-workout-view-student-app"
              onClick={() => onOpenStudentPortal(student.id)}
              className="px-3.5 py-2 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/40 text-teal-300 text-xs font-bold flex items-center gap-1.5 transition-all"
              title="Visualizar a experiência do aluno"
            >
              <Smartphone className="w-4 h-4 text-teal-400" />
              <span>Ver App do Aluno</span>
            </button>
          )}

          {onOpenShareModal && (
            <button
              id="btn-workout-share-link"
              onClick={() => onOpenShareModal(student)}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all"
              title="Gerar e compartilhar link direto do aluno"
            >
              <Share2 className="w-4 h-4 text-teal-400" />
              <span>Link do Aluno</span>
            </button>
          )}

          {onOpenSubscriptionModal && (
            <button
              id="btn-workout-manage-subscription"
              onClick={() => onOpenSubscriptionModal(student)}
              className={`px-3.5 py-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all ${
                student.subscriptionStatus === 'canceled'
                  ? 'bg-rose-950/60 border-rose-500/50 text-rose-300 hover:bg-rose-900'
                  : student.subscriptionStatus === 'pending_payment'
                  ? 'bg-amber-950/60 border-amber-500/50 text-amber-300 hover:bg-amber-900'
                  : 'bg-slate-800 hover:bg-slate-750 text-amber-300 border-slate-700'
              }`}
              title="Gerenciar mensalidade / Cancelar ou reativar plano do aluno"
            >
              <DollarSign className="w-4 h-4 text-amber-400" />
              <span>{student.subscriptionStatus === 'canceled' ? 'Desbloquear' : 'Mensalidade'}</span>
            </button>
          )}

          {plan.nutritionPlan && (
            <button
              id="btn-view-nutrition-quick"
              onClick={onNavigateToNutrition}
              className="px-3.5 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-bold flex items-center gap-1.5 transition-all"
            >
              <Utensils className="w-4 h-4" />
              <span>Ver Dieta ({plan.nutritionPlan.dailyCalories} kcal)</span>
            </button>
          )}

          <button
            id="btn-edit-plan-details"
            onClick={() => {
              setEditTitle(plan.title);
              setEditObjective(plan.objectiveSummary);
              setEditCoachNotes(plan.coachCustomNotes || '');
              setIsEditingMetadata(true);
            }}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all"
          >
            <Sliders className="w-4 h-4 text-emerald-400" />
            <span>Editar Ficha</span>
          </button>

          <button
            id="btn-share-whatsapp"
            onClick={handleShareWhatsApp}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all"
          >
            <MessageCircle className="w-4 h-4" />
            <span>WhatsApp</span>
          </button>

          <button
            id="btn-export-pdf"
            onClick={handleDownloadPdf}
            disabled={isExportingPdf}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all"
          >
            {isExportingPdf ? (
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <FileDown className="w-4 h-4 text-emerald-400" />
            )}
            <span>PDF Diagramado</span>
          </button>

          <button
            id="btn-print-workout"
            onClick={() => window.print()}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white transition-all"
            title="Imprimir Direto"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Objective & Coach Notes Banner */}
      {(plan.objectiveSummary || plan.coachCustomNotes) && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-3 relative group">
          <button
            onClick={() => {
              setEditTitle(plan.title);
              setEditObjective(plan.objectiveSummary);
              setEditCoachNotes(plan.coachCustomNotes || '');
              setIsEditingMetadata(true);
            }}
            className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white text-xs flex items-center gap-1 transition-all opacity-80 group-hover:opacity-100"
            title="Editar notas e objetivo"
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Editar Notas</span>
          </button>

          {plan.objectiveSummary && (
            <div className="flex items-start gap-3 pr-20">
              <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                <Sparkles className="w-4 h-4" />
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                <strong>Estratégia Biomecânica:</strong> {plan.objectiveSummary}
              </p>
            </div>
          )}

          {plan.coachCustomNotes && (
            <div className="flex items-start gap-3 pt-2 border-t border-slate-800">
              <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
                <Info className="w-4 h-4" />
              </div>
              <p className="text-xs sm:text-sm text-amber-200/90 leading-relaxed">
                <strong>Orientações do Educador Físico:</strong> {plan.coachCustomNotes}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Workout Days Tabs (Treino A, Treino B, etc.) */}
      {plan.workouts.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {plan.workouts.map((day, dIdx) => (
            <button
              key={day.id}
              onClick={() => setSelectedDayIndex(dIdx)}
              className={`px-5 py-3 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2.5 transition-all whitespace-nowrap border ${
                selectedDayIndex === dIdx
                  ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-lg shadow-emerald-500/20'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              <Dumbbell className="w-4 h-4" />
              <span>{day.code || `Treino ${dIdx + 1}`}</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                selectedDayIndex === dIdx ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-slate-400'
              }`}>
                {day.exercises.length} ex
              </span>
            </button>
          ))}
        </div>
      )}

      {/* Active Day Card */}
      {currentDay && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          {/* Day Title & Launch Mode Button */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white font-display">{currentDay.name}</h2>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Foco: <span className="text-slate-300 font-medium">{currentDay.focus}</span> • Descanso sugerido entre séries: <strong className="text-emerald-400">{currentDay.suggestedRestSeconds}s</strong>
              </p>
            </div>

            {/* Iniciar Treino com Cronômetro */}
            <button
              id="btn-start-individual-session"
              onClick={() => onStartSession(currentDay)}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all transform active:scale-95"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Iniciar com Cronômetro</span>
            </button>
          </div>

          {/* Exercise List */}
          <div className="space-y-3">
            {currentDay.exercises.map((ex, exIdx) => {
              const currentLoad = ex.userCurrentLoadKg ?? ex.suggestedLoadKg ?? 0;

              return (
                <div
                  key={ex.id}
                  className="bg-slate-800/60 hover:bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 sm:p-5 transition-all space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    {/* Exercise info */}
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-xl bg-slate-700 text-emerald-400 flex items-center justify-center font-bold text-sm shrink-0 mt-0.5">
                        {exIdx + 1}
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="font-bold text-sm sm:text-base text-white">{ex.name}</h3>
                          <span className="px-2 py-0.5 rounded-md bg-slate-700 text-[10px] font-semibold text-slate-300">
                            {ex.muscleGroup}
                          </span>
                          {ex.technique && ex.technique !== 'Tradicional' && (
                            <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold flex items-center gap-1">
                              <Zap className="w-3 h-3" />
                              {ex.technique}
                            </span>
                          )}
                        </div>
                        {ex.notes && (
                          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                            💡 {ex.notes}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Sets, Reps & Rest badges */}
                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/70 text-center">
                        <span className="text-[10px] text-slate-400 block">Séries</span>
                        <span className="text-xs font-bold text-white">{ex.sets}x</span>
                      </div>
                      <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/70 text-center">
                        <span className="text-[10px] text-slate-400 block">Reps</span>
                        <span className="text-xs font-bold text-white">{ex.reps}</span>
                      </div>
                      <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700/70 text-center">
                        <span className="text-[10px] text-slate-400 block">Descanso</span>
                        <span className="text-xs font-bold text-cyan-400">{ex.restSeconds}s</span>
                      </div>
                    </div>
                  </div>

                  {/* Espaço para Vídeo de Execução / Drag & Drop / Google Drive */}
                  <div className="pt-1">
                    <ExerciseVideoSlot
                      videoUrl={ex.videoUrl}
                      videoName={ex.videoName}
                      exerciseName={ex.name}
                      muscleGroup={ex.muscleGroup}
                      notes={ex.notes}
                      onUpdateVideo={(vUrl, vName) => handleUpdateExerciseVideo(ex.id, vUrl, vName)}
                      onRemoveVideo={() => handleRemoveExerciseVideo(ex.id)}
                    />
                  </div>

                  {/* Carga (kg) Adjuster & Actions for Professor */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-700/50 text-xs">
                    <div className="flex items-center gap-3">
                      <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                        <Dumbbell className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Carga do Aluno:</span>
                      </label>
                      <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700 rounded-xl p-1">
                        <button
                          type="button"
                          onClick={() => handleLoadChange(ex.id, Math.max(0, currentLoad - 2.5))}
                          className="w-6 h-6 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-bold flex items-center justify-center text-xs"
                          title="Diminuir 2.5kg"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          step="0.5"
                          min="0"
                          value={currentLoad}
                          onChange={(e) => handleLoadChange(ex.id, Number(e.target.value))}
                          className="w-14 text-center bg-transparent font-extrabold text-white text-xs focus:outline-none"
                        />
                        <span className="text-[11px] text-slate-400 pr-1">kg</span>
                        <button
                          type="button"
                          onClick={() => handleLoadChange(ex.id, currentLoad + 2.5)}
                          className="w-6 h-6 rounded-lg bg-slate-800 text-slate-300 hover:text-white font-bold flex items-center justify-center text-xs"
                          title="Aumentar 2.5kg"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {/* Editar Exercício */}
                      <button
                        type="button"
                        onClick={() => setEditingExercise({ ...ex })}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center gap-1 transition-all"
                        title="Editar detalhes do exercício"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Editar</span>
                      </button>

                      {/* Duplicar Exercício */}
                      <button
                        type="button"
                        onClick={() => handleDuplicateExercise(ex)}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center gap-1 transition-all"
                        title="Duplicar exercício"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Clonar</span>
                      </button>

                      {/* Excluir */}
                      <button
                        type="button"
                        onClick={() => handleRemoveExercise(ex.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-all"
                        title="Remover exercício"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Add Exercise Button */}
          <div className="pt-2">
            <button
              id="btn-add-custom-exercise"
              onClick={() => setShowAddModal(true)}
              className="w-full py-3.5 rounded-2xl border border-dashed border-slate-700 hover:border-emerald-500/50 bg-slate-800/30 hover:bg-slate-800/60 text-slate-300 hover:text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Exercício Personalizado ao Treino</span>
            </button>
          </div>
        </div>
      )}

      {/* MODAL 1: Adicionar Exercício */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 my-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base">Adicionar Novo Exercício</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleAddExerciseSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Nome do Exercício *</label>
                <input
                  type="text"
                  required
                  value={newExName}
                  onChange={(e) => setNewExName(e.target.value)}
                  placeholder="Ex: Elevação Pélvica com Miniband"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Grupo Muscular</label>
                  <input
                    type="text"
                    value={newExMuscle}
                    onChange={(e) => setNewExMuscle(e.target.value)}
                    placeholder="Ex: Glúteos"
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Técnica Especial</label>
                  <select
                    value={newExTechnique}
                    onChange={(e) => setNewExTechnique(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  >
                    <option value="Tradicional">Tradicional</option>
                    <option value="Pirâmide">Pirâmide</option>
                    <option value="Drop-set">Drop-set</option>
                    <option value="Bi-set">Bi-set</option>
                    <option value="Rest-pause">Rest-pause</option>
                    <option value="Excêntrica Lenta">Excêntrica Lenta</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Séries</label>
                  <input
                    type="number"
                    value={newExSets}
                    onChange={(e) => setNewExSets(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Repetições</label>
                  <input
                    type="text"
                    value={newExReps}
                    onChange={(e) => setNewExReps(e.target.value)}
                    placeholder="Ex: 12-15"
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Carga Sugerida (kg)</label>
                  <input
                    type="number"
                    value={newExLoad}
                    onChange={(e) => setNewExLoad(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Descanso (segundos)</label>
                  <input
                    type="number"
                    value={newExRest}
                    onChange={(e) => setNewExRest(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Observações Biomecânicas</label>
                <textarea
                  rows={2}
                  value={newExNotes}
                  onChange={(e) => setNewExNotes(e.target.value)}
                  placeholder="Ex: Segurar 2 segundos no pico de contração no topo."
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                ></textarea>
              </div>

              {/* Video configuration for new exercise */}
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-750 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider text-indigo-400 flex items-center gap-1">
                    <Video className="w-3 h-3" /> Vídeo de Demonstração (Opcional)
                  </span>
                  <a
                    href={GOOGLE_DRIVE_VIDEOS_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                  >
                    <FolderOpen className="w-3 h-3" /> Abrir Drive
                  </a>
                </div>
                <input
                  type="text"
                  value={newExVideoUrl}
                  onChange={(e) => setNewExVideoUrl(e.target.value)}
                  placeholder="Cole o link da pasta ou vídeo do Google Drive..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono"
                />
                <input
                  type="text"
                  value={newExVideoName}
                  onChange={(e) => setNewExVideoName(e.target.value)}
                  placeholder="Título do vídeo (opcional)"
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400"
                >
                  Inserir Exercício
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Editar Exercício Existente */}
      {editingExercise && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 my-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base">Editar Exercício</h3>
              <button
                onClick={() => setEditingExercise(null)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleSaveEditedExercise} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Nome do Exercício *</label>
                <input
                  type="text"
                  required
                  value={editingExercise.name}
                  onChange={(e) => setEditingExercise({ ...editingExercise, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Grupo Muscular</label>
                  <input
                    type="text"
                    value={editingExercise.muscleGroup}
                    onChange={(e) => setEditingExercise({ ...editingExercise, muscleGroup: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Técnica Especial</label>
                  <select
                    value={editingExercise.technique || 'Tradicional'}
                    onChange={(e) => setEditingExercise({ ...editingExercise, technique: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  >
                    <option value="Tradicional">Tradicional</option>
                    <option value="Pirâmide">Pirâmide</option>
                    <option value="Drop-set">Drop-set</option>
                    <option value="Bi-set">Bi-set</option>
                    <option value="Rest-pause">Rest-pause</option>
                    <option value="Excêntrica Lenta">Excêntrica Lenta</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Séries</label>
                  <input
                    type="number"
                    value={editingExercise.sets}
                    onChange={(e) => setEditingExercise({ ...editingExercise, sets: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Repetições</label>
                  <input
                    type="text"
                    value={editingExercise.reps}
                    onChange={(e) => setEditingExercise({ ...editingExercise, reps: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Carga Atual (kg)</label>
                  <input
                    type="number"
                    value={editingExercise.userCurrentLoadKg ?? editingExercise.suggestedLoadKg}
                    onChange={(e) =>
                      setEditingExercise({
                        ...editingExercise,
                        userCurrentLoadKg: Number(e.target.value),
                        suggestedLoadKg: Number(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Descanso (segundos)</label>
                  <input
                    type="number"
                    value={editingExercise.restSeconds}
                    onChange={(e) => setEditingExercise({ ...editingExercise, restSeconds: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Orientações Técnicas</label>
                <textarea
                  rows={2}
                  value={editingExercise.notes || ''}
                  onChange={(e) => setEditingExercise({ ...editingExercise, notes: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                ></textarea>
              </div>

              {/* Video configuration for editing exercise */}
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-750 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider text-indigo-400 flex items-center gap-1">
                    <Video className="w-3 h-3" /> Vídeo de Demonstração (Opcional)
                  </span>
                  <a
                    href={GOOGLE_DRIVE_VIDEOS_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                  >
                    <FolderOpen className="w-3 h-3" /> Abrir Drive
                  </a>
                </div>
                <input
                  type="text"
                  value={editingExercise.videoUrl || ''}
                  onChange={(e) => setEditingExercise({ ...editingExercise, videoUrl: e.target.value })}
                  placeholder="Cole o link da pasta ou vídeo do Google Drive..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono"
                />
                <input
                  type="text"
                  value={editingExercise.videoName || ''}
                  onChange={(e) => setEditingExercise({ ...editingExercise, videoName: e.target.value })}
                  placeholder="Título do vídeo (opcional)"
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingExercise(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400"
                >
                  Salvar Alterações
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Editar Detalhes da Ficha / Estratégia do Professor */}
      {isEditingMetadata && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 my-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base">Editar Estratégia e Título da Ficha</h3>
              <button
                onClick={() => setIsEditingMetadata(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleSaveMetadata} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Título do Programa</label>
                <input
                  type="text"
                  required
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-emerald-500 font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Estratégia Biomecânica</label>
                <textarea
                  rows={3}
                  value={editObjective}
                  onChange={(e) => setEditObjective(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                ></textarea>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Orientações do Educador Físico / Notas Gerais
                </label>
                <textarea
                  rows={3}
                  value={editCoachNotes}
                  onChange={(e) => setEditCoachNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                ></textarea>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsEditingMetadata(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400"
                >
                  Salvar Ficha
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
