import {
  DRIVE_BARBELL_VIDEOS,
  DRIVE_BATTLE_ROPE_VIDEOS,
  DRIVE_MEDICINE_BALL_VIDEOS,
  DRIVE_KETTLEBELL_VIDEOS,
  DRIVE_MYOFASCIAL_VIDEOS,
  DRIVE_MOBILITY_LPO_MINIBAND_VIDEOS,
  DRIVE_BODYWEIGHT_CORE_VIDEOS,
  DRIVE_TRX_SUSPENSION_VIDEOS,
} from './driveVideoFiles';

export interface ExerciseVideoEntry {
  id: string;
  name: string;
  aliases: string[];
  muscleGroup: string;
  category: 'inferiores' | 'superiores' | 'core' | 'funcional' | 'mobilidade' | 'aquecimento';
  videoUrl: string;
  provider: 'drive' | 'direct';
  description: string;
  equipment?: string;
}

export const VIDEO_LIBRARY: ExerciseVideoEntry[] = [
  // ==========================================
  // 1. INFERIORES - QUADRÍCEPS & GLÚTEOS & POSTERIOR (COM BARRA / HALTER / LIVRE)
  // ==========================================
  {
    id: 'vid-agachamento-livre',
    name: 'Agachamento Livre com Barra',
    aliases: ['agachamento', 'agachamento livre', 'back squat', 'squat', 'agachamento costas', 'agachamento com barra'],
    muscleGroup: 'Quadríceps',
    category: 'inferiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[0] || 'https://drive.google.com/file/d/1FjrWuGsDT5HGJdyPTdAadphysdBDCXon/view?usp=drive_link',
    provider: 'drive',
    description: 'Pés na largura dos ombros, desça flexionando quadril e joelhos mantendo a coluna neutra e peito aberto.',
    equipment: 'Barra Olímpica / Halteres'
  },
  {
    id: 'vid-agachamento-goblet',
    name: 'Agachamento Goblet com Halter / Kettlebell',
    aliases: ['goblet squat', 'agachamento goblet', 'agachamento com halter no peito', 'goblet'],
    muscleGroup: 'Quadríceps',
    category: 'inferiores',
    videoUrl: DRIVE_KETTLEBELL_VIDEOS[1] || 'https://drive.google.com/file/d/10ehJgxmRV9DEy204RFmGvvY3I5EaRGGF/view?usp=drive_link',
    provider: 'drive',
    description: 'Segure o halter ou kettlebell junto ao peito, cotovelos apontados para baixo, desça profundo mantendo o tronco ereto.',
    equipment: 'Halter / Kettlebell'
  },
  {
    id: 'vid-agachamento-bulgaro',
    name: 'Agachamento Búlgaro com Halteres',
    aliases: ['bulgaro', 'agachamento bulgaro', 'bulgarian split squat', 'split squat', 'bulgaro com halteres'],
    muscleGroup: 'Quadríceps',
    category: 'inferiores',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[0] || 'https://drive.google.com/file/d/1bRQfnrr7hKCBZKc5euoj8_4jN1hWvyYw/view?usp=drive_link',
    provider: 'drive',
    description: 'Apoie o peito do pé de trás em um banco. Desça verticalmente focando o peso na perna da frente.',
    equipment: 'Halteres / Banco'
  },
  {
    id: 'vid-leg-press-45',
    name: 'Leg Press 45°',
    aliases: ['leg press', 'leg press 45', 'leg 45', 'legpress'],
    muscleGroup: 'Quadríceps',
    category: 'inferiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[2] || 'https://drive.google.com/file/d/170uywtQX2NTkyhRP7FEhmPIttDO2aDIP/view?usp=drive_link',
    provider: 'drive',
    description: 'Mantenha toda a extensão da coluna e glúteos apoiados. Não hiperestenda os joelhos no topo.',
    equipment: 'Máquina Leg Press 45'
  },
  {
    id: 'vid-cadeira-extensora',
    name: 'Cadeira Extensora',
    aliases: ['extensora', 'cadeira extensora', 'extensao de pernas', 'leg extension'],
    muscleGroup: 'Quadríceps',
    category: 'inferiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[3] || 'https://drive.google.com/file/d/1n3_uASR7WHdxXk0HmVu8aMt4S80eoKUF/view?usp=drive_link',
    provider: 'drive',
    description: 'Ajuste o rolo sobre os tornozelos. Estenda as pernas controlando o movimento sem impulsos bruscos.',
    equipment: 'Cadeira Extensora'
  },
  {
    id: 'vid-afundo-passada',
    name: 'Passada / Avanço / Afundo com Halteres',
    aliases: ['passada', 'avanco', 'afundo', 'walking lunge', 'lunge', 'afundo com halteres', 'passada com halteres'],
    muscleGroup: 'Quadríceps',
    category: 'inferiores',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[1] || 'https://drive.google.com/file/d/1JZfICNdL0Ib5VV4iY7cJo9Sdefo8E_5D/view?usp=drive_link',
    provider: 'drive',
    description: 'Dê um passo à frente flexionando ambos os joelhos a 90°. O joelho de trás quase toca o chão.',
    equipment: 'Halteres'
  },
  {
    id: 'vid-agachamento-hack',
    name: 'Agachamento Hack Machine',
    aliases: ['hack', 'hack machine', 'agachamento hack', 'hack squat'],
    muscleGroup: 'Quadríceps',
    category: 'inferiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[4] || 'https://drive.google.com/file/d/1O1A94tnNjAgalY7xCBDKhKoa7IdZ4T09/view?usp=drive_link',
    provider: 'drive',
    description: 'Apoio lombar firme na máquina, pés centralizados na plataforma, descida controlada.',
    equipment: 'Máquina Hack'
  },
  {
    id: 'vid-agachamento-sumo',
    name: 'Agachamento Sumô com Halter ou Barra',
    aliases: ['sumo', 'agachamento sumo', 'sumo squat', 'agachamento sumo com halter'],
    muscleGroup: 'Glúteos',
    category: 'inferiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[5] || 'https://drive.google.com/file/d/1BBqoJpN7UZ2Tx7BhTwSqmTFbzgwzqVlV/view?usp=drive_link',
    provider: 'drive',
    description: 'Pés afastados além da largura dos ombros com pontas rodadas para fora a 45°. Foco em adutores e glúteos.',
    equipment: 'Halter / Kettlebell'
  },
  {
    id: 'vid-elevacao-pelvica',
    name: 'Elevação Pélvica com Barra / Hip Thrust',
    aliases: ['elevacao pelvica', 'hip thrust', 'elevacao de quadril', 'ponte de gluteos com barra', 'thrust'],
    muscleGroup: 'Glúteos',
    category: 'inferiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[6] || 'https://drive.google.com/file/d/10gy-V2gLGYg1LKerlbTKk4APU3J59FxW/view?usp=drive_link',
    provider: 'drive',
    description: 'Escápulas apoiadas no banco, barra acolchoada sobre a pelve, empurre o chão com os calcanhares até travar o quadril.',
    equipment: 'Banco, Barra e Protetor'
  },
  {
    id: 'vid-stiff',
    name: 'Stiff com Barra ou Halteres',
    aliases: ['stiff', 'stiff com barra', 'stiff com halteres', 'romanian deadlift', 'rdl'],
    muscleGroup: 'Posterior',
    category: 'inferiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[7] || 'https://drive.google.com/file/d/1F94QgUZ522X7VfKVB9_OX3kPUfKmkyM_/view?usp=drive_link',
    provider: 'drive',
    description: 'Joelhos semi-flexionados fixos, empurre o quadril para trás mantendo as costas perfeitamente seladas.',
    equipment: 'Barra / Halteres'
  },
  {
    id: 'vid-mesa-flexora',
    name: 'Mesa Flexora Deitada',
    aliases: ['mesa flexora', 'flexora deitada', 'leg curl', 'flexao de pernas', 'mesa flexora deitada'],
    muscleGroup: 'Posterior',
    category: 'inferiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[8] || 'https://drive.google.com/file/d/1oPvTcq0__l2u9pBoSbXZvvq40qe-S-jW/view?usp=drive_link',
    provider: 'drive',
    description: 'Deite-se no aparelho com o quadril colado no estofado. Flexione as pernas trazendo o calcanhar ao glúteo.',
    equipment: 'Mesa Flexora'
  },
  {
    id: 'vid-cadeira-flexora',
    name: 'Cadeira Flexora Sentada',
    aliases: ['cadeira flexora', 'flexora sentada', 'seated leg curl'],
    muscleGroup: 'Posterior',
    category: 'inferiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[9] || 'https://drive.google.com/file/d/1xhOZjmKAKYfbxWvMSSFH6WfSZGazJGK3/view?usp=drive_link',
    provider: 'drive',
    description: 'Ajuste a almofada superior travando as coxas. Puxe para baixo com controle na fase excêntrica.',
    equipment: 'Cadeira Flexora'
  },
  {
    id: 'vid-levantamento-terra',
    name: 'Levantamento Terra Convencional',
    aliases: ['levantamento terra', 'deadlift', 'terra', 'dead lift'],
    muscleGroup: 'Posterior',
    category: 'inferiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[10] || 'https://drive.google.com/file/d/1iaonMUzAIDSz6oMtdcqIEs-BcJjqy5v-/view?usp=drive_link',
    provider: 'drive',
    description: 'Barra colada nas canelas, pegada firme, puxe o chão estendendo quadril e joelhos simultaneamente.',
    equipment: 'Barra Olímpica e Anilhas'
  },
  {
    id: 'vid-cadeira-abdutora',
    name: 'Cadeira Abdutora',
    aliases: ['abdutora', 'cadeira abdutora', 'abducao de quadril', 'hip abduction'],
    muscleGroup: 'Glúteos',
    category: 'inferiores',
    videoUrl: DRIVE_MOBILITY_LPO_MINIBAND_VIDEOS[2] || 'https://drive.google.com/file/d/1z9E940ZuOy_PzOetKCGWbEwkhbJjCvyf/view?usp=drive_link',
    provider: 'drive',
    description: 'Sente-se com as costas apoiadas, abra as pernas contraindo o glúteo médio e segure 1s na abertura.',
    equipment: 'Cadeira Abdutora / Mini Band'
  },
  {
    id: 'vid-gemeos-panturrilha',
    name: 'Gêmeos em Pé / Panturrilha no Degrau',
    aliases: ['panturrilha', 'gemeos', 'gemeos em pe', 'panturrilha em pe', 'panturrilha sentada', 'calf raise'],
    muscleGroup: 'Panturrilhas',
    category: 'inferiores',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[2] || 'https://drive.google.com/file/d/1qf4t_mmKePTsB2r3rKar4Xn_zBUIXr1l/view?usp=drive_link',
    provider: 'drive',
    description: 'Suba na ponta dos pés em amplitude máxima, segure 2s no topo e desça alongando o tendão de aquiles.',
    equipment: 'Degrau / Máquina Smith'
  },

  // ==========================================
  // 2. SUPERIORES - PEITORAL & DORSAL & OMBROS
  // ==========================================
  {
    id: 'vid-supino-reto-barra',
    name: 'Supino Reto com Barra',
    aliases: ['supino reto', 'supino com barra', 'bench press', 'supino reto com barra', 'supino'],
    muscleGroup: 'Peitoral',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[11] || 'https://drive.google.com/file/d/16VrS_kS5WRtNh5fi44KVXxCokhDN6e87/view?usp=drive_link',
    provider: 'drive',
    description: 'Pés firmes no chão, escápulas retraídas, desça a barra controlada até o terço médio do peitoral.',
    equipment: 'Banco e Barra'
  },
  {
    id: 'vid-supino-inclinado-halteres',
    name: 'Supino Inclinado com Halteres / Barra',
    aliases: ['supino inclinado', 'supino inclinado com halteres', 'incline bench press', 'incline dumbbell press'],
    muscleGroup: 'Peitoral',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[12] || 'https://drive.google.com/file/d/1bFZxvJMWWEFNkG4zEfWDJP98ztk4D_oD/view?usp=drive_link',
    provider: 'drive',
    description: 'Banco a 30-45°. Empurre os halteres para cima alinhados com a clavícula sem bater no topo.',
    equipment: 'Banco Inclinado e Halteres'
  },
  {
    id: 'vid-flexao-de-braco',
    name: 'Flexão de Braço (Push-Up)',
    aliases: ['flexao', 'flexao de braco', 'push up', 'push-up', 'flexoes', 'flexao no solo'],
    muscleGroup: 'Peitoral',
    category: 'superiores',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[3] || 'https://drive.google.com/file/d/13sAG4RHjc2J5GdYdmlee0Z-DMRm0vRw6/view?usp=drive_link',
    provider: 'drive',
    description: 'Corpo alinhado em prancha, desça o peito próximo ao solo mantendo os cotovelos a 45° do tronco.',
    equipment: 'Peso Corporal'
  },
  {
    id: 'vid-peck-deck-voador',
    name: 'Peck Deck / Voador / Crucifixo',
    aliases: ['peck deck', 'voador', 'crucifixo maquina', 'fly', 'voador peitoral', 'crucifixo'],
    muscleGroup: 'Peitoral',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[13] || 'https://drive.google.com/file/d/11NKCBv-5XH2c8mMB5v4maq89i1VLmgkC/view?usp=drive_link',
    provider: 'drive',
    description: 'Mantenha os cotovelos ligeiramente flexionados, feche na frente apertando o peitoral.',
    equipment: 'Máquina Peck Deck / Halteres'
  },
  {
    id: 'vid-crossover-cabo',
    name: 'Crossover no Cabo / Polia',
    aliases: ['crossover', 'cross over', 'cabo peitoral', 'cable fly'],
    muscleGroup: 'Peitoral',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[14] || 'https://drive.google.com/file/d/1wQzTyaWcyCEHpcP1ECwujFNbO6VtI4WS/view?usp=drive_link',
    provider: 'drive',
    description: 'Tronco ligeiramente inclinado para frente, cruze as mãos à frente do peito focando na contração.',
    equipment: 'Polia Dupla / Crossover'
  },
  {
    id: 'vid-puxada-alta-aberta',
    name: 'Puxada Alta na Polia (Lat Pulldown)',
    aliases: ['puxada alta', 'puxada frente', 'lat pulldown', 'pulley frente', 'puxada aberta'],
    muscleGroup: 'Dorsais',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[15] || 'https://drive.google.com/file/d/1WhYOuYKzPRJn8fXGQaXvzddGmzkFHUuc/view?usp=drive_link',
    provider: 'drive',
    description: 'Puxe a barra em direção à parte superior do peito puxando os cotovelos para baixo e para trás.',
    equipment: 'Polia Alta'
  },
  {
    id: 'vid-remada-curvada-barra',
    name: 'Remada Curvada com Barra',
    aliases: ['remada curvada', 'bent over row', 'barbell row', 'remada com barra'],
    muscleGroup: 'Dorsais',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[16] || 'https://drive.google.com/file/d/1-xhAxhRZijiT-He5KcdC9qKEmc-fNpWP/view?usp=drive_link',
    provider: 'drive',
    description: 'Tronco inclinado a 45°, puxe a barra em direção ao umbigo fechando as escápulas.',
    equipment: 'Barra e Anilhas'
  },
  {
    id: 'vid-remada-baixa-triangulo',
    name: 'Remada Baixa no Triângulo / Polia',
    aliases: ['remada baixa', 'seated cable row', 'remada triangulo', 'remada sentada'],
    muscleGroup: 'Dorsais',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[17] || 'https://drive.google.com/file/d/1lWyxnAE8Jaz6QK2blMaJ6D3zV_NTgAuu/view?usp=drive_link',
    provider: 'drive',
    description: 'Tronco ereto, puxe o pegador em direção ao abdômen aproximando as escápulas sem balançar o corpo.',
    equipment: 'Polia Baixa com Triângulo'
  },
  {
    id: 'vid-remada-serrote-halter',
    name: 'Remada Unilateral com Halter (Serrote)',
    aliases: ['serrote', 'remada unilateral', 'one arm dumbbell row', 'remada serrote', 'remada unilateral com halter'],
    muscleGroup: 'Dorsais',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[18] || 'https://drive.google.com/file/d/1FPUIv2VK3nxYPUAtNcOt71Urx9cvdXDu/view?usp=drive_link',
    provider: 'drive',
    description: 'Um joelho e mão apoiados no banco. Puxe o halter trazendo o cotovelo rente à costela em direção ao quadril.',
    equipment: 'Halter e Banco'
  },
  {
    id: 'vid-remada-trx',
    name: 'Remada no TRX / Fita de Suspensão',
    aliases: ['remada trx', 'trx row', 'fita de suspensao', 'remada suspensa', 'trx'],
    muscleGroup: 'Dorsais',
    category: 'funcional',
    videoUrl: DRIVE_TRX_SUSPENSION_VIDEOS[0] || 'https://drive.google.com/file/d/1XY3GfQwMvtkzCAt4VPVwTS6JKCkr-SVX/view?usp=drive_link',
    provider: 'drive',
    description: 'Corpo alinhado em diagonal, puxe o peito até as manoplas mantendo o core ativado.',
    equipment: 'Fita de Suspensão TRX'
  },
  {
    id: 'vid-desenvolvimento-halteres',
    name: 'Desenvolvimento de Ombros com Halteres ou Barra',
    aliases: ['desenvolvimento', 'desenvolvimento ombros', 'shoulder press', 'overhead press', 'desenvolvimento com halteres', 'desenvolvimento com barra'],
    muscleGroup: 'Ombros',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[19] || 'https://drive.google.com/file/d/1qT6GOSIs_EnFszDnaqnEn6csS3FhWZyv/view?usp=drive_link',
    provider: 'drive',
    description: 'Cotovelos levemente à frente da linha dos ombros, empurre os halteres para cima acima da cabeça.',
    equipment: 'Halteres / Barra e Banco'
  },
  {
    id: 'vid-elevacao-lateral',
    name: 'Elevação Lateral com Halteres',
    aliases: ['elevacao lateral', 'lateral raise', 'side raise', 'elevacao lateral halteres'],
    muscleGroup: 'Ombros',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[20] || 'https://drive.google.com/file/d/13R8TntzX3kKnmr_RTOn_8SbZapZc53yS/view?usp=drive_link',
    provider: 'drive',
    description: 'Eleve os braços lateralmente até a altura dos ombros, com cotovelos ligeiramente flexionados.',
    equipment: 'Halteres'
  },
  {
    id: 'vid-crucifixo-inverso',
    name: 'Crucifixo Inverso / Posterior de Ombro',
    aliases: ['crucifixo inverso', 'rear delt fly', 'posterior de ombro', 'face pull'],
    muscleGroup: 'Ombros',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[21] || 'https://drive.google.com/file/d/1khWO3aDYc0sz1MUGXvkWtuSMEcEVwygE/view?usp=drive_link',
    provider: 'drive',
    description: 'Tronco inclinado para frente ou no cabo/aparelho, abra os braços ativando a porção posterior do deltóide.',
    equipment: 'Halteres / Cabos'
  },

  // ==========================================
  // 3. BRAÇOS - BÍCEPS & TRÍCEPS
  // ==========================================
  {
    id: 'vid-rosca-direta-barra',
    name: 'Rosca Direta com Barra',
    aliases: ['rosca direta', 'bicep curl', 'rosca com barra', 'rosca w', 'rosca direta com barra'],
    muscleGroup: 'Bíceps',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[22] || 'https://drive.google.com/file/d/1ZlP-vD93bIasiD9NWSDwziO5A_Q6QdGI/view?usp=drive_link',
    provider: 'drive',
    description: 'Cotovelos fixos ao lado do corpo, flexione os antebraços erguendo a barra sem balançar o tronco.',
    equipment: 'Barra W / Reta'
  },
  {
    id: 'vid-rosca-martelo',
    name: 'Rosca Martelo com Halteres',
    aliases: ['rosca martelo', 'martelo', 'hammer curl', 'rosca martelo com halteres'],
    muscleGroup: 'Bíceps',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[23] || 'https://drive.google.com/file/d/1uUI-E0CZ4I7bBX03dnATZaa8LwkLppzO/view?usp=drive_link',
    provider: 'drive',
    description: 'Pegada neutra (palmas voltadas uma para a outra), flexione focando em braquial e antebraço.',
    equipment: 'Halteres'
  },
  {
    id: 'vid-triceps-corda',
    name: 'Tríceps na Polia com Corda',
    aliases: ['triceps corda', 'rope pushdown', 'triceps pulley', 'triceps na polia', 'triceps corda polia'],
    muscleGroup: 'Tríceps',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[24] || 'https://drive.google.com/file/d/1OhhIIn0RYakZx5YXFfBAoPkPJYOAPfnm/view?usp=drive_link',
    provider: 'drive',
    description: 'Cotovelos travados na lateral do tronco, empurre a corda para baixo abrindo as pontas no final do movimento.',
    equipment: 'Polia Alta e Corda'
  },
  {
    id: 'vid-triceps-testa',
    name: 'Tríceps Testa com Barra W / Halteres',
    aliases: ['triceps testa', 'skull crusher', 'triceps frances', 'testa'],
    muscleGroup: 'Tríceps',
    category: 'superiores',
    videoUrl: DRIVE_BARBELL_VIDEOS[25] || 'https://drive.google.com/file/d/1jPlNPxEAU-8-Q1vZgPAPt4lln7ngO-we/view?usp=drive_link',
    provider: 'drive',
    description: 'Deitado no banco, flexione apenas os antebraços descendo o peso em direção à testa, mantendo braços verticais.',
    equipment: 'Barra W ou Halteres'
  },

  // ==========================================
  // 4. CORE & ABDÔMEN
  // ==========================================
  {
    id: 'vid-prancha-abdominal',
    name: 'Prancha Abdominal Isométrica (Plank)',
    aliases: ['prancha', 'prancha abdominal', 'plank', 'prancha isometrica', 'prancha frontal'],
    muscleGroup: 'Abdômen',
    category: 'core',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[4] || 'https://drive.google.com/file/d/1dkhJzmVbxJyMyBnYGl_q-L10xTOH7FKV/view?usp=drive_link',
    provider: 'drive',
    description: 'Apoie antebraços e ponta dos pés no chão. Mantenha quadril alinhado com ombros e abdômen bem contraído.',
    equipment: 'Colchonete'
  },
  {
    id: 'vid-mountain-climbers',
    name: 'Mountain Climber / Escalador no Solo',
    aliases: ['escalador', 'mountain climber', 'mountain climbers', 'escalador no solo', 'corrida na prancha'],
    muscleGroup: 'Abdômen',
    category: 'core',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[5] || 'https://drive.google.com/file/d/1F-CxcxM6Ch2VTSgJMszpOSnp-3-S5W6_/view?usp=drive_link',
    provider: 'drive',
    description: 'Posição de prancha alta com mãos no chão, traga os joelhos alternadamente em direção ao peito com agilidade.',
    equipment: 'Colchonete'
  },
  {
    id: 'vid-abdominal-supra',
    name: 'Abdominal Supra no Solo / Crunch',
    aliases: ['abdominal', 'crunch', 'abdominal supra', 'abdominal solo', 'abdominais'],
    muscleGroup: 'Abdômen',
    category: 'core',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[6] || 'https://drive.google.com/file/d/1bgKW1bM3OWh2tvdPKkPBYMWut1Yti046/view?usp=drive_link',
    provider: 'drive',
    description: 'Flexione a coluna torácica aproximando as costelas da pelve, soltando todo o ar na subida.',
    equipment: 'Colchonete'
  },
  {
    id: 'vid-abdominal-infra',
    name: 'Abdominal Infra / Elevação de Pernas',
    aliases: ['infra', 'abdominal infra', 'elevacao de pernas', 'leg raise', 'infra no solo'],
    muscleGroup: 'Abdômen',
    category: 'core',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[7] || 'https://drive.google.com/file/d/1b-KPDTEhYAjWTWYp2xzgVIb2jH-5C0Pe/view?usp=drive_link',
    provider: 'drive',
    description: 'Deitado de barriga para cima, eleve as pernas retas sem descolar a região lombar do chão.',
    equipment: 'Colchonete'
  },
  {
    id: 'vid-russian-twist',
    name: 'Russian Twist / Rotação de Tronco',
    aliases: ['russian twist', 'rotacao russa', 'twist russo', 'abdominal obliquo'],
    muscleGroup: 'Abdômen',
    category: 'core',
    videoUrl: DRIVE_MEDICINE_BALL_VIDEOS[2] || 'https://drive.google.com/file/d/12UxExlIPJJm2dZdMJ4R5CA6uACjxWCf8/view?usp=drive_link',
    provider: 'drive',
    description: 'Sentado com tronco levemente inclinado para trás e pés fora do chão, gire o tronco tocando os dois lados.',
    equipment: 'Colchonete / Medicine Ball / Anilha'
  },

  // ==========================================
  // 5. FUNCIONAL & CONDICIONAMENTO EM GRUPO
  // ==========================================
  {
    id: 'vid-kettlebell-swing',
    name: 'Kettlebell Swing',
    aliases: ['kettlebell swing', 'kb swing', 'swing com kettlebell', 'swing', 'swing kettlebell'],
    muscleGroup: 'Glúteos',
    category: 'funcional',
    videoUrl: DRIVE_KETTLEBELL_VIDEOS[0] || 'https://drive.google.com/file/d/1Rg0mLX3HyLIAc9LMgyRT9vUDnp6G5m7w/view?usp=drive_link',
    provider: 'drive',
    description: 'Movimento de dobradiça de quadril (hip hinge), projete o kettlebell com a força dos glúteos e não dos braços.',
    equipment: 'Kettlebell'
  },
  {
    id: 'vid-corda-naval',
    name: 'Corda Naval / Battle Rope',
    aliases: ['corda naval', 'battle rope', 'ondas na corda', 'corda'],
    muscleGroup: 'Ombros',
    category: 'funcional',
    videoUrl: DRIVE_BATTLE_ROPE_VIDEOS[0] || 'https://drive.google.com/file/d/1DBCAaOfRIvlb8uNJM1QvENJ-rDRAN_z1/view?usp=drive_link',
    provider: 'drive',
    description: 'Base semi-agachada firme, gere ondas contínuas e enérgicas com os braços respirando no ritmo.',
    equipment: 'Corda Naval'
  },
  {
    id: 'vid-slam-ball',
    name: 'Medicine Ball Slam / Slam Ball',
    aliases: ['slam ball', 'medicine ball slam', 'slam de bola', 'arremesso no solo', 'medbol', 'medicine ball'],
    muscleGroup: 'Abdômen',
    category: 'funcional',
    videoUrl: DRIVE_MEDICINE_BALL_VIDEOS[0] || 'https://drive.google.com/file/d/1FFts0LDLOMwU5P0Jsr3sbSQTrR9OJ40R/view?usp=drive_link',
    provider: 'drive',
    description: 'Erga a bola acima da cabeça e arremesse-a com máxima potência no solo, agachando para amortecer e recolher.',
    equipment: 'Slam Ball / Medicine Ball'
  },
  {
    id: 'vid-step-up-caixote',
    name: 'Step-Up no Caixote / Banco',
    aliases: ['step up', 'step-up', 'subida no banco', 'subida no caixote', 'caixote'],
    muscleGroup: 'Quadríceps',
    category: 'funcional',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[8] || 'https://drive.google.com/file/d/1cqwrvcXvHIP-PjMkk4DdCLkVjSaqnjAh/view?usp=drive_link',
    provider: 'drive',
    description: 'Pise firme com todo o pé no centro do caixote, suba impulsionando pela perna de cima sem dar impulso com a de trás.',
    equipment: 'Caixote de Pliometria / Banco'
  },
  {
    id: 'vid-burpee',
    name: 'Burpee Completo',
    aliases: ['burpee', 'burpees', 'burpee funcional'],
    muscleGroup: 'Quadríceps',
    category: 'funcional',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[9] || 'https://drive.google.com/file/d/1NrJ9NS2y3J19sXotG6Ar9laGAzE9dCV6/view?usp=drive_link',
    provider: 'drive',
    description: 'Agache, jogue os pés para trás em prancha, toque o peito no chão, volte os pés e finalize com um salto vertical.',
    equipment: 'Peso Corporal'
  },
  {
    id: 'vid-jump-squat',
    name: 'Agachamento com Salto (Jump Squat)',
    aliases: ['jump squat', 'agachamento com salto', 'salto vertical agachado'],
    muscleGroup: 'Quadríceps',
    category: 'funcional',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[10] || 'https://drive.google.com/file/d/1E9yxWVPtmQa1lMinTLd5nNzmjswIW-u3/view?usp=drive_link',
    provider: 'drive',
    description: 'Agache a 90° e salte com explosão vertical, aterrissando de forma suave na ponta dos pés flexionando os joelhos.',
    equipment: 'Peso Corporal'
  },

  // ==========================================
  // 6. AQUECIMENTO GERAL & MOBILIDADE ARTICULAR & LIBERAÇÃO MIOFASCIAL
  // ==========================================
  {
    id: 'vid-polichinelo',
    name: 'Polichinelo Dinâmico',
    aliases: ['polichinelo', 'jumping jack', 'jumping jacks', 'polichinelos'],
    muscleGroup: 'Mobilidade',
    category: 'aquecimento',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[11] || 'https://drive.google.com/file/d/1eQAZZRqBtk4sJ97Y_hGaB_BHmeK2NAl3/view?usp=drive_link',
    provider: 'drive',
    description: 'Salte abrindo pernas e batendo palmas acima da cabeça com aterrissagem suave e ritmo constante.',
    equipment: 'Peso Corporal'
  },
  {
    id: 'vid-skipping-alto',
    name: 'Corrida Estacionária / Skipping Alto',
    aliases: ['skipping', 'skipping alto', 'corrida estacionaria', 'high knees', 'joelhos altos'],
    muscleGroup: 'Mobilidade',
    category: 'aquecimento',
    videoUrl: DRIVE_BODYWEIGHT_CORE_VIDEOS[12] || 'https://drive.google.com/file/d/16ouZB1No_FkSDkGn3BvYtIn6mzC51KJT/view?usp=drive_link',
    provider: 'drive',
    description: 'Eleve os joelhos alternadamente até a altura do quadril mantendo o tronco ereto e braços em pêndulo.',
    equipment: 'Peso Corporal'
  },
  {
    id: 'vid-liberacao-rolo',
    name: 'Liberação Miofascial com Rolo de Espuma (Foam Roller)',
    aliases: ['liberacao miofascial', 'foam roller', 'rolo de espuma', 'liberacao rolo', 'miofascial'],
    muscleGroup: 'Mobilidade',
    category: 'mobilidade',
    videoUrl: DRIVE_MYOFASCIAL_VIDEOS[0] || 'https://drive.google.com/file/d/1la01s8V9Ykh_zj7TdKldCu59-Mi_Neir/view?usp=drive_link',
    provider: 'drive',
    description: 'Deslize o rolo suavemente sobre os pontos de tensão muscular, respirando fundo e mantendo 30-45s por ponto.',
    equipment: 'Rolo de Liberação Miofascial'
  },
  {
    id: 'vid-mobilidade-quadril-9090',
    name: 'Mobilidade de Quadril 90/90 no Solo',
    aliases: ['90/90', 'quadril 90 90', 'mobilidade 90/90', 'mobilidade de quadril', 'rotacao de quadril'],
    muscleGroup: 'Mobilidade',
    category: 'mobilidade',
    videoUrl: DRIVE_MOBILITY_LPO_MINIBAND_VIDEOS[0] || 'https://drive.google.com/file/d/18icOgZojDqqIi6su44nqQ8_cAr1DZ2lY/view?usp=drive_link',
    provider: 'drive',
    description: 'Sentado no chão, posicione as duas pernas a 90° e gire suavemente o quadril de um lado para o outro mantendo o peito alto.',
    equipment: 'Colchonete'
  },
  {
    id: 'vid-gato-vaca',
    name: 'Gato e Vaca (Cat-Cow) para Coluna',
    aliases: ['gato e vaca', 'cat cow', 'cat-cow', 'mobilidade de coluna', 'coluna gato'],
    muscleGroup: 'Mobilidade',
    category: 'mobilidade',
    videoUrl: DRIVE_MOBILITY_LPO_MINIBAND_VIDEOS[1] || 'https://drive.google.com/file/d/1YVotLRwDSKMt30xxX6sinfgYba_c07f8/view?usp=drive_link',
    provider: 'drive',
    description: 'Em 4 apoios, alterne entre arquear a coluna para cima soltando o ar e estender a coluna olhando à frente inspirando.',
    equipment: 'Colchonete'
  },
  {
    id: 'vid-mobilidade-toracica',
    name: 'Mobilidade Torácica com Rotação em 4 Apoios',
    aliases: ['mobilidade toracica', 'rotacao toracica', 'toracica', 'rotacao de tronco em 4 apoios'],
    muscleGroup: 'Mobilidade',
    category: 'mobilidade',
    videoUrl: DRIVE_MOBILITY_LPO_MINIBAND_VIDEOS[4] || 'https://drive.google.com/file/d/1f6xOoAQsbf7fztqHR3cn7vD_I82NxyLL/view?usp=drive_link',
    provider: 'drive',
    description: 'Mão atrás da cabeça em 4 apoios, aponte o cotovelo para o teto abrindo o peito e retorne suavemente.',
    equipment: 'Colchonete'
  },
  {
    id: 'vid-mobilidade-tornozelo',
    name: 'Mobilidade de Tornozelo na Parede (Dorsiflexão)',
    aliases: ['tornozelo', 'mobilidade de tornozelo', 'dorsiflexao', 'tornozelo na parede'],
    muscleGroup: 'Mobilidade',
    category: 'mobilidade',
    videoUrl: DRIVE_MOBILITY_LPO_MINIBAND_VIDEOS[5] || 'https://drive.google.com/file/d/1jbrRk_UYkkeDSe3DB0msHjA7uivYyzZv/view?usp=drive_link',
    provider: 'drive',
    description: 'Com o pé próximo à parede, projete o joelho à frente sem desencostar o calcanhar do solo.',
    equipment: 'Parede'
  }
];

const STORAGE_KEY_CUSTOM_VIDEOS = 'fitpro_custom_video_library_v1';

/**
 * Normalizes text removing accents, punctuation and lowering case for fuzzy matching
 */
export function normalizeExerciseString(str: string): string {
  if (!str) return '';
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Loads custom user mappings from localStorage
 */
export function getCustomVideoMappings(): Record<string, { videoUrl: string; videoName: string }> {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_CUSTOM_VIDEOS);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error(e);
  }
  return {};
}

/**
 * Saves a custom video mapping to localStorage
 */
export function saveCustomVideoMapping(exerciseName: string, videoUrl: string, videoName: string) {
  try {
    const current = getCustomVideoMappings();
    const key = normalizeExerciseString(exerciseName);
    current[key] = { videoUrl, videoName };
    localStorage.setItem(STORAGE_KEY_CUSTOM_VIDEOS, JSON.stringify(current));
  } catch (e) {
    console.error(e);
  }
}

/**
 * Finds the best matching video for an exercise name from the Google Drive repository
 */
export function findBestVideoMatch(
  exerciseName: string
): { videoUrl: string; videoName: string; entry?: ExerciseVideoEntry; confidence: number } | null {
  if (!exerciseName || !exerciseName.trim()) return null;

  const normalizedInput = normalizeExerciseString(exerciseName);
  const inputTokens = normalizedInput.split(' ').filter((t) => t.length > 1);

  // 1. Check custom coach-mapped videos first (highest priority)
  const customMappings = getCustomVideoMappings();
  if (customMappings[normalizedInput]) {
    return {
      videoUrl: customMappings[normalizedInput].videoUrl,
      videoName: customMappings[normalizedInput].videoName,
      confidence: 1.0,
    };
  }

  // 2. Check exact name match in VIDEO_LIBRARY
  for (const entry of VIDEO_LIBRARY) {
    const normEntryName = normalizeExerciseString(entry.name);
    if (normEntryName === normalizedInput) {
      return {
        videoUrl: entry.videoUrl,
        videoName: entry.name,
        entry,
        confidence: 1.0,
      };
    }
  }

  // 3. Check alias exact matches or inclusions
  for (const entry of VIDEO_LIBRARY) {
    for (const alias of entry.aliases) {
      const normAlias = normalizeExerciseString(alias);
      if (normAlias === normalizedInput || normalizedInput.includes(normAlias) || normAlias.includes(normalizedInput)) {
        return {
          videoUrl: entry.videoUrl,
          videoName: entry.name,
          entry,
          confidence: 0.9,
        };
      }
    }
  }

  // 4. Token overlap scoring
  let bestEntry: ExerciseVideoEntry | null = null;
  let bestScore = 0;

  for (const entry of VIDEO_LIBRARY) {
    const allSearchable = [
      entry.name,
      ...entry.aliases,
      entry.muscleGroup,
      entry.equipment || ''
    ]
      .map(normalizeExerciseString)
      .join(' ');

    let score = 0;
    for (const token of inputTokens) {
      if (allSearchable.includes(token)) {
        score += token.length >= 4 ? 2 : 1;
      }
    }

    if (score > bestScore) {
      bestScore = score;
      bestEntry = entry;
    }
  }

  if (bestEntry && bestScore >= 2) {
    return {
      videoUrl: bestEntry.videoUrl,
      videoName: bestEntry.name,
      entry: bestEntry,
      confidence: Math.min(0.85, bestScore / (inputTokens.length * 2)),
    };
  }

  return null;
}
