export type Gender = 'feminino' | 'masculino' | 'outro';
export type FitnessLevel = 'Iniciante' | 'Intermediário' | 'Avançado' | 'Atleta';
export type PrimaryGoal =
  | 'Hipertrofia de Membros Inferiores'
  | 'Hipertrofia Geral'
  | 'Emagrecimento & Queima de Gordura'
  | 'Força Bruta e Potência'
  | 'Mobilidade Articular e Flexibilidade'
  | 'Condicionamento Físico & Resistência'
  | 'Reabilitação e Prevenção de Lesões';

export type WorkoutModality = 'fullbody' | 'inferiores' | 'superiores' | 'musculacao' | 'mobilidade' | 'casa';
export type SplitType = 'Fullbody' | 'A/B' | 'A/B/C' | 'A/B/C/D' | 'A/B/C/D/E' | 'Push/Pull/Legs' | 'Superior/Inferior';
export type AdvancedTechnique = 'Tradicional' | 'Pirâmide' | 'Drop-set' | 'Bi-set' | 'Rest-pause' | 'Série Gigante' | 'Excêntrica Lenta';
export type GenerationScope = 'both' | 'workout_only' | 'diet_only';
export type HomeEquipmentType = 'bodyweight_only' | 'elastic_bands' | 'dumbbells_free_weights' | 'mixed_home';

export interface CoachProfile {
  name: string;
  fullName?: string;
  cref: string;
  phone: string;
  email?: string;
  instagram?: string;
  brandOrGym: string;
  customHeaderTitle: string;
  consultancyNotes?: string;
  bio?: string;
  pixKey?: string;
  pixKeyType?: 'cpf' | 'cnpj' | 'email' | 'phone' | 'random';
  avatarUrl?: string;
}

export interface Exercise {
  id: string;
  name: string;
  muscleGroup: string;
  sets: number;
  reps: string;
  suggestedLoadKg: number;
  userCurrentLoadKg?: number;
  restSeconds: number;
  technique?: AdvancedTechnique | string;
  notes?: string;
  videoUrl?: string;
  videoName?: string;
  isCompleted?: boolean;
  executedSets?: {
    setNumber: number;
    repsCompleted: number;
    weightKg: number;
    completed: boolean;
  }[];
}

export interface WorkoutDay {
  id: string;
  code: string; // "A", "B", "C", "Fullbody", "Inferiores", "Mobilidade"
  name: string;
  focus: string;
  suggestedRestSeconds: number;
  exercises: Exercise[];
}

export interface Meal {
  id: string;
  name: string;
  time: string;
  foods: string[];
  calories: number;
  proteinGrams: number;
  carbsGrams: number;
  fatGrams: number;
  notes?: string;
}

export interface NutritionPlan {
  dailyCalories: number;
  tmb: number;
  get: number;
  macros: {
    proteinGrams: number;
    carbsGrams: number;
    fatGrams: number;
    proteinPercentage: number;
    carbsPercentage: number;
    fatPercentage: number;
  };
  waterIntakeMl: number;
  strategy: string;
  meals: Meal[];
  supplementSuggestions: string[];
}

export interface EvolutionRecord {
  id?: string;
  date: string;
  weightKg?: number;
  bodyFatPercent?: number;
  squatMaxKg?: number;
  benchPressMaxKg?: number;
  deadliftMaxKg?: number;
  legPressMaxKg?: number;
  waistCm?: number;
  hipCm?: number;
  thighCm?: number;
  armCm?: number;
  exerciseLoads?: Record<string, number>;
  notes?: string;
}

export type SubscriptionStatus = 'active' | 'pending_payment' | 'canceled';

export interface Student {
  id: string;
  name: string;
  gender: Gender;
  age: number;
  weightKg: number;
  heightCm: number;
  level: FitnessLevel;
  goal: PrimaryGoal;
  frequencyDaysPerWeek: number;
  limitations?: string;
  phone?: string;
  notes?: string;
  createdAt: string;
  evolutionHistory: EvolutionRecord[];
  savedPlans?: WorkoutPlan[];
  subscriptionStatus?: SubscriptionStatus;
  monthlyFee?: number;
  dueDay?: number;
  cancellationReason?: string;
  lastPaymentDate?: string;
  lastUpdatedByCoach?: string;
}

export interface WorkoutPlan {
  id: string;
  studentId: string;
  studentName: string;
  title: string;
  objectiveSummary: string;
  modality: WorkoutModality;
  splitType: SplitType;
  advancedTechniques: AdvancedTechnique[];
  generationScope: GenerationScope;
  totalEstimatedTimeMinutes: number;
  coachCustomNotes?: string;
  homeEquipment?: HomeEquipmentType;
  coachProfile?: CoachProfile;
  workouts: WorkoutDay[];
  nutritionPlan?: NutritionPlan;
  createdAt: string;
}

export interface CircuitExerciseItem {
  id: string;
  stationNumber: number;
  name: string;
  targetFocus: string;
  equipment: string;
  durationOrReps: string;
  description?: string;
  beginnerAlternative?: string;
  advancedAlternative?: string;
  videoUrl?: string;
  videoName?: string;
}

export interface FunctionalCircuit {
  id: string;
  title: string;
  groupCategory: string; // e.g. "Turma Geral", "Turma das 07h", "Mulheres em Forma", "Avançado", "Iniciantes"
  objective: string;
  intensity: 'Iniciante' | 'Intermediário' | 'Avançado' | 'Alta Intensidade / HIIT';
  rounds: number; // e.g. 3 or 4 voltas
  workTimeSeconds: number; // e.g. 40s per station
  transitionTimeSeconds: number; // e.g. 15s to rotate to next station
  roundRestSeconds: number; // e.g. 60s between rounds
  estimatedTotalMinutes: number;
  coachInstructions?: string;
  warmupExercises: CircuitExerciseItem[]; // Aquecimento (3-5 exercícios)
  mobilityExercises: CircuitExerciseItem[]; // Mobilidade Articular (3-5 exercícios)
  mainExercises: CircuitExerciseItem[]; // Treino Principal (default 8 estações, expansível)
  createdAt: string;
  updatedAt?: string;
}
