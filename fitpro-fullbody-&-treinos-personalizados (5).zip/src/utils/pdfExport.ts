import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { WorkoutPlan, Student } from '../types';

export async function exportPlanToPdf(elementId: string, filename: string = 'treino-personalizado.pdf'): Promise<boolean> {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error(`Element with id ${elementId} not found`);
    return false;
  }

  try {
    // Clone or capture target element with high DPI
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
      windowWidth: 1200,
    });

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();

    const imgWidth = pdfWidth;
    const imgHeight = (canvas.height * pdfWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 0;

    // Add first page
    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
    heightLeft -= pdfHeight;

    // Handle multiple pages if content is long
    while (heightLeft > 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
      heightLeft -= pdfHeight;
    }

    pdf.save(filename);
    return true;
  } catch (err) {
    console.error('Error creating PDF:', err);
    // Fallback: trigger standard browser print
    window.print();
    return false;
  }
}

export function generateWhatsAppWorkoutText(plan: WorkoutPlan, student: Student): string {
  const lines: string[] = [];
  const baseUrl = typeof window !== 'undefined' ? (window.location.origin + window.location.pathname) : '';
  const studentUrl = baseUrl ? `${baseUrl}?view=student&studentId=${student.id}` : '';

  lines.push(`🏋️‍♂️ *FITPRO - PRESCRIÇÃO INDIVIDUALIZADA*`);
  lines.push(`👤 *Aluno(a):* ${student.name}`);
  lines.push(`📊 *Perfil:* ${student.gender === 'feminino' ? 'Feminino' : 'Masculino'} • ${student.age} anos • ${student.weightKg}kg • ${student.heightCm}cm`);
  lines.push(`🎯 *Objetivo:* ${student.goal}`);
  lines.push(`⚡ *Nível:* ${student.level} | *Modalidade:* ${plan.modality.toUpperCase()} (${plan.splitType})`);
  lines.push(`📅 *Gerado em:* ${new Date(plan.createdAt).toLocaleDateString('pt-BR')}`);
  
  if (studentUrl) {
    lines.push(``);
    lines.push(`📱 *SEU APP DE TREINOS COM VÍDEOS & CRONÔMETRO:*`);
    lines.push(`👉 ${studentUrl}`);
    lines.push(`_(Toque no link acima para abrir sua ficha completa com demonstração em vídeo/GIF e registrar suas cargas!)_`);
  }
  lines.push(``);

  if (plan.coachCustomNotes) {
    lines.push(`📝 *ORIENTAÇÕES DO PROFESSOR:*`);
    lines.push(`_${plan.coachCustomNotes}_`);
    lines.push(``);
  }

  // Workouts
  if (plan.generationScope !== 'diet_only' && plan.workouts.length > 0) {
    lines.push(`==============================`);
    lines.push(`📋 *PROGRAMA DE TREINOS*`);
    lines.push(`==============================`);

    plan.workouts.forEach((day, dIdx) => {
      lines.push(``);
      lines.push(`🔸 *${day.name.toUpperCase()}*`);
      lines.push(`🎯 _Foco: ${day.focus}_`);
      lines.push(`⏱ _Descanso sugerido entre séries: ${day.suggestedRestSeconds}s_`);
      lines.push(``);

      day.exercises.forEach((ex, eIdx) => {
        const loadStr = ex.userCurrentLoadKg ? ` | Carga: *${ex.userCurrentLoadKg}kg*` : (ex.suggestedLoadKg ? ` | Carga Sugerida: ${ex.suggestedLoadKg}kg` : '');
        lines.push(`${eIdx + 1}. *${ex.name}*`);
        lines.push(`   └ Séries: *${ex.sets}x* | Reps: *${ex.reps}* | Descanso: *${ex.restSeconds}s*${loadStr}`);
        if (ex.technique && ex.technique !== 'Tradicional') {
          lines.push(`   └ ⚡ _Técnica: ${ex.technique}_`);
        }
        if (ex.notes) {
          lines.push(`   └ 💡 _Dica: ${ex.notes}_`);
        }
      });
    });
  }

  // Nutrition
  if (plan.generationScope !== 'workout_only' && plan.nutritionPlan) {
    const np = plan.nutritionPlan;
    lines.push(``);
    lines.push(`==============================`);
    lines.push(`🥗 *PLANO NUTRICIONAL & DIETA*`);
    lines.push(`==============================`);
    lines.push(`🔥 *Meta Diária:* ${np.dailyCalories} kcal (TMB: ${np.tmb} kcal)`);
    lines.push(`🥩 *Proteínas:* ${np.macros.proteinGrams}g (${np.macros.proteinPercentage}%)`);
    lines.push(`🍚 *Carboidratos:* ${np.macros.carbsGrams}g (${np.macros.carbsPercentage}%)`);
    lines.push(`🥑 *Gorduras:* ${np.macros.fatGrams}g (${np.macros.fatPercentage}%)`);
    lines.push(`💧 *Água Recomendada:* ${(np.waterIntakeMl / 1000).toFixed(1)}L por dia`);
    lines.push(`💡 _Estratégia: ${np.strategy}_`);
    lines.push(``);

    np.meals.forEach((meal, mIdx) => {
      lines.push(`🍽️ *${meal.name}* (${meal.time}) - ~${meal.calories} kcal [${meal.proteinGrams}g Prot]`);
      meal.foods.forEach((f) => lines.push(`   • ${f}`));
      if (meal.notes) lines.push(`   _Obs: ${meal.notes}_`);
      lines.push(``);
    });

    if (np.supplementSuggestions?.length > 0) {
      lines.push(`💊 *SUPLEMENTAÇÃO RECOMENDADA:*`);
      np.supplementSuggestions.forEach((s) => lines.push(`   • ${s}`));
      lines.push(``);
    }
  }

  lines.push(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
  lines.push(`🚀 *Bons treinos e constância nos resultados!*`);
  lines.push(`📲 _Prescrito via FitPro Trainer System_`);

  return lines.join('\n');
}

export function openWhatsAppWithText(phone: string | undefined, message: string) {
  const cleanPhone = (phone || '').replace(/\D/g, '');
  const encodedText = encodeURIComponent(message);
  const url = cleanPhone
    ? `https://api.whatsapp.com/send?phone=55${cleanPhone}&text=${encodedText}`
    : `https://api.whatsapp.com/send?text=${encodedText}`;
  window.open(url, '_blank');
}

export function generateWhatsAppCircuitText(circuit: import('../types').FunctionalCircuit): string {
  const lines: string[] = [];

  lines.push(`🔥 *CIRCUITO FUNCIONAL EM GRUPO - FITPRO*`);
  lines.push(`🏷️ *${circuit.title.toUpperCase()}*`);
  lines.push(`👥 *Categoria:* ${circuit.groupCategory} | ⚡ *Nível:* ${circuit.intensity}`);
  lines.push(`🎯 *Objetivo:* ${circuit.objective}`);
  lines.push(`⏱️ *Estrutura:* ${circuit.rounds} Voltas • ${circuit.workTimeSeconds}s Ação / ${circuit.transitionTimeSeconds}s Troca • ${circuit.roundRestSeconds}s Intervalo`);
  lines.push(`⏳ *Duração Estimada:* ~${circuit.estimatedTotalMinutes} minutos`);
  lines.push(``);

  if (circuit.coachInstructions) {
    lines.push(`📢 *ORIENTAÇÕES DA TURMA:*`);
    lines.push(`_${circuit.coachInstructions}_`);
    lines.push(``);
  }

  if (circuit.warmupExercises.length > 0) {
    lines.push(`🔥 *1. AQUECIMENTO GERAL:*`);
    circuit.warmupExercises.forEach((w, i) => {
      lines.push(`${i + 1}. *${w.name}* (${w.durationOrReps})`);
      if (w.description) lines.push(`   └ _${w.description}_`);
    });
    lines.push(``);
  }

  if (circuit.mobilityExercises.length > 0) {
    lines.push(`🧘 *2. MOBILIDADE ARTICULAR:*`);
    circuit.mobilityExercises.forEach((m, i) => {
      lines.push(`${i + 1}. *${m.name}* (${m.durationOrReps})`);
      if (m.targetFocus) lines.push(`   └ Foco: ${m.targetFocus}`);
    });
    lines.push(``);
  }

  lines.push(`⚡ *3. TREINO PRINCIPAL (${circuit.mainExercises.length} ESTAÇÕES):*`);
  circuit.mainExercises.forEach((ex, idx) => {
    lines.push(`[Estação ${idx + 1}] *${ex.name}*`);
    lines.push(`   └ 🎯 Foco: ${ex.targetFocus} | 🛠️ Equipamento: ${ex.equipment}`);
    if (ex.description) lines.push(`   └ 💡 Dica: ${ex.description}`);
    if (ex.beginnerAlternative) lines.push(`   └ 🟢 Adaptação Iniciante: ${ex.beginnerAlternative}`);
    if (ex.advancedAlternative) lines.push(`   └ 🔴 Opção Avançada: ${ex.advancedAlternative}`);
  });

  lines.push(``);
  lines.push(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
  lines.push(`🚀 *Vamos com energia máxima turma! Bora treinar!*`);
  lines.push(`📲 _Prescrito via FitPro Functional System_`);

  return lines.join('\n');
}
