export const GOOGLE_DRIVE_FOLDER_ID = '190lNCkJL2RolWzbxCIexihKx1yoQoru8';

export const GOOGLE_DRIVE_VIDEOS_URL =
  'https://drive.google.com/drive/folders/190lNCkJL2RolWzbxCIexihKx1yoQoru8?usp=sharing';

export const GOOGLE_DRIVE_EMBED_FOLDER_URL =
  `https://drive.google.com/embeddedfolderview?id=${GOOGLE_DRIVE_FOLDER_ID}#grid`;

export interface DriveFolderItem {
  id: string;
  folderId: string;
  name: string;
  url: string;
  embedUrl: string;
  category?: string;
}

export const GOOGLE_DRIVE_FOLDERS: DriveFolderItem[] = [
  {
    id: 'folder-main-drive',
    folderId: '190lNCkJL2RolWzbxCIexihKx1yoQoru8',
    name: 'Pasta Principal de Exercícios & GIFs (Drive Oficial)',
    url: 'https://drive.google.com/drive/folders/190lNCkJL2RolWzbxCIexihKx1yoQoru8?usp=sharing',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=190lNCkJL2RolWzbxCIexihKx1yoQoru8#grid',
    category: 'Geral / Todos os Exercícios',
  },
  {
    id: 'folder-2',
    folderId: '18TJ3pBxXjrzrJH_U9n0LWhGR9g9r-K95',
    name: 'Pasta de Exercícios 02',
    url: 'https://drive.google.com/drive/folders/18TJ3pBxXjrzrJH_U9n0LWhGR9g9r-K95?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=18TJ3pBxXjrzrJH_U9n0LWhGR9g9r-K95#grid',
    category: 'Musculação / Funcional',
  },
  {
    id: 'folder-3',
    folderId: '188TEjwSbdfwp3qFByhftO-X7M7Q8H7Tl',
    name: 'Pasta de Exercícios 03',
    url: 'https://drive.google.com/drive/folders/188TEjwSbdfwp3qFByhftO-X7M7Q8H7Tl?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=188TEjwSbdfwp3qFByhftO-X7M7Q8H7Tl#grid',
    category: 'Musculação / Funcional',
  },
  {
    id: 'folder-4',
    folderId: '1myvdGJzNFCPj75SksOFT4jtckiIQ_YxP',
    name: 'Pasta de Exercícios 04',
    url: 'https://drive.google.com/drive/folders/1myvdGJzNFCPj75SksOFT4jtckiIQ_YxP?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1myvdGJzNFCPj75SksOFT4jtckiIQ_YxP#grid',
    category: 'Membros Inferiores',
  },
  {
    id: 'folder-5',
    folderId: '1yPedHH-jT4-KalBmf-Q55AeZtx0E-oCX',
    name: 'Pasta de Exercícios 05',
    url: 'https://drive.google.com/drive/folders/1yPedHH-jT4-KalBmf-Q55AeZtx0E-oCX?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1yPedHH-jT4-KalBmf-Q55AeZtx0E-oCX#grid',
    category: 'Membros Superiores',
  },
  {
    id: 'folder-6',
    folderId: '151yozTzG4V6ia4_jRCn42Na0aL1oWDh5',
    name: 'Pasta de Exercícios 06',
    url: 'https://drive.google.com/drive/folders/151yozTzG4V6ia4_jRCn42Na0aL1oWDh5?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=151yozTzG4V6ia4_jRCn42Na0aL1oWDh5#grid',
    category: 'Costas & Peito',
  },
  {
    id: 'folder-7',
    folderId: '1sbBxuh2_86PZnGIGhh1VQZJj2CWPzTC1',
    name: 'Pasta de Exercícios 07',
    url: 'https://drive.google.com/drive/folders/1sbBxuh2_86PZnGIGhh1VQZJj2CWPzTC1?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1sbBxuh2_86PZnGIGhh1VQZJj2CWPzTC1#grid',
    category: 'Pernas & Glúteos',
  },
  {
    id: 'folder-8',
    folderId: '16KqWNPwrfk7KwuDGgwMVVG-4Gk7NrKZy',
    name: 'Pasta de Exercícios 08',
    url: 'https://drive.google.com/drive/folders/16KqWNPwrfk7KwuDGgwMVVG-4Gk7NrKZy?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=16KqWNPwrfk7KwuDGgwMVVG-4Gk7NrKZy#grid',
    category: 'Core & Abdômen',
  },
  {
    id: 'folder-9',
    folderId: '1Z1Qxj5jelrhVjoGRC4INYsR88rmuX61-',
    name: 'Pasta de Exercícios 09',
    url: 'https://drive.google.com/drive/folders/1Z1Qxj5jelrhVjoGRC4INYsR88rmuX61-?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1Z1Qxj5jelrhVjoGRC4INYsR88rmuX61-#grid',
    category: 'Ombros & Braços',
  },
  {
    id: 'folder-10',
    folderId: '1gHS1D6KiW_3uhhsKoJ1cSd9gizyJoqY3',
    name: 'Pasta de Exercícios 10',
    url: 'https://drive.google.com/drive/folders/1gHS1D6KiW_3uhhsKoJ1cSd9gizyJoqY3?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1gHS1D6KiW_3uhhsKoJ1cSd9gizyJoqY3#grid',
    category: 'Circuito & Cárdio',
  },
  {
    id: 'folder-11',
    folderId: '1aqEFDo-p3oLygF2UAgg1GCW9W_0X0CqD',
    name: 'Pasta de Exercícios 11',
    url: 'https://drive.google.com/drive/folders/1aqEFDo-p3oLygF2UAgg1GCW9W_0X0CqD?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1aqEFDo-p3oLygF2UAgg1GCW9W_0X0CqD#grid',
    category: 'Mobilidade & Aquecimento',
  },
  {
    id: 'folder-12',
    folderId: '1xNsxbHsUvMuCzZQiiMevMbIlodSTw4MW',
    name: 'Pasta de Exercícios 12',
    url: 'https://drive.google.com/drive/folders/1xNsxbHsUvMuCzZQiiMevMbIlodSTw4MW?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1xNsxbHsUvMuCzZQiiMevMbIlodSTw4MW#grid',
    category: 'Treino Funcional',
  },
  {
    id: 'folder-13',
    folderId: '1_3bwuS0d-vjkqcxe1lE5FzqzoLi8P0sU',
    name: 'Pasta de Exercícios 13',
    url: 'https://drive.google.com/drive/folders/1_3bwuS0d-vjkqcxe1lE5FzqzoLi8P0sU?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1_3bwuS0d-vjkqcxe1lE5FzqzoLi8P0sU#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-14',
    folderId: '1sWq1FmRaC_Ve-vOSJUA_U_3VaTQvzv3x',
    name: 'Pasta de Exercícios 14',
    url: 'https://drive.google.com/drive/folders/1sWq1FmRaC_Ve-vOSJUA_U_3VaTQvzv3x?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1sWq1FmRaC_Ve-vOSJUA_U_3VaTQvzv3x#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-15',
    folderId: '19a2Po_it9nqTzLY_gG8vxn5W4RPQgZnz',
    name: 'Pasta de Exercícios 15',
    url: 'https://drive.google.com/drive/folders/19a2Po_it9nqTzLY_gG8vxn5W4RPQgZnz?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=19a2Po_it9nqTzLY_gG8vxn5W4RPQgZnz#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-16',
    folderId: '1gu9GsClO2bs_4kCWivzJUPEk2gIem-jO',
    name: 'Pasta de Exercícios 16',
    url: 'https://drive.google.com/drive/folders/1gu9GsClO2bs_4kCWivzJUPEk2gIem-jO?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1gu9GsClO2bs_4kCWivzJUPEk2gIem-jO#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-17',
    folderId: '1hQ_us4Xy3OAItmDCTGyzOD_S0eWm1Ek-',
    name: 'Pasta de Exercícios 17',
    url: 'https://drive.google.com/drive/folders/1hQ_us4Xy3OAItmDCTGyzOD_S0eWm1Ek-?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1hQ_us4Xy3OAItmDCTGyzOD_S0eWm1Ek-#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-18',
    folderId: '12r43kjvidYlwGZ6I3jv719lkOjDYXwRx',
    name: 'Pasta de Exercícios 18',
    url: 'https://drive.google.com/drive/folders/12r43kjvidYlwGZ6I3jv719lkOjDYXwRx?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=12r43kjvidYlwGZ6I3jv719lkOjDYXwRx#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-19',
    folderId: '1HGg_GXgtIw7r0r8MQaId-kDSEgOYDolh',
    name: 'Pasta de Exercícios 19',
    url: 'https://drive.google.com/drive/folders/1HGg_GXgtIw7r0r8MQaId-kDSEgOYDolh?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1HGg_GXgtIw7r0r8MQaId-kDSEgOYDolh#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-20',
    folderId: '18YVmsJ7B8PPGSJ9brG60ePoxYwhVzoOG',
    name: 'Pasta de Exercícios 20',
    url: 'https://drive.google.com/drive/folders/18YVmsJ7B8PPGSJ9brG60ePoxYwhVzoOG?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=18YVmsJ7B8PPGSJ9brG60ePoxYwhVzoOG#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-21',
    folderId: '1X_klp-plcdaOzNPa9b6HjBs8RqgX2_CM',
    name: 'Pasta de Exercícios 21',
    url: 'https://drive.google.com/drive/folders/1X_klp-plcdaOzNPa9b6HjBs8RqgX2_CM?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1X_klp-plcdaOzNPa9b6HjBs8RqgX2_CM#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-22',
    folderId: '1qv-Vc-64YIHSJk7vbWRupA5L02tmrFm_',
    name: 'Pasta de Exercícios 22',
    url: 'https://drive.google.com/drive/folders/1qv-Vc-64YIHSJk7vbWRupA5L02tmrFm_?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1qv-Vc-64YIHSJk7vbWRupA5L02tmrFm_#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-23',
    folderId: '1qdp_RKJ-Epi4Z4o47tOT77rUMdMdL0VX',
    name: 'Pasta de Exercícios 23',
    url: 'https://drive.google.com/drive/folders/1qdp_RKJ-Epi4Z4o47tOT77rUMdMdL0VX?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1qdp_RKJ-Epi4Z4o47tOT77rUMdMdL0VX#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-24',
    folderId: '1lR6aJ_la-KtQd0eb_BksCVvrMHQm5n9r',
    name: 'Pasta de Exercícios 24',
    url: 'https://drive.google.com/drive/folders/1lR6aJ_la-KtQd0eb_BksCVvrMHQm5n9r?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1lR6aJ_la-KtQd0eb_BksCVvrMHQm5n9r#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-25',
    folderId: '1hIROROhJkFOFOqOYiwOX__4I4p7ezj9v',
    name: 'Pasta de Exercícios 25',
    url: 'https://drive.google.com/drive/folders/1hIROROhJkFOFOqOYiwOX__4I4p7ezj9v?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1hIROROhJkFOFOqOYiwOX__4I4p7ezj9v#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-26',
    folderId: '15xK7MvgXeARmtqzmLKMWYQmiTvdlV5CA',
    name: 'Pasta de Exercícios 26',
    url: 'https://drive.google.com/drive/folders/15xK7MvgXeARmtqzmLKMWYQmiTvdlV5CA?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=15xK7MvgXeARmtqzmLKMWYQmiTvdlV5CA#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-27',
    folderId: '1yrsbG1H74XxdQW2e9B6R43mHZj6C_ICh',
    name: 'Pasta de Exercícios 27',
    url: 'https://drive.google.com/drive/folders/1yrsbG1H74XxdQW2e9B6R43mHZj6C_ICh?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1yrsbG1H74XxdQW2e9B6R43mHZj6C_ICh#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-28',
    folderId: '1sV7l9yDhoPzTi1uMwQWrnKRqjS52LlrZ',
    name: 'Pasta de Exercícios 28',
    url: 'https://drive.google.com/drive/folders/1sV7l9yDhoPzTi1uMwQWrnKRqjS52LlrZ?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1sV7l9yDhoPzTi1uMwQWrnKRqjS52LlrZ#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-29',
    folderId: '12ExHpkBtUC21Ic8-jJ8SJ4whZ04iC6Um',
    name: 'Pasta de Exercícios 29',
    url: 'https://drive.google.com/drive/folders/12ExHpkBtUC21Ic8-jJ8SJ4whZ04iC6Um?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=12ExHpkBtUC21Ic8-jJ8SJ4whZ04iC6Um#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-30',
    folderId: '1vvr_HCwx3OXJx7bwE1CzlCFLH0HC9t2v',
    name: 'Pasta de Exercícios 30',
    url: 'https://drive.google.com/drive/folders/1vvr_HCwx3OXJx7bwE1CzlCFLH0HC9t2v?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1vvr_HCwx3OXJx7bwE1CzlCFLH0HC9t2v#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-31',
    folderId: '1aX3KGqJrPPGazpb8k4SpqVhy3u1df2V_',
    name: 'Pasta de Exercícios 31',
    url: 'https://drive.google.com/drive/folders/1aX3KGqJrPPGazpb8k4SpqVhy3u1df2V_?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1aX3KGqJrPPGazpb8k4SpqVhy3u1df2V_#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-32',
    folderId: '1SPstO0AS6fC5tkXoUPq86s0eBJtIyWCw',
    name: 'Pasta de Exercícios 32',
    url: 'https://drive.google.com/drive/folders/1SPstO0AS6fC5tkXoUPq86s0eBJtIyWCw?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1SPstO0AS6fC5tkXoUPq86s0eBJtIyWCw#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-33',
    folderId: '1ks3lSHSb8lne_UCs5j7BX4leOyQ-_XH_',
    name: 'Pasta de Exercícios 33',
    url: 'https://drive.google.com/drive/folders/1ks3lSHSb8lne_UCs5j7BX4leOyQ-_XH_?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1ks3lSHSb8lne_UCs5j7BX4leOyQ-_XH_#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-34',
    folderId: '1dYKLsXSMxDbNvVqOYTfcxZlMoVgrLrUL',
    name: 'Pasta de Exercícios 34',
    url: 'https://drive.google.com/drive/folders/1dYKLsXSMxDbNvVqOYTfcxZlMoVgrLrUL?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1dYKLsXSMxDbNvVqOYTfcxZlMoVgrLrUL#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-35',
    folderId: '1bsbpb7IYnmN8uqGuy4pzoc_FaetwSCNQ',
    name: 'Pasta de Exercícios 35',
    url: 'https://drive.google.com/drive/folders/1bsbpb7IYnmN8uqGuy4pzoc_FaetwSCNQ?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1bsbpb7IYnmN8uqGuy4pzoc_FaetwSCNQ#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-36',
    folderId: '1Hce5h6p0TbrStc_54HTgZftCPG5fi7lb',
    name: 'Pasta de Exercícios 36',
    url: 'https://drive.google.com/drive/folders/1Hce5h6p0TbrStc_54HTgZftCPG5fi7lb?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1Hce5h6p0TbrStc_54HTgZftCPG5fi7lb#grid',
    category: 'Exercícios Especiais',
  },
  {
    id: 'folder-37',
    folderId: '1lfhhXpEcjmK4lFb7jElrdcuNwbnPbHdp',
    name: 'Pasta de Exercícios 37',
    url: 'https://drive.google.com/drive/folders/1lfhhXpEcjmK4lFb7jElrdcuNwbnPbHdp?usp=drive_link',
    embedUrl: 'https://drive.google.com/embeddedfolderview?id=1lfhhXpEcjmK4lFb7jElrdcuNwbnPbHdp#grid',
    category: 'Exercícios Especiais',
  },
];

export interface VideoEmbedInfo {
  type: 'drive' | 'drive_folder' | 'direct' | 'external' | 'none';
  embedUrl: string | null;
  originalUrl: string;
  isPlayableDirectly: boolean;
  providerLabel: string;
  fileId?: string;
  folderId?: string;
}

export function extractDriveId(url: string): { type: 'file' | 'folder'; id: string } | null {
  if (!url || typeof url !== 'string') return null;
  const clean = url.trim();

  // 1. Check folder
  const folderMatch = clean.match(/\/folders\/([a-zA-Z0-9_-]+)/);
  if (folderMatch && folderMatch[1]) {
    return { type: 'folder', id: folderMatch[1] };
  }

  // 2. Check file
  const fileMatch =
    clean.match(/\/file(?:\/u\/\d+)?\/d\/([a-zA-Z0-9_-]+)/) ||
    clean.match(/[?&]id=([a-zA-Z0-9_-]+)/) ||
    clean.match(/\/open\?id=([a-zA-Z0-9_-]+)/) ||
    clean.match(/\/uc\?id=([a-zA-Z0-9_-]+)/);

  if (fileMatch && fileMatch[1]) {
    return { type: 'file', id: fileMatch[1] };
  }

  return null;
}

export function getVideoEmbedInfo(url?: string | null): VideoEmbedInfo {
  if (!url || typeof url !== 'string' || !url.trim()) {
    return {
      type: 'none',
      embedUrl: null,
      originalUrl: '',
      isPlayableDirectly: false,
      providerLabel: 'Nenhum vídeo',
    };
  }

  const cleanUrl = url.trim();

  // 1. Google Drive Links (Folders & Files)
  if (cleanUrl.includes('drive.google.com') || cleanUrl.includes('docs.google.com')) {
    const driveInfo = extractDriveId(cleanUrl);

    if (driveInfo) {
      if (driveInfo.type === 'folder') {
        return {
          type: 'drive_folder',
          embedUrl: `https://drive.google.com/embeddedfolderview?id=${driveInfo.id}#grid`,
          originalUrl: cleanUrl,
          isPlayableDirectly: true,
          providerLabel: 'Pasta do Google Drive',
          folderId: driveInfo.id,
        };
      }

      // File
      return {
        type: 'drive',
        embedUrl: `https://drive.google.com/file/d/${driveInfo.id}/preview`,
        originalUrl: cleanUrl,
        isPlayableDirectly: true,
        providerLabel: 'Vídeo do Google Drive',
        fileId: driveInfo.id,
      };
    }

    // Default fallback for generic drive url
    return {
      type: 'drive',
      embedUrl: cleanUrl.includes('/preview') ? cleanUrl : cleanUrl.replace(/\/view(\?.*)?$/, '/preview'),
      originalUrl: cleanUrl,
      isPlayableDirectly: true,
      providerLabel: 'Google Drive',
    };
  }

  // 2. If an old YouTube/Vimeo or non-drive link was passed, redirect safely to the default Google Drive collection
  if (cleanUrl.includes('youtube.com') || cleanUrl.includes('youtu.be') || cleanUrl.includes('vimeo.com')) {
    return {
      type: 'drive_folder',
      embedUrl: `https://drive.google.com/embeddedfolderview?id=${GOOGLE_DRIVE_FOLDER_ID}#grid`,
      originalUrl: GOOGLE_DRIVE_VIDEOS_URL,
      isPlayableDirectly: true,
      providerLabel: 'Google Drive',
      folderId: GOOGLE_DRIVE_FOLDER_ID,
    };
  }

  // 4. Direct video files, GIFs or blob/data URLs
  if (
    cleanUrl.startsWith('data:video/') ||
    cleanUrl.startsWith('data:image/') ||
    cleanUrl.startsWith('blob:') ||
    /\.(mp4|webm|ogg|mov|m4v|gif)(\?.*)?$/i.test(cleanUrl)
  ) {
    return {
      type: 'direct',
      embedUrl: cleanUrl,
      originalUrl: cleanUrl,
      isPlayableDirectly: true,
      providerLabel: cleanUrl.includes('.gif') ? 'GIF Demonstrativo' : 'Arquivo de Vídeo Direto',
    };
  }

  // 5. Generic / External URL
  return {
    type: 'external',
    embedUrl: cleanUrl,
    originalUrl: cleanUrl,
    isPlayableDirectly: false,
    providerLabel: 'Link Externo',
  };
}
