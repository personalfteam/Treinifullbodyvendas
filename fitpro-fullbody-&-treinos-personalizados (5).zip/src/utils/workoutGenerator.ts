import {
  Student,
  WorkoutPlan,
  WorkoutDay,
  Exercise,
  NutritionPlan,
  WorkoutModality,
  SplitType,
  AdvancedTechnique,
  GenerationScope,
  HomeEquipmentType,
  CoachProfile,
  Meal,
} from '../types';
import { EXERCISE_DATABASE, DatabaseExercise } from '../data/exerciseDatabase';
import { findBestVideoMatch } from '../data/videoLibrary';

export type GenerationEngine = 'auto' | 'ai_gemini' | 'algorithmic' | 'manual';

export interface GeneratorConfig {
  modality: WorkoutModality;
  splitType: SplitType;
  advancedTechniques: AdvancedTechnique[];
  generationScope: GenerationScope;
  homeEquipment?: HomeEquipmentType;
  customNotes?: string;
  coachProfile?: CoachProfile;
  focusMuscles?: string[];
  generationEngine?: GenerationEngine;
  avoidPreviousExercises?: boolean;
  excludedExerciseNames?: string[];
  customExercises?: Exercise[];
}

function calculateTMB(student: Student): { tmb: number; get: number } {
  const { gender, weightKg, heightCm, age, frequencyDaysPerWeek, goal } = student;
  // Mifflin-St Jeor Formula
  let tmb = 10 * weightKg + 6.25 * heightCm - 5 * age;
  if (gender === 'masculino') {
    tmb += 5;
  } else {
    tmb -= 161;
  }

  // Activity multiplier based on weekly frequency
  let activityFactor = 1.2;
  if (frequencyDaysPerWeek <= 2) activityFactor = 1.35;
  else if (frequencyDaysPerWeek <= 4) activityFactor = 1.55;
  else if (frequencyDaysPerWeek <= 6) activityFactor = 1.725;
  else activityFactor = 1.9;

  let get = Math.round(tmb * activityFactor);

  // Goal calorie adjustment
  if (goal.includes('Emagrecimento')) {
    get -= 400; // Caloric deficit
  } else if (goal.includes('Hipertrofia') || goal.includes('Força')) {
    get += 300; // Lean caloric surplus
  }

  return { tmb: Math.round(tmb), get: Math.max(1400, get) };
}

export function generateNutritionPlan(student: Student, dailyCalories: number, tmb: number): NutritionPlan {
  const { weightKg, goal, gender } = student;

  // Macros calculation based on sports nutrition guidelines
  let proteinPerKg = 2.0;
  if (goal.includes('Hipertrofia') || goal.includes('Força')) proteinPerKg = 2.2;
  else if (goal.includes('Emagrecimento')) proteinPerKg = 2.3; // Preserve lean mass
  else proteinPerKg = 1.8;

  const proteinGrams = Math.round(weightKg * proteinPerKg);
  const fatGrams = Math.round(weightKg * 0.9);
  const proteinCals = proteinGrams * 4;
  const fatCals = fatGrams * 9;
  const remainingCals = Math.max(400, dailyCalories - (proteinCals + fatCals));
  const carbsGrams = Math.round(remainingCals / 4);

  const totalCalcCals = proteinCals + fatCals + carbsGrams * 4;
  const proteinPercentage = Math.round((proteinCals / totalCalcCals) * 100);
  const carbsPercentage = Math.round(((carbsGrams * 4) / totalCalcCals) * 100);
  const fatPercentage = 100 - proteinPercentage - carbsPercentage;

  // Water intake: 35-45ml/kg
  const waterIntakeMl = Math.round(weightKg * 40);

  // Strategy description
  let strategy = '';
  if (goal.includes('Hipertrofia')) {
    strategy = `Superávit calórico controlado (${dailyCalories} kcal) para síntese proteica máxima e ganho de massa magra sem acúmulo excessivo de gordura.`;
  } else if (goal.includes('Emagrecimento')) {
    strategy = `Déficit calórico estratégico (${dailyCalories} kcal) com alta densidade proteica para preservar massa magra e acelerar oxidação lipídica.`;
  } else if (goal.includes('Mobilidade') || goal.includes('Condicionamento')) {
    strategy = `Plano normocalórico (${dailyCalories} kcal) equilibrado com foco em energia para desempenho, recuperação articular e vitalidade.`;
  } else {
    strategy = `Dieta personalizada (${dailyCalories} kcal) calculada rigorosamente para os parâmetros biológicos de ${student.name}.`;
  }

  // Generate 5 structured meals
  const meals: Meal[] = [
    {
      id: 'm-1',
      name: 'Café da Manhã Energético',
      time: '07:30',
      foods: [
        `${gender === 'masculino' ? '3 a 4' : '2 a 3'} ovos caipiras mexidos com orégano`,
        '2 fatias de pão 100% integral ou 100g de cuscuz nordestino com chia',
        '1 fruta média (banana ou 150g de mamão papaia)',
        'Café preto sem açúcar ou chá verde com canela'
      ],
      calories: Math.round(dailyCalories * 0.23),
      proteinGrams: Math.round(proteinGrams * 0.22),
      carbsGrams: Math.round(carbsGrams * 0.24),
      fatGrams: Math.round(fatGrams * 0.25),
      notes: 'Fornece aminoácidos para quebra de jejum e carboidratos de liberação gradual.'
    },
    {
      id: 'm-2',
      name: 'Colação / Lanche da Manhã',
      time: '10:30',
      foods: [
        '1 iogurte natural desnatado ou grego sem açúcar (150g)',
        '20g de castanhas do pará ou nozes',
        '1 maçã picada com canela em pó'
      ],
      calories: Math.round(dailyCalories * 0.14),
      proteinGrams: Math.round(proteinGrams * 0.12),
      carbsGrams: Math.round(carbsGrams * 0.15),
      fatGrams: Math.round(fatGrams * 0.2),
      notes: 'Gorduras boas para modulação hormonal e fibras para saciedade.'
    },
    {
      id: 'm-3',
      name: 'Almoço Anabólico Completo',
      time: '13:00',
      foods: [
        `${gender === 'masculino' ? '180g' : '140g'} de filé de peito de frango grelhado ou patinho moído`,
        `${gender === 'masculino' ? '180g' : '130g'} de arroz integral ou batata doce cozida`,
        '80g de feijão carioca ou preto (concha média)',
        'Prato farto de salada verde (rúcula, alface, espinafre) com tomate e 1 colher de sobremesa de azeite extravirgem'
      ],
      calories: Math.round(dailyCalories * 0.32),
      proteinGrams: Math.round(proteinGrams * 0.35),
      carbsGrams: Math.round(carbsGrams * 0.35),
      fatGrams: Math.round(fatGrams * 0.28),
      notes: 'Refeição principal rica em ferro, zinco, micronutrientes e alto teor de proteína pura.'
    },
    {
      id: 'm-4',
      name: 'Lanche da Tarde / Pré-Treino',
      time: '16:45',
      foods: [
        '30g de Whey Protein concentrado ou isolado batido com 200ml de água/leite vegetal',
        '40g de aveia em flocos finos',
        '1 colher de sopa de pasta de amendoim integral',
        '1 banana média amassada'
      ],
      calories: Math.round(dailyCalories * 0.18),
      proteinGrams: Math.round(proteinGrams * 0.20),
      carbsGrams: Math.round(carbsGrams * 0.20),
      fatGrams: Math.round(fatGrams * 0.15),
      notes: 'Consumir cerca de 60 a 90 minutos antes do treino para máxima energia e síntese muscular.'
    },
    {
      id: 'm-5',
      name: 'Jantar Restaurador / Pós-Treino',
      time: '20:00',
      foods: [
        `${gender === 'masculino' ? '160g' : '130g'} de tilápia grelhada, salmão ou carne magra`,
        `${gender === 'masculino' ? '150g' : '100g'} de mandioca cozida, abóbora cabotiá assada ou arroz`,
        'Legumes no vapor à vontade (brócolis, abobrinha, cenoura)',
        '1 xícara de chá de camomila ou melissa antes de dormir'
      ],
      calories: Math.round(dailyCalories * 0.13),
      proteinGrams: Math.round(proteinGrams * 0.11),
      carbsGrams: Math.round(carbsGrams * 0.06),
      fatGrams: Math.round(fatGrams * 0.12),
      notes: 'Refeição leve com digestão facilitada para otimizar o sono REM e a liberação de GH.'
    }
  ];

  const supplementSuggestions = [
    'Creatina Monohidratada: 5g todos os dias (inclusive dias sem treino) para aumento de força e volume celular.',
    'Whey Protein: 30g pós-treino ou no lanche para atingir a meta proteica diária com praticidade.',
    'Ômega 3: 2 cápsulas ao dia com ação anti-inflamatória e melhora da sensibilidade à insulina.',
    'Multivitamínico e Vitamina D3: 1 dose pela manhã para suporte imunológico e síntese hormonal.'
  ];

  return {
    dailyCalories,
    tmb,
    get: dailyCalories,
    macros: {
      proteinGrams,
      carbsGrams,
      fatGrams,
      proteinPercentage,
      carbsPercentage,
      fatPercentage,
    },
    waterIntakeMl,
    strategy,
    meals,
    supplementSuggestions,
  };
}

export function getStudentPastExerciseNames(student: Student): string[] {
  const names = new Set<string>();
  if (student.savedPlans && student.savedPlans.length > 0) {
    student.savedPlans.forEach((plan) => {
      plan.workouts.forEach((w) => {
        w.exercises.forEach((e) => {
          if (e.name) names.add(e.name.trim());
        });
      });
    });
  }
  return Array.from(names);
}

function pseudoRandom(seedStr: string): number {
  const seed = (seedStr || '')
    .split('')
    .reduce((acc, char, i) => acc + char.charCodeAt(0) * (i + 1), 42);
  const x = Math.sin(seed) * 10000;
  return Math.abs(x - Math.floor(x));
}

// Deterministic non-repeating shuffle seeded by student characteristics and timestamp
function getShuffledFilteredExercises(
  categoryFilter?: string,
  muscleFilter?: string,
  level?: string,
  seedStr?: string,
  excludedNames?: Set<string>
): DatabaseExercise[] {
  let list = [...EXERCISE_DATABASE];

  if (categoryFilter) {
    list = list.filter((e) => e.category === categoryFilter || (categoryFilter === 'inferiores' && (e.muscleGroup === 'Quadríceps' || e.muscleGroup === 'Glúteos' || e.muscleGroup === 'Posterior' || e.muscleGroup === 'Panturrilhas')));
  }
  if (muscleFilter) {
    list = list.filter((e) => e.muscleGroup === muscleFilter);
  }

  // If excludedNames is provided, prioritize fresh exercises not seen before
  if (excludedNames && excludedNames.size > 0) {
    const nonExcluded = list.filter((e) => !excludedNames.has(e.name.toLowerCase().trim()));
    const excluded = list.filter((e) => excludedNames.has(e.name.toLowerCase().trim()));
    list = [...nonExcluded, ...excluded];
  }

  // Shuffle using a hash seed so different students get different distinct exercise picks
  const seed = (seedStr || '')
    .split('')
    .reduce((acc, char, i) => acc + char.charCodeAt(0) * (i + 1), Date.now() % 10000);

  for (let i = list.length - 1; i > 0; i--) {
    const pRand = Math.abs(Math.sin(seed + i * 37)) * 10000;
    const j = Math.floor(pRand) % (i + 1);
    [list[i], list[j]] = [list[j], list[i]];
  }

  return list;
}

function buildExerciseInstance(
  dbEx: DatabaseExercise,
  student: Student,
  techniques: AdvancedTechnique[],
  index: number
): Exercise {
  const isFemale = student.gender === 'feminino';
  const isAdv = student.level === 'Avançado';
  const isBeginner = student.level === 'Iniciante';
  const goal = student.goal;

  // Base load estimation based on bodyweight and gender
  let baseLoad = 10;
  if (dbEx.muscleGroup === 'Quadríceps' || dbEx.muscleGroup === 'Glúteos') {
    baseLoad = Math.round(student.weightKg * (isFemale ? 0.45 : 0.65));
  } else if (dbEx.muscleGroup === 'Peitoral' || dbEx.muscleGroup === 'Dorsais') {
    baseLoad = Math.round(student.weightKg * (isFemale ? 0.3 : 0.55));
  } else if (dbEx.muscleGroup === 'Ombros' || dbEx.muscleGroup === 'Bíceps' || dbEx.muscleGroup === 'Tríceps') {
    baseLoad = Math.round(student.weightKg * (isFemale ? 0.12 : 0.22));
  } else {
    baseLoad = 15;
  }

  if (isBeginner) baseLoad = Math.round(baseLoad * 0.7);
  if (isAdv) baseLoad = Math.round(baseLoad * 1.3);

  // Technique allocation
  let chosenTechnique = 'Tradicional';
  let reps = dbEx.defaultReps;
  let sets = dbEx.defaultSets;

  if (techniques.length > 0) {
    if (techniques.includes('Pirâmide') && index === 0) {
      chosenTechnique = 'Pirâmide Crescente';
      reps = '12-10-8-6 (Aumentando carga a cada série)';
      sets = 4;
    } else if (techniques.includes('Drop-set') && index === 2) {
      chosenTechnique = 'Drop-Set na Última Série';
      reps = '3x10 + 1x até falha com redução de 30% da carga';
      sets = 3;
    } else if (techniques.includes('Bi-set') && index % 2 === 0 && index < 4) {
      chosenTechnique = 'Bi-Set Conjugado';
      reps = '10 a 12 reps sem descanso para o próximo';
    } else if (techniques.includes('Rest-pause') && index === 1) {
      chosenTechnique = 'Rest-Pause (10s pausa no pico)';
      reps = '3 séries normais + 1 série Rest-Pause (8+4+3 reps)';
    } else if (techniques.includes('Excêntrica Lenta')) {
      chosenTechnique = 'Excêntrica Lenta (3-4 segundos)';
      reps = '10 repetições controladas';
    }
  }

  // Adjust reps if specific goal
  if (goal.includes('Força') && chosenTechnique === 'Tradicional') {
    reps = '5-6 repetições pesadas';
    sets = 4;
  } else if (goal.includes('Emagrecimento') && chosenTechnique === 'Tradicional') {
    reps = '12-15 repetições ativas';
  }

  // Prefer direct verified video from EXERCISE_DATABASE, fallback to fuzzy matcher
  const matchedVideo = findBestVideoMatch(dbEx.name);
  const finalVideoUrl = dbEx.videoUrl || matchedVideo?.videoUrl || undefined;
  const finalVideoName = dbEx.videoName || matchedVideo?.videoName || dbEx.name;

  return {
    id: `ex-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    name: dbEx.name,
    muscleGroup: dbEx.muscleGroup,
    sets,
    reps,
    suggestedLoadKg: Math.max(5, Math.round(baseLoad / 2) * 2),
    userCurrentLoadKg: Math.max(5, Math.round(baseLoad / 2) * 2),
    restSeconds: dbEx.defaultRest,
    technique: chosenTechnique,
    notes: dbEx.executionTip,
    videoUrl: finalVideoUrl,
    videoName: finalVideoName,
    isCompleted: false,
    executedSets: Array.from({ length: sets }, (_, sIdx) => ({
      setNumber: sIdx + 1,
      repsCompleted: parseInt(reps.split('-')[0]) || 10,
      weightKg: Math.max(5, Math.round(baseLoad / 2) * 2),
      completed: false,
    })),
  };
}

export function generateAlgorithmicWorkout(
  student: Student,
  config: GeneratorConfig
): WorkoutPlan {
  const { modality, splitType, advancedTechniques, generationScope, customNotes } = config;
  const { tmb, get: dailyCalories } = calculateTMB(student);
  const nutritionPlan = generationScope !== 'workout_only' ? generateNutritionPlan(student, dailyCalories, tmb) : undefined;

  const pastNames = new Set<string>();
  if (config.avoidPreviousExercises !== false) {
    if (config.excludedExerciseNames) {
      config.excludedExerciseNames.forEach((n) => pastNames.add(n.toLowerCase().trim()));
    }
    const studentHistory = getStudentPastExerciseNames(student);
    studentHistory.forEach((n) => pastNames.add(n.toLowerCase().trim()));
  }

  const usedExerciseNames = new Set<string>();

  function pickUnique(pool: DatabaseExercise[], count: number): DatabaseExercise[] {
    const selected: DatabaseExercise[] = [];

    // 1st Priority: Exercises not used in this plan AND not used in student's previous history
    for (const ex of pool) {
      const lower = ex.name.toLowerCase().trim();
      if (!usedExerciseNames.has(lower) && !pastNames.has(lower)) {
        selected.push(ex);
        usedExerciseNames.add(lower);
        if (selected.length >= count) break;
      }
    }

    // 2nd Priority: Exercises not used in this plan (if history consumed all distinct options)
    if (selected.length < count) {
      for (const ex of pool) {
        const lower = ex.name.toLowerCase().trim();
        if (!usedExerciseNames.has(lower)) {
          selected.push(ex);
          usedExerciseNames.add(lower);
          if (selected.length >= count) break;
        }
      }
    }

    // 3rd Fallback: Remaining pool
    if (selected.length < count) {
      for (const ex of pool) {
        if (!selected.includes(ex)) {
          selected.push(ex);
          if (selected.length >= count) break;
        }
      }
    }

    return selected;
  }

  const workouts: WorkoutDay[] = [];
  const seedBase = `${student.name}_${student.gender}_${student.age}_${student.weightKg}_${student.goal}_${Date.now()}`;

  // 1. FULLBODY MODALITY
  if (modality === 'fullbody') {
    const daysCount = Math.min(Math.max(student.frequencyDaysPerWeek || 3, 2), 4);
    const dayCodes = ['A', 'B', 'C', 'D'];

    for (let d = 0; d < daysCount; d++) {
      const code = dayCodes[d];
      const daySeed = `${seedBase}_day_${code}`;
      const quads = getShuffledFilteredExercises(undefined, 'Quadríceps', student.level, daySeed + 'q', pastNames);
      const posteriorGlute = getShuffledFilteredExercises(undefined, d % 2 === 0 ? 'Glúteos' : 'Posterior', student.level, daySeed + 'p', pastNames);
      const chest = getShuffledFilteredExercises(undefined, 'Peitoral', student.level, daySeed + 'c', pastNames);
      const back = getShuffledFilteredExercises(undefined, 'Dorsais', student.level, daySeed + 'b', pastNames);
      const shoulders = getShuffledFilteredExercises(undefined, 'Ombros', student.level, daySeed + 's', pastNames);
      const arms = getShuffledFilteredExercises(undefined, d % 2 === 0 ? 'Bíceps' : 'Tríceps', student.level, daySeed + 'a', pastNames);
      const core = getShuffledFilteredExercises('core', undefined, student.level, daySeed + 'co', pastNames);

      const dayPicks = [
        ...pickUnique(quads, 1),
        ...pickUnique(posteriorGlute, 1),
        ...pickUnique(chest, 1),
        ...pickUnique(back, 1),
        ...pickUnique(shoulders, 1),
        ...pickUnique(arms, 1),
        ...pickUnique(core, 1),
      ];

      const exercises: Exercise[] = dayPicks.map((dbEx, idx) =>
        buildExerciseInstance(dbEx, student, advancedTechniques, idx)
      );

      workouts.push({
        id: `day-${code.toLowerCase()}`,
        code: `Treino ${code}`,
        name: `Fullbody ${code} - Corpo Inteiro & Equilíbrio Funcional`,
        focus: `Estímulo global com ênfase em ${d % 2 === 0 ? 'Membros Inferiores & Empurrar' : 'Cadeia Posterior & Puxar'}`,
        suggestedRestSeconds: 60,
        exercises,
      });
    }
  }

  // 2. INFERIORES / PERNAS EXCLUSIVAS
  else if (modality === 'inferiores') {
    const quads = getShuffledFilteredExercises(undefined, 'Quadríceps', student.level, seedBase + 'q', pastNames);
    const gluteos = getShuffledFilteredExercises(undefined, 'Glúteos', student.level, seedBase + 'g', pastNames);
    const posterior = getShuffledFilteredExercises(undefined, 'Posterior', student.level, seedBase + 'p', pastNames);
    const calves = getShuffledFilteredExercises(undefined, 'Panturrilhas', student.level, seedBase + 'c', pastNames);

    const dayPicks = [
      ...pickUnique(quads, 2),
      ...pickUnique(gluteos, 2),
      ...pickUnique(posterior, 2),
      ...pickUnique(calves, 1),
    ];

    const exercises: Exercise[] = dayPicks.map((dbEx, idx) =>
      buildExerciseInstance(dbEx, student, advancedTechniques, idx)
    );

    workouts.push({
      id: 'day-inferiores',
      code: 'Inferiores',
      name: 'Treino Especializado: Membros Inferiores & Glúteos',
      focus: 'Quadríceps, Glúteos, Isquiotibiais e Panturrilhas com volume e densidade máxima',
      suggestedRestSeconds: 75,
      exercises,
    });
  }

  // 3. MOBILIDADE ARTICULAR
  else if (modality === 'mobilidade') {
    const mobPool = getShuffledFilteredExercises('mobilidade', undefined, student.level, seedBase + 'mob', pastNames);
    const dayPicks = pickUnique(mobPool, 6);

    const exercises: Exercise[] = dayPicks.map((dbEx, idx) =>
      buildExerciseInstance(dbEx, student, advancedTechniques, idx)
    );

    workouts.push({
      id: 'day-mobilidade',
      code: 'Mobilidade',
      name: 'Rotina de Mobilidade Articular, Descompressão & Flexibilidade',
      focus: 'Liberação miofascial, amplitude de tornozelo, quadril, coluna torácica e escápulas',
      suggestedRestSeconds: 30,
      exercises,
    });
  }

  // 4. SUPERIORES
  else if (modality === 'superiores') {
    const chest = getShuffledFilteredExercises(undefined, 'Peitoral', student.level, seedBase + 'c', pastNames);
    const back = getShuffledFilteredExercises(undefined, 'Dorsais', student.level, seedBase + 'b', pastNames);
    const shoulders = getShuffledFilteredExercises(undefined, 'Ombros', student.level, seedBase + 's', pastNames);
    const biceps = getShuffledFilteredExercises(undefined, 'Bíceps', student.level, seedBase + 'bi', pastNames);
    const triceps = getShuffledFilteredExercises(undefined, 'Tríceps', student.level, seedBase + 'tri', pastNames);
    const core = getShuffledFilteredExercises('core', undefined, student.level, seedBase + 'core', pastNames);

    const dayPicks = [
      ...pickUnique(chest, 2),
      ...pickUnique(back, 2),
      ...pickUnique(shoulders, 1),
      ...pickUnique(biceps, 1),
      ...pickUnique(triceps, 1),
      ...pickUnique(core, 1),
    ];

    const exercises: Exercise[] = dayPicks.map((dbEx, idx) =>
      buildExerciseInstance(dbEx, student, advancedTechniques, idx)
    );

    workouts.push({
      id: 'day-superiores',
      code: 'Superiores',
      name: 'Treino de Membros Superiores Completo (Upper Body)',
      focus: 'Peito, Costas, Deltóides e Braços com equilíbrio articular',
      suggestedRestSeconds: 60,
      exercises,
    });
  }

  // 5. TREINO EM CASA (PROGRAMA COMPLETO 30 DIAS: TREINO A, B, C)
  else if (modality === 'casa') {
    const homeEquipment = config.homeEquipment || 'mixed_home';
    const equipmentLabel =
      homeEquipment === 'bodyweight_only'
        ? 'Peso Corporal (Calistenia)'
        : homeEquipment === 'elastic_bands'
        ? 'Acessórios & Elásticos'
        : homeEquipment === 'dumbbells_free_weights'
        ? 'Pesos Livres & Halteres'
        : 'Estrutura Completa em Casa';

    let homePool = EXERCISE_DATABASE.filter((e) => {
      if (homeEquipment === 'bodyweight_only') {
        return e.equipment === 'peso_corporal' || e.category === 'core' || e.category === 'mobilidade';
      }
      if (homeEquipment === 'elastic_bands') {
        return (
          e.equipment === 'elastico_acessorio' ||
          e.equipment === 'peso_corporal' ||
          e.category === 'core'
        );
      }
      if (homeEquipment === 'dumbbells_free_weights') {
        return (
          e.equipment === 'peso_livre' ||
          e.equipment === 'peso_corporal' ||
          e.category === 'core'
        );
      }
      return true;
    });

    if (homePool.length === 0) {
      homePool = EXERCISE_DATABASE;
    }

    // --- TREINO A: INFERIORES & GLÚTEOS + CORE ---
    const legsExercises = homePool.filter((e) => e.muscleGroup === 'Quadríceps' || e.muscleGroup === 'Glúteos' || e.muscleGroup === 'Posterior');
    const calfExercises = homePool.filter((e) => e.muscleGroup === 'Panturrilhas');
    const coreExercisesA = homePool.filter((e) => e.muscleGroup === 'Abdômen' || e.category === 'core');

    const shuffledLegs = [...legsExercises].sort(() => 0.5 - pseudoRandom(seedBase + 'ha_legs'));
    const shuffledCalves = [...calfExercises, ...legsExercises].sort(() => 0.5 - pseudoRandom(seedBase + 'ha_calf'));
    const shuffledCoreA = [...coreExercisesA].sort(() => 0.5 - pseudoRandom(seedBase + 'ha_core'));

    const dayAPicks = [
      ...pickUnique(shuffledLegs, 4),
      ...pickUnique(shuffledCalves, 1),
      ...pickUnique(shuffledCoreA, 1),
    ];
    const exA = dayAPicks.map((dbEx, idx) => buildExerciseInstance(dbEx, student, advancedTechniques, idx));

    workouts.push({
      id: 'day-casa-a',
      code: 'Treino A',
      name: `Treino A - Membros Inferiores & Glúteos (${equipmentLabel})`,
      focus: 'Ênfase em quadríceps, posterior de coxa, glúteos e estabilização de core',
      suggestedRestSeconds: 45,
      exercises: exA,
    });

    // --- TREINO B: SUPERIORES & TRONCO + ABDÔMEN ---
    const chestExercises = homePool.filter((e) => e.muscleGroup === 'Peitoral');
    const backExercises = homePool.filter((e) => e.muscleGroup === 'Dorsais');
    const shoulderExercises = homePool.filter((e) => e.muscleGroup === 'Ombros');
    const armExercises = homePool.filter((e) => e.muscleGroup === 'Bíceps' || e.muscleGroup === 'Tríceps');
    const coreExercisesB = homePool.filter((e) => e.muscleGroup === 'Abdômen' || e.category === 'core');

    const dayBPicks = [
      ...pickUnique(chestExercises.length ? chestExercises : homePool, 2),
      ...pickUnique(backExercises.length ? backExercises : homePool, 2),
      ...pickUnique(shoulderExercises.length ? shoulderExercises : homePool, 1),
      ...pickUnique(armExercises.length ? armExercises : homePool, 1),
      ...pickUnique(coreExercisesB.length ? coreExercisesB : homePool, 1),
    ];
    const exB = dayBPicks.map((dbEx, idx) => buildExerciseInstance(dbEx, student, advancedTechniques, idx));

    workouts.push({
      id: 'day-casa-b',
      code: 'Treino B',
      name: `Treino B - Membros Superiores & Puxar/Empurrar (${equipmentLabel})`,
      focus: 'Equilíbrio anatômico de peitoral, costas, deltóides e braços em ambiente domiciliar',
      suggestedRestSeconds: 45,
      exercises: exB,
    });

    // --- TREINO C: FULL BODY METABÓLICO & QUEIMA 30 DIAS (HIIT / FUNCIONAL) ---
    const functionalExercises = homePool.filter((e) => e.tier === 'funcional' || e.category === 'core' || e.category === 'mobilidade');
    const compoundExercises = homePool.filter((e) => e.tier === 'composto');
    const mobilityExercises = EXERCISE_DATABASE.filter((e) => e.category === 'mobilidade');

    const shuffledFunc = [...functionalExercises, ...compoundExercises].sort(() => 0.5 - pseudoRandom(seedBase + 'hc_func'));
    const shuffledMob = [...mobilityExercises].sort(() => 0.5 - pseudoRandom(seedBase + 'hc_mob'));

    const dayCPicks = [
      ...pickUnique(shuffledFunc, 4),
      ...pickUnique(shuffledMob, 2),
    ];
    const exC = dayCPicks.map((dbEx, idx) => buildExerciseInstance(dbEx, student, advancedTechniques, idx));

    workouts.push({
      id: 'day-casa-c',
      code: 'Treino C',
      name: `Treino C - Full Body Metabólico & Queima de Gordura 30 Dias`,
      focus: 'Aceleração do metabolismo, potência cardiovascular e mobilidade funcional completa',
      suggestedRestSeconds: 40,
      exercises: exC,
    });
  }

  // 6. MUSCULAÇÃO COM DIVISÕES (A/B, A/B/C)
  else {
    if (splitType === 'A/B' || splitType === 'Superior/Inferior') {
      const chest = getShuffledFilteredExercises(undefined, 'Peitoral', student.level, seedBase + 'a_c', pastNames);
      const back = getShuffledFilteredExercises(undefined, 'Dorsais', student.level, seedBase + 'a_b', pastNames);
      const shoulders = getShuffledFilteredExercises(undefined, 'Ombros', student.level, seedBase + 'a_s', pastNames);
      const arms = getShuffledFilteredExercises(undefined, 'Bíceps', student.level, seedBase + 'a_bi', pastNames);
      const triceps = getShuffledFilteredExercises(undefined, 'Tríceps', student.level, seedBase + 'a_tri', pastNames);

      const dayAPicks = [
        ...pickUnique(chest, 2),
        ...pickUnique(back, 2),
        ...pickUnique(shoulders, 1),
        ...pickUnique(arms, 1),
        ...pickUnique(triceps, 1),
      ];
      const exA = dayAPicks.map((ex, i) => buildExerciseInstance(ex, student, advancedTechniques, i));

      workouts.push({
        id: 'day-a',
        code: 'Treino A',
        name: 'Treino A - Membros Superiores (Peitoral, Dorsal, Ombros & Braços)',
        focus: 'Volume concentrado para tronco e membros superiores',
        suggestedRestSeconds: 60,
        exercises: exA,
      });

      const quads = getShuffledFilteredExercises(undefined, 'Quadríceps', student.level, seedBase + 'b_q', pastNames);
      const glutes = getShuffledFilteredExercises(undefined, 'Glúteos', student.level, seedBase + 'b_g', pastNames);
      const post = getShuffledFilteredExercises(undefined, 'Posterior', student.level, seedBase + 'b_p', pastNames);
      const calves = getShuffledFilteredExercises(undefined, 'Panturrilhas', student.level, seedBase + 'b_c', pastNames);
      const core = getShuffledFilteredExercises('core', undefined, student.level, seedBase + 'b_core', pastNames);

      const dayBPicks = [
        ...pickUnique(quads, 2),
        ...pickUnique(glutes, 2),
        ...pickUnique(post, 1),
        ...pickUnique(calves, 1),
        ...pickUnique(core, 1),
      ];
      const exB = dayBPicks.map((ex, i) => buildExerciseInstance(ex, student, advancedTechniques, i));

      workouts.push({
        id: 'day-b',
        code: 'Treino B',
        name: 'Treino B - Membros Inferiores & Core (Coxas, Glúteos e Abdômen)',
        focus: 'Intensidade e hipertrofia de membros inferiores com base biomecânica segura',
        suggestedRestSeconds: 75,
        exercises: exB,
      });
    } else {
      // A/B/C: A=Peito/Ombro/Tríceps (Push), B=Costas/Bíceps/Posterior de Ombro (Pull), C=Pernas Completo (Legs)
      const pushChest = getShuffledFilteredExercises(undefined, 'Peitoral', student.level, seedBase + 'push_c', pastNames);
      const pushShoulder = getShuffledFilteredExercises(undefined, 'Ombros', student.level, seedBase + 'push_s', pastNames);
      const pushTriceps = getShuffledFilteredExercises(undefined, 'Tríceps', student.level, seedBase + 'push_t', pastNames);
      const dayA = [
        ...pickUnique(pushChest, 3),
        ...pickUnique(pushShoulder, 2),
        ...pickUnique(pushTriceps, 2),
      ].map((ex, i) => buildExerciseInstance(ex, student, advancedTechniques, i));

      workouts.push({
        id: 'day-a',
        code: 'Treino A',
        name: 'Treino A - Peito, Ombros & Tríceps (Empurrar)',
        focus: 'Padrão de empurrar horizontal e vertical com isolamento de tríceps',
        suggestedRestSeconds: 60,
        exercises: dayA,
      });

      const pullBack = getShuffledFilteredExercises(undefined, 'Dorsais', student.level, seedBase + 'pull_b', pastNames);
      const pullBiceps = getShuffledFilteredExercises(undefined, 'Bíceps', student.level, seedBase + 'pull_bi', pastNames);
      const pullCore = getShuffledFilteredExercises('core', undefined, student.level, seedBase + 'pull_c', pastNames);
      const dayB = [
        ...pickUnique(pullBack, 3),
        ...pickUnique(pullBiceps, 2),
        ...pickUnique(pullCore, 2),
      ].map((ex, i) => buildExerciseInstance(ex, student, advancedTechniques, i));

      workouts.push({
        id: 'day-b',
        code: 'Treino B',
        name: 'Treino B - Costas, Bíceps & Abdômen (Puxar)',
        focus: 'Padrão de puxada vertical, remadas anatômicas e braquiais',
        suggestedRestSeconds: 60,
        exercises: dayB,
      });

      const legsQuad = getShuffledFilteredExercises(undefined, 'Quadríceps', student.level, seedBase + 'legs_q', pastNames);
      const legsGlute = getShuffledFilteredExercises(undefined, 'Glúteos', student.level, seedBase + 'legs_g', pastNames);
      const legsPost = getShuffledFilteredExercises(undefined, 'Posterior', student.level, seedBase + 'legs_p', pastNames);
      const legsCalf = getShuffledFilteredExercises(undefined, 'Panturrilhas', student.level, seedBase + 'legs_c', pastNames);
      const dayC = [
        ...pickUnique(legsQuad, 2),
        ...pickUnique(legsGlute, 2),
        ...pickUnique(legsPost, 2),
        ...pickUnique(legsCalf, 1),
      ].map((ex, i) => buildExerciseInstance(ex, student, advancedTechniques, i));

      workouts.push({
        id: 'day-c',
        code: 'Treino C',
        name: 'Treino C - Membros Inferiores Completo (Legs)',
        focus: 'Sobrecarga de quadríceps, isquiotibiais e glúteos com alta densidade',
        suggestedRestSeconds: 75,
        exercises: dayC,
      });
    }
  }

  // If coach provided custom exercises (with direct GIFs/video URLs), merge them into the workouts
  if (config.customExercises && config.customExercises.length > 0 && workouts.length > 0) {
    config.customExercises.forEach((customEx) => {
      // Find matching day by muscle group or append to first workout
      let targetDay = workouts[0];
      const mgLower = (customEx.muscleGroup || '').toLowerCase();
      const matchedDay = workouts.find((w) => {
        const wFocus = (w.focus || '').toLowerCase();
        const wName = (w.name || '').toLowerCase();
        if (mgLower.includes('inferior') || mgLower.includes('perna') || mgLower.includes('glúteo') || mgLower.includes('quadr')) {
          return wFocus.includes('inferior') || wFocus.includes('leg') || wName.includes('c') || wName.includes('inferior');
        }
        if (mgLower.includes('costas') || mgLower.includes('dorsal') || mgLower.includes('bíceps') || mgLower.includes('pull')) {
          return wFocus.includes('puxar') || wFocus.includes('costas') || wName.includes('b');
        }
        if (mgLower.includes('peito') || mgLower.includes('ombro') || mgLower.includes('tríceps') || mgLower.includes('push')) {
          return wFocus.includes('empurrar') || wFocus.includes('peito') || wName.includes('a');
        }
        return false;
      });

      if (matchedDay) {
        targetDay = matchedDay;
      }

      // Add to target day if not duplicate
      if (!targetDay.exercises.some((e) => e.name.toLowerCase() === customEx.name.toLowerCase())) {
        targetDay.exercises.push({
          ...customEx,
          id: customEx.id || `custom-ex-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          isCompleted: false,
          executedSets: Array.from({ length: customEx.sets || 3 }, (_, sIdx) => ({
            setNumber: sIdx + 1,
            repsCompleted: 10,
            weightKg: customEx.suggestedLoadKg || 15,
            completed: false,
          })),
        });
      }
    });
  }

  const title = `Protocolo Personalizado: ${student.name} • ${student.goal}`;
  const objectiveSummary = `Prescrição individualizada para ${student.name} (${student.gender}, ${student.age} anos, ${student.weightKg}kg, ${student.heightCm}cm), nível ${student.level}. Foco principal: ${student.goal}. Estrutura: ${modality.toUpperCase()} (${splitType}). Técnicas avançadas: ${advancedTechniques.join(', ') || 'Tradicional'}.`;

  return {
    id: `plan-${Date.now()}`,
    studentId: student.id,
    studentName: student.name,
    title,
    objectiveSummary,
    modality,
    splitType,
    advancedTechniques,
    generationScope,
    totalEstimatedTimeMinutes: modality === 'mobilidade' ? 30 : 55,
    coachCustomNotes: customNotes || '',
    workouts,
    nutritionPlan,
    createdAt: new Date().toISOString(),
  };
}

export async function requestWorkoutGeneration(
  student: Student,
  config: GeneratorConfig
): Promise<WorkoutPlan> {
  const previousExercises = config.excludedExerciseNames && config.excludedExerciseNames.length > 0
    ? config.excludedExerciseNames
    : getStudentPastExerciseNames(student);

  // If coach requested purely algorithmic generation or manual base
  if (config.generationEngine === 'algorithmic') {
    return generateAlgorithmicWorkout(student, config);
  }

  try {
    const response = await fetch('/api/generate-custom-workout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        student,
        workoutConfig: config,
        previousExercises,
      }),
    });

    if (response.ok) {
      const json = await response.json();
      if (json.success && json.data) {
        const aiData = json.data;
        // Construct valid workout plan from AI result with fallback validation
        const finalWorkouts: WorkoutDay[] = (aiData.workouts || []).map((w: any, idx: number) => ({
          id: w.id || `day-${idx}`,
          code: w.name?.includes('B') ? 'B' : w.name?.includes('C') ? 'C' : 'A',
          name: w.name || `Treino ${idx + 1}`,
          focus: w.focus || 'Hipertrofia & Força',
          suggestedRestSeconds: w.suggestedRestBetweenExercisesSeconds || 60,
          exercises: (w.exercises || []).map((e: any, eIdx: number) => {
            const exName = e.name || 'Exercício Personalizado';
            const dbMatch = EXERCISE_DATABASE.find(
              (db) =>
                db.name.toLowerCase() === exName.toLowerCase() ||
                exName.toLowerCase().includes(db.name.toLowerCase()) ||
                db.name.toLowerCase().includes(exName.toLowerCase())
            );
            const matchedVideo = findBestVideoMatch(exName);
            const videoUrl = dbMatch?.videoUrl || matchedVideo?.videoUrl || undefined;
            const videoName = dbMatch?.videoName || matchedVideo?.videoName || exName;

            return {
              id: e.id || `ex-${idx}-${eIdx}`,
              name: dbMatch?.name || exName,
              muscleGroup: e.muscleGroup || dbMatch?.muscleGroup || 'Geral',
              sets: Number(e.sets) || 3,
              reps: String(e.reps || '10-12'),
              suggestedLoadKg: Number(e.suggestedLoadKg) || 15,
              userCurrentLoadKg: Number(e.suggestedLoadKg) || 15,
              restSeconds: Number(e.restSeconds) || 60,
              technique: e.technique || 'Tradicional',
              notes: e.notes || dbMatch?.executionTip || '',
              videoUrl,
              videoName,
              isCompleted: false,
              executedSets: Array.from({ length: Number(e.sets) || 3 }, (_, sIdx) => ({
                setNumber: sIdx + 1,
                repsCompleted: 10,
                weightKg: Number(e.suggestedLoadKg) || 15,
                completed: false,
              })),
            };
          }),
        }));

        // Merge custom exercises with GIFs into finalWorkouts if provided
        if (config.customExercises && config.customExercises.length > 0 && finalWorkouts.length > 0) {
          config.customExercises.forEach((customEx) => {
            let targetDay = finalWorkouts[0];
            const mgLower = (customEx.muscleGroup || '').toLowerCase();
            const matchedDay = finalWorkouts.find((w) => {
              const wFocus = (w.focus || '').toLowerCase();
              const wName = (w.name || '').toLowerCase();
              if (mgLower.includes('inferior') || mgLower.includes('perna') || mgLower.includes('glúteo') || mgLower.includes('quadr')) {
                return wFocus.includes('inferior') || wFocus.includes('leg') || wName.includes('c') || wName.includes('inferior');
              }
              if (mgLower.includes('costas') || mgLower.includes('dorsal') || mgLower.includes('bíceps') || mgLower.includes('pull')) {
                return wFocus.includes('puxar') || wFocus.includes('costas') || wName.includes('b');
              }
              if (mgLower.includes('peito') || mgLower.includes('ombro') || mgLower.includes('tríceps') || mgLower.includes('push')) {
                return wFocus.includes('empurrar') || wFocus.includes('peito') || wName.includes('a');
              }
              return false;
            });

            if (matchedDay) {
              targetDay = matchedDay;
            }

            if (!targetDay.exercises.some((e) => e.name.toLowerCase() === customEx.name.toLowerCase())) {
              targetDay.exercises.push({
                ...customEx,
                id: customEx.id || `custom-ex-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
                isCompleted: false,
                executedSets: Array.from({ length: customEx.sets || 3 }, (_, sIdx) => ({
                  setNumber: sIdx + 1,
                  repsCompleted: 10,
                  weightKg: customEx.suggestedLoadKg || 15,
                  completed: false,
                })),
              });
            }
          });
        }

        let nutritionPlan: NutritionPlan | undefined = undefined;
        if (config.generationScope !== 'workout_only' && aiData.nutritionPlan) {
          const { tmb, get } = calculateTMB(student);
          const np = aiData.nutritionPlan;
          nutritionPlan = {
            dailyCalories: np.dailyCalories || get,
            tmb,
            get,
            macros: {
              proteinGrams: np.macros?.proteinGrams || Math.round(student.weightKg * 2),
              carbsGrams: np.macros?.carbsGrams || 200,
              fatGrams: np.macros?.fatGrams || 50,
              proteinPercentage: 30,
              carbsPercentage: 50,
              fatPercentage: 20,
            },
            waterIntakeMl: np.waterIntakeMl || Math.round(student.weightKg * 40),
            strategy: np.strategy || 'Estratégia nutricional individualizada',
            meals: (np.meals || []).map((m: any, mIdx: number) => ({
              id: m.id || `meal-${mIdx}`,
              name: m.name || `Refeição ${mIdx + 1}`,
              time: m.time || '08:00',
              foods: Array.isArray(m.foods) ? m.foods : [String(m.foods)],
              calories: m.calories || 350,
              proteinGrams: m.proteinGrams || 20,
              carbsGrams: m.carbsGrams || 40,
              fatGrams: m.fatGrams || 10,
              notes: m.notes || '',
            })),
            supplementSuggestions: np.supplementSuggestions || [],
          };
        }

        return {
          id: `plan-${Date.now()}`,
          studentId: student.id,
          studentName: student.name,
          title: aiData.title || `Protocolo Personalizado: ${student.name}`,
          objectiveSummary: aiData.objectiveSummary || `Foco em ${student.goal}`,
          modality: config.modality,
          splitType: config.splitType,
          advancedTechniques: config.advancedTechniques,
          generationScope: config.generationScope,
          totalEstimatedTimeMinutes: aiData.totalEstimatedTimeMinutes || 55,
          coachCustomNotes: config.customNotes || aiData.coachSummaryNotes || '',
          workouts: finalWorkouts.length > 0 ? finalWorkouts : generateAlgorithmicWorkout(student, config).workouts,
          nutritionPlan: nutritionPlan || (config.generationScope !== 'workout_only' ? generateNutritionPlan(student, calculateTMB(student).get, calculateTMB(student).tmb) : undefined),
          createdAt: new Date().toISOString(),
        };
      }
    }
  } catch (err) {
    console.warn('API call skipped or failed, using local smart generator:', err);
  }

  // Fallback to high-precision algorithmic generator
  return generateAlgorithmicWorkout(student, config);
}
